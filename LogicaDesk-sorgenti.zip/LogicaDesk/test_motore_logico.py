# test_motore_logico.py - test automatici del motore logico di LogicaDesk
#
# Come si avviano: fai doppio clic su Esegui_test.bat
# oppure, da un terminale aperto in questa cartella:  python test_motore_logico.py
# Alla fine compare il numero di casi verificati e «OK» se sono tutti giusti.
import csv
import io
import itertools
import random
import time
import unittest

import motore_logico as M

CASI = [0]


def conta(test_case, quanti=1):
    CASI[0] += quanti


def valori_finali(formula, nomi=None):
    """Colonna finale come stringa di V/F (comoda da leggere nei test)."""
    intestazione, righe = M.truth_table(formula, max_variabili=None)
    return "".join(riga[-1] for riga in righe)


# ---------- dati dei test ----------

TAUTOLOGIE = [
    "p ∨ ¬p", "p → p", "p ↔ p", "¬(p ∧ ¬p)", "(p ∧ q) → p", "(p ∧ q) → q", "p → (p ∨ q)", "q → (p ∨ q)",
    "((p → q) ∧ p) → q",                          # modus ponens
    "((p → q) ∧ ¬q) → ¬p",                        # modus tollens
    "((p → q) ∧ (q → r)) → (p → r)",              # sillogismo ipotetico
    "((p ∨ q) ∧ ¬p) → q",                         # sillogismo disgiuntivo
    "((p → q) → p) → p",                          # legge di Peirce
    "¬(p ∧ q) ↔ (¬p ∨ ¬q)",                       # De Morgan
    "¬(p ∨ q) ↔ (¬p ∧ ¬q)",                       # De Morgan
    "(p → q) ↔ (¬q → ¬p)",                        # contrapposizione
    "(p → q) ↔ (¬p ∨ q)",                         # implicazione materiale
    "((p ∧ q) → r) ↔ (p → (q → r))",              # esportazione
    "(p ∧ (q ∨ r)) ↔ ((p ∧ q) ∨ (p ∧ r))",        # distributiva
    "(p ∨ (q ∧ r)) ↔ ((p ∨ q) ∧ (p ∨ r))",        # distributiva
    "(p ∨ (p ∧ q)) ↔ p", "(p ∧ (p ∨ q)) ↔ p",     # assorbimento
    "¬¬p ↔ p",                                    # doppia negazione
    "(p ∧ q) ↔ (q ∧ p)", "(p ∨ q) ↔ (q ∨ p)",     # commutativa
    "((p ∧ q) ∧ r) ↔ (p ∧ (q ∧ r))", "((p ∨ q) ∨ r) ↔ (p ∨ (q ∨ r))",
    "(p ↔ q) ↔ ((p → q) ∧ (q → p))",
    "(p ↔ q) ↔ ((p ∧ q) ∨ (¬p ∧ ¬q))",
    "(p ⊕ q) ↔ ¬(p ↔ q)", "(p ⊕ q) ↔ ((p ∨ q) ∧ ¬(p ∧ q))",
    "(p ↑ q) ↔ ¬(p ∧ q)", "(p ↓ q) ↔ ¬(p ∨ q)", "(p ↑ p) ↔ ¬p", "(p ↓ p) ↔ ¬p",
    "((p ↑ q) ↑ (p ↑ q)) ↔ (p ∧ q)", "((p ↓ p) ↓ (q ↓ q)) ↔ (p ∧ q)",
    "p ∧ ⊤ ↔ p", "p ∨ ⊥ ↔ p", "p ∨ ⊤", "¬(p ∧ ⊥)", "⊤", "¬⊥", "V", "1", "vero", "true", "⊥ → p", "p → ⊤",
    "(p → q) ∨ (q → p)", "p → (q → p)", "(p → (q → r)) → ((p → q) → (p → r))",
    "(¬p → p) → p", "(p → ¬p) → ¬p", "((p ∨ q) ∧ (p → r) ∧ (q → r)) → r",
]

CONTRADDIZIONI = [
    "p ∧ ¬p", "¬(p ∨ ¬p)", "¬(p → p)", "p ↔ ¬p", "(p ∨ q) ∧ ¬p ∧ ¬q", "¬((p → q) ↔ (¬q → ¬p))",
    "⊥", "F", "0", "falso", "false", "¬⊤", "p ⊕ p", "(p ↑ q) ∧ p ∧ q", "(p ↓ q) ∧ (p ∨ q)", "p ∧ ⊥",
    "¬(((p → q) ∧ p) → q)",
]

CONTINGENTI = [
    "p", "¬p", "p ∧ q", "p ∨ q", "p → q", "p ↔ q", "p ⊕ q", "p ↑ q", "p ↓ q", "(p → q) → p",
    "p ∧ (q ∨ r)", "(p → q) ∧ (q → r)", "Pioggia → Bagnato", "p1 ∨ p2 ∨ p3", "q → p",
]

EQUIVALENTI = [
    ("¬(p ∧ q)", "¬p ∨ ¬q"), ("¬(p ∨ q)", "¬p ∧ ¬q"), ("p → q", "¬q → ¬p"), ("p → q", "¬p ∨ q"),
    ("p ↔ q", "(p → q) ∧ (q → p)"), ("p ⊕ q", "(p ∧ ¬q) ∨ (¬p ∧ q)"), ("p ↑ q", "¬p ∨ ¬q"),
    ("p ↓ q", "¬p ∧ ¬q"), ("¬¬¬p", "¬p"), ("p ∧ p", "p"), ("p ∨ p", "p"), ("p ∧ (p ∨ q)", "p"),
    ("(p ∧ q) → r", "p → (q → r)"), ("p ∨ (q ∧ r)", "(p ∨ q) ∧ (p ∨ r)"), ("p ∧ ⊤", "p"),
    ("p ∨ ⊤", "⊤"), ("p ∧ ⊥", "⊥"), ("p → ⊥", "¬p"), ("⊤ → p", "p"), ("p ↔ ⊤", "p"),
    ("p ↔ ⊥", "¬p"), ("p ⊕ ⊤", "¬p"), ("p ⊕ ⊥", "p"), ("¬(p ↔ q)", "¬p ↔ q"),
    ("p ⊕ q ⊕ r", "p ↔ q ↔ r"), ("(p → q) ∧ (p → r)", "p → (q ∧ r)"), ("(p → r) ∧ (q → r)", "(p ∨ q) → r"),
    ("p ↑ (q ↑ q)", "p → q"), ("¬p ↑ ¬q", "p ∨ q"), ("(p ↓ q) ↓ (p ↓ q)", "p ∨ q"),
    ("p → q → r", "p → (q → r)"), ("¬p ∧ q ∨ r", "((¬p) ∧ q) ∨ r"), ("p ∨ q ∧ r", "p ∨ (q ∧ r)"),
    ("p → q ↔ ¬q → ¬p", "(p → q) ↔ (¬q → ¬p)"), ("p ∧ q → r", "(p ∧ q) → r"),
    ("p ∨ q → r ∧ s", "(p ∨ q) → (r ∧ s)"), ("p ⊕ q ∧ r", "p ⊕ (q ∧ r)"), ("p ⊕ q ∨ r", "(p ⊕ q) ∨ r"),
    ("p ↑ q ∨ r", "(p ↑ q) ∨ r"), ("p ∧ q ↓ r", "(p ∧ q) ↓ r"),
]

NON_EQUIVALENTI = [
    ("p → q", "q → p"), ("p → q", "¬p → ¬q"), ("¬(p ∧ q)", "¬p ∧ ¬q"), ("¬(p ∨ q)", "¬p ∨ ¬q"),
    ("p ↑ q ↑ r", "p ↑ (q ↑ r)"), ("p ↓ q ↓ r", "p ↓ (q ↓ r)"), ("(p → q) → r", "p → (q → r)"),
    ("p ⊕ q", "p ∨ q"), ("p ∧ q", "p ∨ q"), ("p", "q"), ("p ∨ q ∧ r", "(p ∨ q) ∧ r"),
    ("¬p ∧ q", "¬(p ∧ q)"), ("p ↔ q", "p → q"), ("p ↑ q", "p ↓ q"), ("p", "¬p"),
]

# testo scritto in vari modi -> come deve essere riscritto
SINONIMI = [
    ("not p", "¬p"), ("NOT p", "¬p"), ("non p", "¬p"), ("!p", "¬p"), ("~p", "¬p"), ("¬p", "¬p"),
    ("p and q", "p ∧ q"), ("p AND q", "p ∧ q"), ("p & q", "p ∧ q"), ("p && q", "p ∧ q"), ("p ^ q", "p ∧ q"),
    ("p∧q", "p ∧ q"),
    ("p or q", "p ∨ q"), ("p OR q", "p ∨ q"), ("p | q", "p ∨ q"), ("p || q", "p ∨ q"), ("p∨q", "p ∨ q"),
    ("p xor q", "p ⊕ q"), ("p ⊻ q", "p ⊕ q"), ("p ⊕ q", "p ⊕ q"),
    ("p nand q", "p ↑ q"), ("p ↑ q", "p ↑ q"), ("p nor q", "p ↓ q"), ("p ↓ q", "p ↓ q"),
    ("p -> q", "p → q"), ("p => q", "p → q"), ("p ⇒ q", "p → q"), ("p ⊃ q", "p → q"), ("p→q", "p → q"),
    ("p <-> q", "p ↔ q"), ("p <=> q", "p ↔ q"), ("p ⇔ q", "p ↔ q"), ("p ≡ q", "p ↔ q"),
    ("p iff q", "p ↔ q"), ("p↔q", "p ↔ q"),
    ("V", "⊤"), ("1", "⊤"), ("vero", "⊤"), ("Vero", "⊤"), ("true", "⊤"), ("TRUE", "⊤"), ("⊤", "⊤"),
    ("F", "⊥"), ("0", "⊥"), ("falso", "⊥"), ("false", "⊥"), ("⊥", "⊥"),
    ("!(p&&q)->~r", "¬(p ∧ q) → ¬r"), ("p&!q", "p ∧ ¬q"), ("not not p", "¬¬p"), ("p<->!p", "p ↔ ¬p"),
    ("(p)", "p"), ("((p))", "p"), ("( p  ∧\tq )", "p ∧ q"),
]

PRECEDENZE = [
    ("¬p ∧ q", "¬p ∧ q"), ("¬(p ∧ q)", "¬(p ∧ q)"), ("p ∧ q ∨ r", "(p ∧ q) ∨ r"), ("p ∨ q ∧ r", "p ∨ (q ∧ r)"),
    ("p ∨ q → r", "(p ∨ q) → r"), ("p → q ∨ r", "p → (q ∨ r)"), ("p → q ↔ r", "(p → q) ↔ r"),
    ("p ↔ q → r", "p ↔ (q → r)"), ("p → q → r", "p → (q → r)"), ("p → q → r → s", "p → (q → (r → s))"),
    ("p ∧ q ∧ r", "p ∧ q ∧ r"), ("p ∨ q ∨ r", "p ∨ q ∨ r"), ("p ↔ q ↔ r", "(p ↔ q) ↔ r"),
    ("p ⊕ q ⊕ r", "(p ⊕ q) ⊕ r"), ("p ↑ q ↑ r", "(p ↑ q) ↑ r"), ("p ↓ q ↓ r", "(p ↓ q) ↓ r"),
    ("p ∧ q ↑ r", "(p ∧ q) ↑ r"), ("p ↑ q ∧ r", "(p ↑ q) ∧ r"), ("p ∨ q ↓ r", "(p ∨ q) ↓ r"),
    ("p ⊕ q ∧ r", "p ⊕ (q ∧ r)"), ("p ∨ q ⊕ r", "p ∨ (q ⊕ r)"), ("p ↓ q ∧ r", "p ↓ (q ∧ r)"),
    ("¬p ∧ q ∨ r → s ↔ t", "(((¬p ∧ q) ∨ r) → s) ↔ t"), ("¬¬p ∨ q", "¬¬p ∨ q"),
    ("¬p → ¬q", "¬p → ¬q"), ("p ∧ (q ∨ r)", "p ∧ (q ∨ r)"), ("(p → q) → r", "(p → q) → r"),
    ("p ∧ ¬q ∨ ¬r ∧ s", "(p ∧ ¬q) ∨ (¬r ∧ s)"), ("p ↔ q ∨ r ∧ s", "p ↔ (q ∨ (r ∧ s))"),
    ("((((p))))", "p"), ("p → (q → r) → s", "p → ((q → r) → s)"),
    # catene: senza parentesi solo se raggruppate da sinistra con lo stesso connettivo ∧ o ∨
    ("p ∧ q ∧ r ∧ s", "p ∧ q ∧ r ∧ s"), ("p ∧ (q ∧ r)", "p ∧ (q ∧ r)"), ("(p ∨ q) ∨ (r ∨ s)", "p ∨ q ∨ (r ∨ s)"),
    ("p ∧ q ∨ r ∧ s", "(p ∧ q) ∨ (r ∧ s)"), ("¬(p ∧ q ∧ r)", "¬(p ∧ q ∧ r)"), ("(p ∧ q ∧ r) ∨ s", "(p ∧ q ∧ r) ∨ s"),
]

# (formula, carattere atteso (da 1) oppure None, pezzo del messaggio)
ERRORI = [
    ("", None, "vuota"), ("   ", None, "vuota"), ("(p ∧ q", 1, "non chiusa"), ("p ∧ (q ∨ r", 5, "non chiusa"),
    ("((p", 1, "parentesi non chiuse"), ("p ∧ q)", 6, "in più"), (")", 1, "senza una parentesi aperta"),
    ("p)", 2, "in più"), ("()", 1, "vuote"), ("p ∧ ()", 5, "vuote"), ("p q", 3, "Manca un connettivo"),
    ("p (q)", 3, "Manca un connettivo"), ("(p)(q)", 4, "Manca un connettivo"), ("p ¬q", 3, "Manca un connettivo"),
    ("p v q", 3, "usa ∨"), ("p o q", 3, "usa ∨"), ("p e q", 3, "usa ∧"), ("∧ p", 1, "non può iniziare"),
    ("→ q", 1, "non può iniziare"), ("p ∧ ∨ q", 5, "Due connettivi"), ("p → → q", 5, "Due connettivi"),
    ("¬ ∧ p", 3, "Due connettivi"), ("p ∧", 3, "finisce troppo presto"), ("p →", 3, "finisce troppo presto"),
    ("¬", 1, "finisce troppo presto"), ("(", 1, "parentesi aperta"), ("p ∧ (", 5, "parentesi aperta"),
    ("(∧ p)", 2, "Dopo la parentesi aperta"), ("(p ∧)", 4, "Manca una formula dopo"),
    ("(¬)", 2, "Manca una formula dopo"), ("p + q", 3, "«+»"), ("p * q", 3, "«*»"), ("p = q", 3, "«=»"),
    ("p - q", 3, "«-»"), ("p <- q", 3, "«<»"), ("[p]", 1, "tonde"), ("p ∧ q #", 7, "«#»"),
    ("10", 1, "iniziare con una lettera"), ("2p", 1, "iniziare con una lettera"), ("p ∧ 23", 5, "iniziare con una lettera"),
    ("p ∧ q ∧ ∧ r", 9, "Due connettivi"), ("Pioggia →", 9, "finisce troppo presto"),
    ("((p ∧ q) ∨ (r", 1, "2 parentesi non chiuse (ai caratteri 1 e 12)"),
]


# ---------- generatore di formule casuali per il controllo incrociato ----------

LIVELLO = {"∧": 5, "↑": 5, "⊕": 4, "∨": 3, "↓": 3, "→": 2, "↔": 1}
SCRITTURE = {
    "¬": ["¬", "!", "~", "not ", "non "], "∧": ["∧", "&", "&&", "^", " and "], "∨": ["∨", "|", "||", " or "],
    "⊕": ["⊕", "⊻", " xor "], "↑": ["↑", " nand "], "↓": ["↓", " nor "], "→": ["→", "->", "=>", "⇒", "⊃"],
    "↔": ["↔", "<->", "<=>", "⇔", "≡", " iff "],
}


def formula_casuale(rnd, profondita, nomi):
    if profondita == 0 or rnd.random() < 0.2:
        if rnd.random() < 0.06:
            return ("const", rnd.random() < 0.5)
        return ("var", rnd.choice(nomi))
    if rnd.random() < 0.25:
        return ("¬", formula_casuale(rnd, profondita - 1, nomi))
    op = rnd.choice(list(LIVELLO))
    return (op, formula_casuale(rnd, profondita - 1, nomi), formula_casuale(rnd, profondita - 1, nomi))


def valuta_riferimento(nodo, valori):
    """Calcolo «da manuale», indipendente dal motore."""
    tipo = nodo[0]
    if tipo == "var":
        return valori[nodo[1]]
    if tipo == "const":
        return nodo[1]
    if tipo == "¬":
        return not valuta_riferimento(nodo[1], valori)
    a, b = valuta_riferimento(nodo[1], valori), valuta_riferimento(nodo[2], valori)
    return {"∧": a and b, "∨": a or b, "⊕": a != b, "↑": not (a and b), "↓": not (a or b),
            "→": (not a) or b, "↔": a == b}[tipo]


def scrivi_minimo(nodo, rnd):
    """Scrive la formula con il minimo di parentesi secondo le precedenze dichiarate, in stili misti."""
    tipo = nodo[0]
    if tipo == "var":
        return nodo[1]
    if tipo == "const":
        return rnd.choice(["⊤", "V", "1", "vero"] if nodo[1] else ["⊥", "F", "0", "falso"])
    if tipo == "¬":
        figlio = scrivi_minimo(nodo[1], rnd)
        if nodo[1][0] in LIVELLO:
            figlio = f"({figlio})"
        return rnd.choice(SCRITTURE["¬"]) + figlio
    livello = LIVELLO[tipo]
    parti = []
    for lato, figlio in (("sx", nodo[1]), ("dx", nodo[2])):
        testo = scrivi_minimo(figlio, rnd)
        if figlio[0] in LIVELLO:
            lf = LIVELLO[figlio[0]]
            serve = lf < livello or (lf == livello and (lato == "dx") != (tipo == "→"))
            if lf == livello and tipo == "→" and lato == "dx" and figlio[0] != "→":
                serve = True
            if serve or rnd.random() < 0.1:
                testo = f"({testo})"
        parti.append(testo)
    simbolo = rnd.choice(SCRITTURE[tipo])
    spazio = rnd.choice([" ", ""]) if not simbolo.startswith(" ") else ""
    return f"{parti[0]}{spazio}{simbolo}{spazio}{parti[1]}"


# ---------- test ----------

class TestClassificazione(unittest.TestCase):
    def test_tautologie(self):
        for f in TAUTOLOGIE:
            with self.subTest(formula=f):
                self.assertEqual(M.classifica(f), "tautologia")
                self.assertEqual(M.classify(M.truth_table(f)[1]), "Tautologia")
                conta(self)

    def test_contraddizioni(self):
        for f in CONTRADDIZIONI:
            with self.subTest(formula=f):
                self.assertEqual(M.classifica(f), "contraddizione")
                self.assertEqual(M.classify(M.truth_table(f)[1]), "Contraddizione")
                conta(self)

    def test_contingenti(self):
        for f in CONTINGENTI:
            with self.subTest(formula=f):
                self.assertEqual(M.classifica(f), "contingente")
                conta(self)


class TestEquivalenze(unittest.TestCase):
    def test_equivalenti(self):
        for a, b in EQUIVALENTI:
            with self.subTest(a=a, b=b):
                self.assertTrue(M.are_equivalent(a, b))
                self.assertTrue(M.compare(a, b)["equivalenti"])
                conta(self)

    def test_non_equivalenti(self):
        for a, b in NON_EQUIVALENTI:
            with self.subTest(a=a, b=b):
                self.assertFalse(M.are_equivalent(a, b))
                risultato = M.compare(a, b)
                self.assertFalse(risultato["equivalenti"])
                # ogni differenza dev'essere davvero una riga in cui le formule danno valori diversi
                for valori, va, vb in risultato["differenze"]:
                    self.assertEqual(M.evaluate(a, valori), va)
                    self.assertEqual(M.evaluate(b, valori), vb)
                    self.assertNotEqual(va, vb)
                conta(self)

    def test_dettagli_confronto(self):
        r = M.compare("p -> q", "q -> p")
        self.assertEqual((len(r["differenze"]), len(r["tutte"]), r["righe"]), (2, 4, 4))
        self.assertEqual(r["variabili"], ["p", "q"])
        self.assertEqual((r["a"], r["b"]), ("p → q", "q → p"))
        r = M.compare("p", "p ∧ (q ∨ ¬q)")
        self.assertTrue(r["equivalenti"])
        self.assertEqual(r["variabili"], ["p", "q"])
        conta(self, 2)


class TestScrittura(unittest.TestCase):
    def test_sinonimi(self):
        for testo, atteso in SINONIMI:
            with self.subTest(testo=testo):
                self.assertEqual(M.to_text(M.parse(testo)), atteso)
                conta(self)

    def test_precedenze(self):
        for testo, atteso in PRECEDENZE:
            with self.subTest(testo=testo):
                self.assertEqual(M.to_text(testo), atteso)
                # e la versione con le parentesi dev'essere la stessa formula
                self.assertTrue(M.are_equivalent(testo, atteso))
                conta(self)

    def test_nomi_di_variabili(self):
        casi = [
            ("Pioggia → Bagnato", ["Bagnato", "Pioggia"]), ("p1 ∧ p2 ∧ p10", ["p1", "p2", "p10"]),
            ("p10 ∧ p2 ∧ p1", ["p1", "p2", "p10"]), ("x_1 ∨ x_2", ["x_1", "x_2"]), ("p' → p", ["p", "p'"]),
            ("a ∧ A", ["A", "a"]), ("φ → ψ", ["φ", "ψ"]), ("v ∨ f", ["f", "v"]), ("V1 ∧ F2", ["F2", "V1"]),
            ("andrea ∧ oro", ["andrea", "oro"]), ("notte ∨ ¬notte", ["notte"]), ("q ∧ p ∧ r", ["p", "q", "r"]),
        ]
        for testo, nomi in casi:
            with self.subTest(testo=testo):
                self.assertEqual(M.variables(testo), nomi)
                conta(self)

    def test_parentesi_annidate(self):
        for livelli in (1, 2, 10, 50, 200, 1000, 5000):
            with self.subTest(livelli=livelli):
                self.assertEqual(M.to_text("(" * livelli + "p ∧ q" + ")" * livelli), "p ∧ q")
                self.assertEqual(M.classifica("¬" * livelli + "p"), "contingente")
                conta(self)
        catena = " ∧ ".join(["p"] * 5000)
        self.assertEqual(M.classifica(catena), "contingente")
        self.assertEqual(len(M.truth_table(catena)[0]), 5000)
        conta(self)


class TestErrori(unittest.TestCase):
    def test_errori_di_sintassi(self):
        for testo, carattere, pezzo in ERRORI:
            with self.subTest(testo=testo):
                with self.assertRaises(M.FormulaError) as contesto:
                    M.parse(testo)
                errore = contesto.exception
                self.assertIn(pezzo, str(errore))
                self.assertEqual(errore.carattere, carattere)
                if carattere is not None:
                    self.assertRegex(str(errore), rf"caratter[ei] {carattere}\b")
                conta(self)

    def test_troppe_variabili(self):
        with self.assertRaises(M.FormulaError) as contesto:
            M.truth_table("a ∧ b ∧ c ∧ d ∧ e ∧ f")
        self.assertIn("6 variabili", str(contesto.exception))
        with self.assertRaises(M.FormulaError):
            M.compare(" ∧ ".join(f"x{i}" for i in range(1, 12)), " ∨ ".join(f"x{i}" for i in range(11, 22)),
                      usa_sat=False)
        with self.assertRaises(M.FormulaError):
            M.normal_forms("a ∧ b ∧ c ∧ d ∧ e ∧ f ∧ g")
        conta(self, 3)

    def test_prefissi(self):
        with self.assertRaises(M.FormulaError) as c:
            M.compare("p ∧", "q")
        self.assertTrue(str(c.exception).startswith("Formula A:"))
        self.assertEqual(c.exception.carattere, 3)
        with self.assertRaises(M.FormulaError) as c:
            M.compare("p", "(q")
        self.assertTrue(str(c.exception).startswith("Formula B:"))
        with self.assertRaises(M.FormulaError) as c:
            M.consequence(["p", "q ∨"], "r")
        self.assertTrue(str(c.exception).startswith("Premessa 2:"))
        with self.assertRaises(M.FormulaError) as c:
            M.consequence(["p"], "")
        self.assertTrue(str(c.exception).startswith("Conclusione:"))
        conta(self, 4)


class TestTavola(unittest.TestCase):
    def test_struttura(self):
        intestazione, righe = M.truth_table("(p -> q) & !r")
        self.assertEqual(intestazione, ["p", "q", "r", "p → q", "¬r", "(p → q) ∧ ¬r"])
        self.assertEqual([r[:3] for r in righe],
                         [list(c) for c in ("VVV", "VVF", "VFV", "VFF", "FVV", "FVF", "FFV", "FFF")])
        self.assertEqual("".join(r[-1] for r in righe), "FVFFFVFV")
        conta(self, 3)

    def test_colonne_finali(self):
        casi = [
            ("p ∧ q", "VFFF"), ("p ∨ q", "VVVF"), ("p → q", "VFVV"), ("p ↔ q", "VFFV"), ("p ⊕ q", "FVVF"),
            ("p ↑ q", "FVVV"), ("p ↓ q", "FFFV"), ("¬p", "FV"), ("p", "VF"), ("q → p", "VVFV"),
            ("p ∧ q ∧ r", "VFFFFFFF"), ("p ∨ q ∨ r", "VVVVVVVF"), ("p → q → r", "VFVVVVVV"),
            ("(p → q) → r", "VFVVVFVF"), ("p ↑ q ↑ r", "VVFVFVFV"),
        ]
        for formula, atteso in casi:
            with self.subTest(formula=formula):
                self.assertEqual(valori_finali(formula), atteso)
                conta(self)

    def test_casi_particolari(self):
        self.assertEqual(M.truth_table("p"), (["p"], [["V"], ["F"]]))            # niente colonna doppia
        self.assertEqual(M.truth_table("⊤"), (["⊤"], [["V"]]))
        self.assertEqual(M.truth_table("V ∧ F"), (["⊤ ∧ ⊥"], [["F"]]))
        self.assertEqual(M.truth_table("¬⊤"), (["¬⊤"], [["F"]]))
        self.assertEqual(M.truth_table("p ∧ p")[0], ["p", "p ∧ p"])
        # una sottoformula ripetuta compare una sola volta
        self.assertEqual(M.truth_table("(p ∧ q) ∨ (p ∧ q)")[0], ["p", "q", "p ∧ q", "(p ∧ q) ∨ (p ∧ q)"])
        self.assertEqual(M.truth_table("p ∧ ⊤")[0], ["p", "p ∧ ⊤"])
        self.assertEqual(len(M.truth_table("a ∧ b ∧ c ∧ d ∧ e")[1]), 32)
        conta(self, 8)

    def test_coerenza_con_evaluate(self):
        for formula in TAUTOLOGIE[:20] + CONTINGENTI:
            intestazione, righe = M.truth_table(formula)
            nomi = M.variables(formula)
            for numero, riga in enumerate(righe):
                valori = M.assegnazione(nomi, numero)
                self.assertEqual([("V" if valori[n] else "F") for n in nomi], riga[:len(nomi)])
                self.assertEqual(M.evaluate(formula, valori), riga[-1] == "V")
        conta(self, 35)

    def test_molte_variabili_veloce(self):
        nomi = [f"p{i}" for i in range(1, 19)]
        formula = " ∧ ".join(f"({n} ∨ ¬{n})" for n in nomi)
        inizio = time.perf_counter()
        self.assertEqual(M.classifica(formula), "tautologia")
        self.assertLess(time.perf_counter() - inizio, 5)
        conta(self)


class TestConseguenza(unittest.TestCase):
    def test_argomenti(self):
        casi = [
            (["p → q", "p"], "q", True), (["p → q", "¬q"], "¬p", True), (["p → q", "q → r"], "p → r", True),
            (["p ∨ q", "¬p"], "q", True), (["p ∧ q"], "p", True), (["p"], "p ∨ q", True),
            (["p → q", "q"], "p", False), (["p → q", "¬p"], "¬q", False), ([], "p ∨ ¬p", True),
            ([], "p", False), (["p", "¬p"], "q", True), (["", "p"], "p", True), (["p ∨ q"], "p", False),
        ]
        for premesse, conclusione, valida in casi:
            with self.subTest(premesse=premesse, conclusione=conclusione):
                r = M.consequence(premesse, conclusione)
                self.assertEqual(r["valida"], valida)
                for valori, vp, vc in r["controesempi"]:
                    self.assertTrue(all(vp))
                    self.assertFalse(vc)
                conta(self)
        r = M.consequence(["p", "¬p"], "q")
        self.assertEqual(r["righe_critiche"], 0)
        conta(self)


class TestFormeNormali(unittest.TestCase):
    def test_forme_equivalenti(self):
        formule = ["p → q", "p ↔ q", "p ⊕ q ⊕ r", "(p ∧ q) ∨ (¬p ∧ r)", "¬(p ∨ q) → r", "p ↑ q ↓ r",
                   "p ∨ ¬p", "p ∧ ¬p", "(a∧b)∨(c∧d)", "a → b → c → d"]
        for formula in formule:
            with self.subTest(formula=formula):
                r = M.normal_forms(formula)
                for chiave in ("fnd_canonica", "fnc_canonica", "fnd_minima", "fnc_minima"):
                    self.assertTrue(M.are_equivalent(formula, r[chiave]), chiave)
                conta(self)

    def test_risultati_noti(self):
        r = M.normal_forms("p -> q")
        self.assertEqual((r["fnd_minima"], r["fnc_minima"]), ("¬p ∨ q", "¬p ∨ q"))
        self.assertEqual(r["righe_vere"], [1, 3, 4])
        self.assertEqual(r["righe_false"], [2])
        self.assertEqual(r["fnd_canonica"], "(p ∧ q) ∨ (¬p ∧ q) ∨ (¬p ∧ ¬q)")
        self.assertEqual(M.normal_forms("⊤")["fnd_minima"], "⊤")
        conta(self, 5)


class TestAnalisi(unittest.TestCase):
    def test_tautologie_senza_controesempio(self):
        for f in TAUTOLOGIE:
            with self.subTest(formula=f):
                r = M.analizza(f)
                self.assertEqual(r["classificazione"], "tautologia")
                self.assertIsNone(r["controesempio"])
                self.assertIsNone(r["riga_controesempio"])
                self.assertTrue(r["soddisfacibile"])
                self.assertEqual(r["righe_vere"], r["righe"])
                conta(self)

    def test_contraddizioni_senza_esempio(self):
        for f in CONTRADDIZIONI:
            with self.subTest(formula=f):
                r = M.analizza(f)
                self.assertEqual(r["classificazione"], "contraddizione")
                self.assertIsNone(r["esempio"])
                self.assertFalse(r["soddisfacibile"])
                self.assertFalse(M.evaluate(f, r["controesempio"]))
                conta(self)

    def test_controesempi_ed_esempi(self):
        for f in CONTINGENTI + [a for a, _ in NON_EQUIVALENTI]:
            with self.subTest(formula=f):
                r = M.analizza(f)
                self.assertEqual(r["classificazione"], "contingente")
                # il controesempio rende davvero falsa la formula, l'esempio la rende vera
                self.assertFalse(M.evaluate(f, r["controesempio"]))
                self.assertTrue(M.evaluate(f, r["esempio"]))
                # e corrispondono alle righe indicate della tavola
                _, righe = M.truth_table(f)
                self.assertEqual(righe[r["riga_controesempio"] - 1][-1], "F")
                self.assertEqual(righe[r["riga_esempio"] - 1][-1], "V")
                self.assertEqual("V" in [x[-1] for x in righe[:r["riga_esempio"] - 1]], False)
                self.assertEqual(r["righe_vere"], sum(x[-1] == "V" for x in righe))
                conta(self)

    def test_esempio_noto(self):
        r = M.analizza("p → q")
        self.assertEqual((r["riga_controesempio"], r["controesempio"]), (2, {"p": True, "q": False}))
        self.assertEqual(M.descrivi_assegnazione(r["controesempio"], r["variabili"]), "p = V, q = F")
        self.assertEqual(r["verdetto"], M.classify(M.truth_table("p → q")[1]))
        conta(self, 3)

    def test_venti_variabili(self):
        nomi = [f"x{i}" for i in range(1, 21)]
        inizio = time.perf_counter()
        r = M.analizza(" ∧ ".join(f"({n} ∨ ¬{n})" for n in nomi) + " ∧ (x1 → x20)")
        self.assertLess(time.perf_counter() - inizio, 5)
        self.assertEqual(r["righe"], 2 ** 20)
        self.assertEqual(r["righe_vere"], 3 * 2 ** 18)
        self.assertEqual(r["controesempio"]["x1"], True)
        self.assertEqual(r["controesempio"]["x20"], False)
        with self.assertRaises(M.FormulaError) as c:
            M.analizza(" ∧ ".join(f"x{i}" for i in range(1, 22)), usa_sat=False)
        self.assertIn("21 variabili", str(c.exception))
        conta(self, 3)

    def test_confronto_grande(self):
        nomi = [f"x{i}" for i in range(1, 13)]
        r = M.compare("x1", "x1 ∧ x2 ∧ " + " ∧ ".join(f"({n} ∨ ¬{n})" for n in nomi))
        self.assertFalse(r["equivalenti"])
        self.assertIsNone(r["tutte"])
        self.assertEqual(r["righe_diverse"], 2 ** 12 // 4)
        self.assertEqual(len(r["differenze"]), M.LIMITE_RIGHE_ELENCO)
        valori, va, vb = r["controesempio"]
        self.assertEqual((valori["x1"], valori["x2"], va, vb), (True, False, True, False))
        r = M.compare(" ∨ ".join(nomi), " ∨ ".join(reversed(nomi)))
        self.assertTrue(r["equivalenti"])
        self.assertEqual((r["righe_diverse"], r["controesempio"]), (0, None))
        conta(self, 2)

    def test_conseguenza_grande(self):
        nomi = [f"x{i}" for i in range(1, 15)]
        catena = [f"{a} → {b}" for a, b in zip(nomi, nomi[1:])]
        r = M.consequence(catena + ["x1"], "x14")
        self.assertTrue(r["valida"])
        self.assertIsNone(r["tutte"])
        self.assertEqual((r["righe_critiche"], r["numero_controesempi"]), (1, 0))
        r = M.consequence(catena, "x1")
        self.assertFalse(r["valida"])
        self.assertEqual(r["numero_controesempi"], 14)   # x1 falsa: la catena è vera in 14 modi
        for valori, vp, vc in r["controesempi"]:
            self.assertTrue(all(vp))
            self.assertFalse(vc)
        conta(self, 2)

    def test_conteggi_casuali(self):
        rnd = random.Random(31)
        nomi = ["p", "q", "r", "s", "t"]
        for numero in range(150):
            albero = formula_casuale(rnd, rnd.randint(1, 5), nomi)
            testo = scrivi_minimo(albero, rnd)
            with self.subTest(numero=numero, testo=testo):
                r = M.analizza(testo)
                vere = 0
                for riga in range(r["righe"]):
                    valori = dict.fromkeys(nomi, False) | M.assegnazione(r["variabili"], riga)
                    vere += valuta_riferimento(albero, valori)
                self.assertEqual(r["righe_vere"], vere)
                if r["controesempio"] is not None:
                    self.assertFalse(valuta_riferimento(albero, dict.fromkeys(nomi, False) | r["controesempio"]))
                if r["esempio"] is not None:
                    self.assertTrue(valuta_riferimento(albero, dict.fromkeys(nomi, False) | r["esempio"]))
                conta(self)


class TestFormeNormaliPassoPasso(unittest.TestCase):
    NOMI_LEGGI = {nome for nome, _ in M.LEGGI.values()}

    def controlla(self, formula, tipo):
        r = M.forma_normale_passo_passo(formula, tipo)
        # ogni formula intermedia è equivalente a quella di partenza
        for passaggio in r["passaggi"]:
            self.assertIn(passaggio["legge"], self.NOMI_LEGGI)
            self.assertTrue(M.are_equivalent(formula, passaggio["formula"]), passaggio)
            self.assertTrue(passaggio["esempi"] or passaggio["nota"])
        # il risultato è davvero nella forma richiesta ed è equivalente
        self.assertTrue(M.e_forma_normale(r["risultato"], tipo), r["risultato"])
        self.assertTrue(M.are_equivalent(formula, r["risultato"]))
        self.assertIs(r["verificata"], True)
        if r["passaggi"]:
            self.assertEqual(r["passaggi"][-1]["formula"], r["risultato"])
        # niente letterali ripetuti, niente p e ¬p nello stesso termine, niente termini che ne contengono altri
        insiemi = [set(t) for t in r["termini"]]
        for termine in r["termini"]:
            self.assertEqual(len(termine), len(set(termine)))
            self.assertFalse(any(("¬" + l) in termine for l in termine))
        for i, a in enumerate(insiemi):
            for j, b in enumerate(insiemi):
                if i != j:
                    self.assertFalse(a <= b, (a, b))
        return r

    def test_formule_note(self):
        for formula in TAUTOLOGIE[:25] + CONTRADDIZIONI + CONTINGENTI + [a for a, _ in EQUIVALENTI]:
            for tipo in ("FNC", "FND"):
                with self.subTest(formula=formula, tipo=tipo):
                    self.controlla(formula, tipo)
                    conta(self)

    def test_formule_casuali(self):
        rnd = random.Random(99)
        for numero in range(250):
            albero = formula_casuale(rnd, rnd.randint(1, 4), ["p", "q", "r", "s"])
            testo = scrivi_minimo(albero, rnd)
            for tipo in ("FNC", "FND"):
                with self.subTest(numero=numero, testo=testo, tipo=tipo):
                    try:
                        self.controlla(testo, tipo)
                    except M.FormulaError as errore:
                        self.assertIn("troppo lunga", str(errore))
                    conta(self)

    def test_passaggi_attesi(self):
        casi = [
            ("p → q", "FNC", ["Eliminazione dell'implicazione"], "¬p ∨ q"),
            ("¬(p ∧ q)", "FNC", ["Leggi di De Morgan"], "¬p ∨ ¬q"),
            ("¬(p ∨ q)", "FND", ["Leggi di De Morgan"], "¬p ∧ ¬q"),
            ("¬¬p", "FNC", ["Doppia negazione"], "p"),
            ("p ∨ (q ∧ r)", "FNC", ["Distributività di ∨ rispetto a ∧"], "(p ∨ q) ∧ (p ∨ r)"),
            ("p ∧ (q ∨ r)", "FND", ["Distributività di ∧ rispetto a ∨"], "(p ∧ q) ∨ (p ∧ r)"),
            ("p ↔ q", "FNC", ["Eliminazione della doppia implicazione", "Eliminazione dell'implicazione"],
             "(¬p ∨ q) ∧ (¬q ∨ p)"),
            ("p ↔ q", "FND", ["Doppia implicazione in forma disgiuntiva"], "(p ∧ q) ∨ (¬p ∧ ¬q)"),
            ("p ↑ q", "FNC", ["Definizione di NAND", "Leggi di De Morgan"], "¬p ∨ ¬q"),
            ("p ↓ q", "FND", ["Definizione di NOR", "Leggi di De Morgan"], "¬p ∧ ¬q"),
            ("p ⊕ q", "FNC", ["Eliminazione della disgiunzione esclusiva"], "(p ∨ q) ∧ (¬p ∨ ¬q)"),
            ("p → ⊥", "FNC", ["Eliminazione dell'implicazione", "Identità e dominazione"], "¬p"),
            ("(p ∨ ¬p) ∧ q", "FNC", ["Terzo escluso e identità"], "q"),
            ("(p ∧ ¬p) ∨ q", "FND", ["Non contraddizione e identità"], "q"),
            ("p ∧ (p ∨ q)", "FNC", ["Assorbimento"], "p"),
            ("p ∨ (p ∧ q)", "FND", ["Assorbimento"], "p"),
            ("(p ∨ p) ∧ q", "FNC", ["Idempotenza"], "p ∧ q"),
            ("p ∧ (q ∧ r)", "FNC", ["Associatività"], "p ∧ q ∧ r"),
            ("p ∧ q", "FNC", [], "p ∧ q"), ("p", "FND", [], "p"), ("⊤", "FNC", [], "⊤"),
            ("p ∨ ¬p", "FNC", ["Terzo escluso e identità"], "⊤"),
            ("p ∧ ¬p", "FND", ["Non contraddizione e identità"], "⊥"),
        ]
        for formula, tipo, leggi, risultato in casi:
            with self.subTest(formula=formula, tipo=tipo):
                r = M.forma_normale_passo_passo(formula, tipo)
                self.assertEqual([p["legge"] for p in r["passaggi"]], leggi)
                self.assertEqual(r["risultato"], risultato)
                conta(self)

    def test_e_forma_normale(self):
        casi = [("p ∧ (q ∨ ¬r)", "FNC", True), ("p ∧ (q ∨ ¬r)", "FND", False), ("p ∨ (q ∧ r)", "FND", True),
                ("¬¬p", "FNC", False), ("p → q", "FNC", False), ("p", "FNC", True), ("⊤", "FND", True),
                ("¬(p ∧ q)", "FND", False), ("p ∨ q ∨ ¬r", "FNC", True), ("p ∨ q ∨ ¬r", "FND", True)]
        for formula, tipo, atteso in casi:
            with self.subTest(formula=formula, tipo=tipo):
                self.assertEqual(M.e_forma_normale(formula, tipo), atteso)
                conta(self)

    def test_formula_troppo_grande(self):
        # la FNC di una lunga disgiunzione di congiunzioni cresce in modo esponenziale
        formula = " ∨ ".join(f"(a{i} ∧ b{i})" for i in range(1, 16))
        with self.assertRaises(M.FormulaError) as c:
            M.forma_normale_passo_passo(formula, "FNC")
        self.assertIn("troppo lunga", str(c.exception))
        self.assertEqual(len(M.forma_normale_passo_passo(formula, "FND")["termini"]), 15)
        with self.assertRaises(M.FormulaError):
            M.forma_normale_passo_passo("¬" * 70 + "p", "FNC")
        conta(self, 3)


def da_mintermini(nomi, numeri):
    """FND canonica scritta a partire dai numeri dei mintermini (1 = vera, la prima variabile a sinistra)."""
    if not numeri:   # contraddizione che contiene comunque tutte le variabili
        return " ∧ ".join(f"({v} ∧ ¬{v})" for v in nomi)
    n = len(nomi)
    return " ∨ ".join("(" + " ∧ ".join(v if (m >> (n - 1 - i)) & 1 else "¬" + v for i, v in enumerate(nomi)) + ")"
                      for m in numeri)


def costo_minimo_forza_bruta(numeri, n):
    """Costo (termini, letterali) della FND più corta, cercata provando tutto: indipendente dal motore."""
    numeri = set(numeri)
    if not numeri:
        return (0, 0)
    def copre(imp):
        return {m for m in range(1 << n)
                if all(c == "-" or c == format(m, f"0{n}b")[i] for i, c in enumerate(imp))}
    implicanti = {imp: copre(imp) for imp in ("".join(t) for t in itertools.product("01-", repeat=n))}
    implicanti = {imp: c for imp, c in implicanti.items() if c <= numeri}
    primi = [imp for imp, c in implicanti.items()
             if not any(altro != imp and c < c2 for altro, c2 in implicanti.items())]
    for k in range(1, len(primi) + 1):
        costi = [sum(n - p.count("-") for p in scelta) for scelta in itertools.combinations(primi, k)
                 if set().union(*(implicanti[p] for p in scelta)) == numeri]
        if costi:
            return (k, min(costi))
    raise AssertionError("nessuna copertura")


class TestSemplificazione(unittest.TestCase):
    def test_esempi_classici(self):
        # esempio dei libri: f(a,b,c,d) = Σm(0,1,2,5,6,7,8,9,10,14) -> 3 termini, 7 letterali
        r = M.minimizza(da_mintermini(list("abcd"), [0, 1, 2, 5, 6, 7, 8, 9, 10, 14]))
        self.assertEqual((r["termini_minimi"], r["letterali"]), (3, 7))
        self.assertEqual(r["termini"], [0, 1, 2, 5, 6, 7, 8, 9, 10, 14])
        # nucleo ciclico: nessun implicante essenziale, servono comunque 3 termini
        r = M.minimizza(da_mintermini(list("abc"), [0, 1, 2, 5, 6, 7]))
        self.assertEqual((r["termini_minimi"], r["letterali"]), (3, 6))
        self.assertFalse(any(p["essenziale"] for p in r["primi"]))
        self.assertEqual(len(r["primi"]), 6)
        # casi semplici
        self.assertEqual(M.minimizza("p → q")["risultato"], "¬p ∨ q")
        self.assertEqual(M.minimizza("p → q", "FNC")["risultato"], "¬p ∨ q")
        self.assertEqual(M.minimizza("(p ∧ q) ∨ (p ∧ ¬q)")["risultato"], "p")
        self.assertEqual(M.minimizza("p ∨ ¬p")["risultato"], "⊤")
        self.assertEqual(M.minimizza("p ∧ ¬p")["risultato"], "⊥")
        self.assertEqual(M.minimizza("p ∨ ¬p", "FNC")["risultato"], "⊤")
        self.assertEqual(M.minimizza("p ∧ ¬p", "FNC")["risultato"], "⊥")
        self.assertEqual(M.minimizza("⊤")["risultato"], "⊤")
        conta(self, 10)

    def test_giri_di_quine_mccluskey(self):
        r = M.minimizza(da_mintermini(list("abc"), [0, 1, 2, 3]))   # = ¬a
        self.assertEqual(r["risultato"], "¬a")
        self.assertEqual([len(g) for g in r["giri"]], [4, 4, 1])
        self.assertEqual(r["giri"][-1][0]["implicante"], "0--")
        self.assertTrue(all(v["usato"] for v in r["giri"][0]))
        self.assertEqual(r["primi"][0]["copre"], [0, 1, 2, 3])
        conta(self, 3)

    def test_minimalita_contro_forza_bruta(self):
        rnd = random.Random(4)
        for numero in range(160):
            n = rnd.choice([2, 3, 3, 4, 4])
            nomi = ["p", "q", "r", "s"][:n]
            mintermini = sorted(m for m in range(1 << n) if rnd.random() < 0.5)
            formula = da_mintermini(nomi, mintermini)
            for tipo in ("FND", "FNC"):
                with self.subTest(numero=numero, mintermini=mintermini, tipo=tipo):
                    r = M.minimizza(formula, tipo)
                    self.assertTrue(M.are_equivalent(formula, r["risultato"]))
                    self.assertTrue(r["garantita"])
                    da_coprire = (mintermini if tipo == "FND"
                                  else [m for m in range(1 << n) if m not in mintermini])
                    self.assertEqual(r["termini"], da_coprire)
                    atteso = costo_minimo_forza_bruta(da_coprire, n)
                    if da_coprire and len(da_coprire) < (1 << n):
                        self.assertEqual((r["termini_minimi"], r["letterali"]), atteso)
                    conta(self)

    def test_coerenza_con_forme_normali(self):
        for formula in CONTINGENTI[:12] + TAUTOLOGIE[:5] + CONTRADDIZIONI[:5]:
            with self.subTest(formula=formula):
                forme = M.normal_forms(formula)
                self.assertEqual(forme["fnd_minima"], M.minimizza(formula, "FND")["risultato"])
                self.assertEqual(forme["fnc_minima"], M.minimizza(formula, "FNC")["risultato"])
                conta(self)

    def test_dieci_variabili_veloce(self):
        formule = ["(a ∨ b ∨ ¬c) ∧ (c ∨ d ∨ ¬e) ∧ (e ∨ f ∨ ¬g) ∧ (g ∨ h ∨ ¬i) ∧ (i ∨ j ∨ ¬a)",
                   " ⊕ ".join("abcdefghij"), "(a→b)∧(b→c)∧(c→d)∧(d→e)∧(e→f)∧(f→g)∧(g→h)∧(h→i)∧(i→j)"]
        for formula in formule:
            for tipo in ("FND", "FNC"):
                with self.subTest(formula=formula, tipo=tipo):
                    inizio = time.perf_counter()
                    r = M.minimizza(formula, tipo)
                    self.assertLess(time.perf_counter() - inizio, 8)
                    self.assertTrue(M.are_equivalent(formula, r["risultato"]))
                    conta(self)
        with self.assertRaises(M.FormulaError):
            M.minimizza(" ∧ ".join(f"x{i}" for i in range(1, 12)))
        conta(self)

    def test_codice_gray(self):
        self.assertEqual(M.codice_gray(0), [""])
        self.assertEqual(M.codice_gray(1), ["0", "1"])
        self.assertEqual(M.codice_gray(2), ["00", "01", "11", "10"])
        for bit in (1, 2, 3):
            codici = M.codice_gray(bit)
            for a, b in zip(codici, codici[1:] + codici[:1]):
                self.assertEqual(sum(x != y for x, y in zip(a, b)), 1)
        conta(self, 4)


class TestKarnaugh(unittest.TestCase):
    def controlla(self, formula, tipo):
        k = M.mappa_karnaugh(formula, tipo)
        nomi = k["variabili"]
        n = len(nomi)
        _, righe = M.truth_table(formula, max_variabili=None)
        attesi_mappe = {1: 1, 2: 1, 3: 1, 4: 1, 5: 2, 6: 4}[n]
        self.assertEqual(len(k["mappe"]), attesi_mappe)
        visti = set()
        cercato = 1 if tipo == "FND" else 0
        for mappa in k["mappe"]:
            for r, riga in enumerate(mappa["celle"]):
                for c, cella in enumerate(riga):
                    visti.add(cella["numero"])
                    # il valore della cella è quello della tavola (riga = 2^n - 1 - numero)
                    valore = righe[(1 << n) - 1 - cella["numero"]][-1] == "V"
                    self.assertEqual(cella["valore"], int(valore))
                    for g in cella["gruppi"]:
                        self.assertEqual(cella["valore"], cercato)
                    if cella["valore"] == cercato:
                        self.assertTrue(cella["gruppi"], "una cella da coprire è rimasta fuori")
            # i rettangoli coprono esattamente le celle di ogni gruppo
            for g in range(len(k["gruppi"])):
                dai_rettangoli = {(r, c) for gg, r0, r1, c0, c1 in mappa["rettangoli"] if gg == g
                                  for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)}
                dalle_celle = {(r, c) for r, riga in enumerate(mappa["celle"])
                               for c, cella in enumerate(riga) if g in cella["gruppi"]}
                self.assertEqual(dai_rettangoli, dalle_celle)
        self.assertEqual(visti, set(range(1 << n)))
        self.assertEqual(k["risultato"], M.minimizza(formula, tipo)["risultato"])
        return k

    def test_mappe(self):
        formule = ["p", "¬p", "p → q", "p ⊕ q", "(p ∧ q) ∨ r", "p ↔ q ↔ r", "(p ∧ q) ∨ (r ∧ s)", "p ⊕ q ⊕ r ⊕ s",
                   "(p ∨ ¬q) ∧ (r → s)", "a ⊕ b ⊕ c ∨ (d ∧ e)", "(a ∧ e) ∨ (¬a ∧ ¬e ∧ c)",
                   "(a ∧ b) ∨ (c ∧ d) ∨ (e ∧ f)", "(a → f) ∧ (b ⊕ e)", "p ∨ ¬p", "p ∧ ¬p ∧ q"]
        for formula in formule:
            for tipo in ("FND", "FNC"):
                with self.subTest(formula=formula, tipo=tipo):
                    self.controlla(formula, tipo)
                    conta(self)

    def test_gruppo_che_gira_sul_bordo(self):
        # ¬q ∧ ¬s in una mappa 4×4 sono i quattro angoli: 4 rettangoli separati
        k = self.controlla("¬q ∧ ¬s ∧ (p ∨ ¬p) ∧ (r ∨ ¬r)", "FND")
        self.assertEqual(len(k["gruppi"]), 1)
        self.assertEqual(len(k["mappe"][0]["rettangoli"]), 4)
        self.assertEqual(k["variabili_righe"], ["p", "q"])
        self.assertEqual(k["variabili_colonne"], ["r", "s"])
        conta(self, 2)

    def test_errori(self):
        with self.assertRaises(M.FormulaError):
            M.mappa_karnaugh("⊤")
        with self.assertRaises(M.FormulaError):
            M.mappa_karnaugh("a ∧ b ∧ c ∧ d ∧ e ∧ f ∧ g")
        conta(self, 2)


def piccioni(piccioni_, buchi):
    """Ogni piccione in un buco, mai due nello stesso buco: impossibile se i piccioni sono di più."""
    clausole = [" ∨ ".join(f"p{i}_{j}" for j in range(buchi)) for i in range(piccioni_)]
    clausole += [f"¬p{i}_{j} ∨ ¬p{k}_{j}" for j in range(buchi)
                 for i in range(piccioni_) for k in range(i + 1, piccioni_)]
    return " ∧ ".join(f"({c})" for c in clausole)


class TestSAT(unittest.TestCase):
    def test_confronto_con_la_tavola(self):
        rnd = random.Random(55)
        for numero in range(500):
            albero = formula_casuale(rnd, rnd.randint(1, 6), ["p", "q", "r", "s", "t", "u"])
            testo = scrivi_minimo(albero, rnd)
            with self.subTest(numero=numero, testo=testo):
                r = M.sat(testo)
                self.assertEqual(r["soddisfacibile"], M.classifica(testo) != "contraddizione")
                if r["soddisfacibile"]:
                    self.assertTrue(M.evaluate(testo, r["modello"]))
                conta(self)

    def test_analisi_sat_uguale_alla_tavola(self):
        rnd = random.Random(8)
        for numero in range(150):
            albero = formula_casuale(rnd, rnd.randint(1, 5), ["p", "q", "r", "s"])
            testo = scrivi_minimo(albero, rnd)
            with self.subTest(numero=numero, testo=testo):
                tavola, risolutore = M.analizza(testo), M.analizza(testo, max_variabili=0)
                self.assertEqual(risolutore["metodo"], "sat")
                self.assertEqual(tavola["classificazione"], risolutore["classificazione"])
                if risolutore["controesempio"] is not None:
                    self.assertFalse(M.evaluate(testo, risolutore["controesempio"]))
                    nomi = risolutore["variabili"]
                    self.assertEqual(M.assegnazione(nomi, risolutore["riga_controesempio"] - 1),
                                     risolutore["controesempio"])
                if risolutore["esempio"] is not None:
                    self.assertTrue(M.evaluate(testo, risolutore["esempio"]))
                conta(self)

    def test_equivalenza_e_conseguenza_sat(self):
        for a, b in EQUIVALENTI + NON_EQUIVALENTI:
            with self.subTest(a=a, b=b):
                r = M.compare(a, b, max_variabili=0)
                self.assertEqual(r["equivalenti"], M.are_equivalent(a, b))
                if not r["equivalenti"]:
                    valori, va, vb = r["controesempio"]
                    self.assertNotEqual(M.evaluate(a, valori), M.evaluate(b, valori))
                conta(self)
        casi = [(["p → q", "p"], "q"), (["p → q", "q"], "p"), (["p", "¬p"], "q"), ([], "p ∨ ¬p"), ([], "p"),
                (["p ∨ q", "¬p"], "q"), (["p → q", "¬p"], "¬q")]
        for premesse, conclusione in casi:
            with self.subTest(premesse=premesse, conclusione=conclusione):
                r = M.consequence(premesse, conclusione, max_variabili=0)
                self.assertEqual(r["valida"], M.consequence(premesse, conclusione)["valida"])
                for valori, vp, vc in r["controesempi"]:
                    self.assertTrue(all(vp))
                    self.assertFalse(vc)
                conta(self)
        self.assertEqual(M.consequence(["p", "¬p"], "q", max_variabili=0)["righe_critiche"], 0)
        conta(self)

    def test_problemi_classici(self):
        for n in (4, 5, 6, 7):
            with self.subTest(piccioni=n):
                self.assertIs(M.sat(piccioni(n, n - 1))["soddisfacibile"], False)
                self.assertIs(M.sat(piccioni(n, n))["soddisfacibile"], True)
                conta(self)
        rnd = random.Random(3)
        for variabili in (40, 80):
            clausole = [" ∨ ".join(("" if rnd.random() < .5 else "¬") + f"x{rnd.randint(1, variabili)}"
                                   for _ in range(3)) for _ in range(int(variabili * 4.26))]
            r = M.sat(" ∧ ".join(f"({c})" for c in clausole))
            self.assertIn(r["soddisfacibile"], (True, False))
            conta(self)

    def test_formule_con_tante_variabili(self):
        nomi = [f"x{i}" for i in range(1, 101)]
        inizio = time.perf_counter()
        de_morgan = "¬(" + " ∧ ".join(nomi) + ") ↔ (" + " ∨ ".join("¬" + n for n in nomi) + ")"
        r = M.analizza(de_morgan)
        self.assertEqual((r["classificazione"], r["metodo"], r["controesempio"]), ("tautologia", "sat", None))
        self.assertEqual(r["righe"], 2 ** 100)
        r = M.analizza(" ∨ ".join(nomi))
        self.assertEqual(r["classificazione"], "contingente")
        self.assertIsNone(r["righe_vere"])
        self.assertFalse(any(r["controesempio"].values()))
        self.assertEqual(r["riga_controesempio"], 2 ** 100)
        r = M.analizza(" ∧ ".join(nomi) + " ∧ ¬x50")
        self.assertEqual(r["classificazione"], "contraddizione")
        catena = [f"{a} → {b}" for a, b in zip(nomi, nomi[1:])]
        self.assertTrue(M.consequence(catena + ["x1"], "x100")["valida"])
        r = M.consequence(catena, "x1")
        self.assertFalse(r["valida"])
        self.assertIsNone(r["numero_controesempi"])
        valori, vp, vc = r["controesempi"][0]
        self.assertTrue(all(vp) and not vc)
        r = M.compare(" ∨ ".join(nomi), " ∨ ".join(nomi[:-1]))
        self.assertFalse(r["equivalenti"])
        self.assertTrue(r["controesempio"][0]["x100"])
        self.assertTrue(M.compare(" ∧ ".join(nomi), " ∧ ".join(reversed(nomi)))["equivalenti"])
        self.assertLess(time.perf_counter() - inizio, 20)
        conta(self, 9)

    def test_limite_della_tavola(self):
        with self.assertRaises(M.TroppeVariabili) as c:
            M.truth_table("a ∧ b ∧ c ∧ d ∧ e ∧ f")
        self.assertEqual((c.exception.variabili, c.exception.massimo), (6, 5))
        self.assertIn("64 righe", str(c.exception))
        with self.assertRaises(M.TroppeVariabili) as c:
            M.compare(" ∧ ".join(f"x{i}" for i in range(1, 22)), "x1", usa_sat=False)
        self.assertTrue(str(c.exception).startswith("Il confronto ha 21 variabili"))
        self.assertIn("2.097.152 righe", str(c.exception))
        conta(self, 2)


class TestTavolaPaginata(unittest.TestCase):
    def test_pagine_uguali_alla_tavola(self):
        rnd = random.Random(12)
        for numero in range(60):
            albero = formula_casuale(rnd, rnd.randint(1, 5), ["p", "q", "r", "s", "t", "u"])
            testo = scrivi_minimo(albero, rnd)
            intestazione, righe = M.truth_table(testo, max_variabili=None)
            tavola = M.TavolaPaginata(testo)
            self.assertEqual(tavola.intestazione, intestazione)
            for filtro in M.FILTRI:
                for dimensione in (1, 7, 50):
                    with self.subTest(numero=numero, filtro=filtro, dimensione=dimensione):
                        attese = [(i + 1, riga) for i, riga in enumerate(righe)
                                  if filtro == "tutte" or (riga[-1] == "V") == (filtro == "vere")]
                        lette = []
                        for pagina in range(1, tavola.pagine(dimensione, filtro) + 1):
                            lette += tavola.pagina(pagina, dimensione, filtro)
                        self.assertEqual(lette, attese)
                        self.assertEqual(tavola.conta(filtro), len(attese))
                        conta(self)

    def test_solo_formula_finale(self):
        tavola = M.TavolaPaginata("(p → q) ∧ ¬r", sottoformule=False)
        self.assertEqual(tavola.intestazione, ["p", "q", "r", "(p → q) ∧ ¬r"])
        self.assertEqual(M.TavolaPaginata("p", sottoformule=False).intestazione, ["p"])
        self.assertEqual(M.TavolaPaginata("⊤").pagina(1), [(1, ["V"])])
        conta(self, 3)

    def test_un_milione_di_righe(self):
        nomi = [f"x{i}" for i in range(1, 21)]
        formula = " ∧ ".join(f"({n} ∨ ¬{n})" for n in nomi) + " ∧ (x1 → x20) ∧ (x5 ⊕ x9)"
        inizio = time.perf_counter()
        tavola = M.TavolaPaginata(formula)
        self.assertEqual(tavola.righe, 2 ** 20)
        self.assertEqual(tavola.vere, M.analizza(formula)["righe_vere"])
        for filtro in M.FILTRI:
            ultima = tavola.pagina(tavola.pagine(50, filtro), 50, filtro)
            self.assertTrue(ultima)
            for numero, valori in tavola.pagina(1234, 50, filtro):
                self.assertTrue(filtro == "tutte" or (valori[-1] == "V") == (filtro == "vere"))
        self.assertEqual(tavola.pagina(tavola.pagine(50) + 1), [])
        self.assertEqual(tavola.pagina_della_riga(51), 2)
        self.assertLess(time.perf_counter() - inizio, 5)
        with self.assertRaises(M.TroppeVariabili):
            M.TavolaPaginata(" ∧ ".join(f"x{i}" for i in range(1, 22)))
        conta(self, 4)


PREDICATI_LETTURE = [
    ("∀x (Uomo(x) → Mortale(x))", "∀x (Uomo(x) → Mortale(x))"),
    ("forall x exists y Ama(x, y)", "∀x ∃y Ama(x, y)"),
    ("FORALL x EXISTS y Ama(x,y)", "∀x ∃y Ama(x, y)"),
    ("∀x,y (R(x,y) -> R(y,x))", "∀x ∀y (R(x, y) → R(y, x))"),
    ("∀x. P(x) → Q(x)", "∀x (P(x) → Q(x))"),
    ("∀x: P(x) & Q(x)", "∀x (P(x) ∧ Q(x))"),
    ("∀x P(x) → Q(x)", "∀x P(x) → Q(x)"),
    ("¬∃x P(x)", "¬∃x P(x)"),
    ("∃x ¬P(x)", "∃x ¬P(x)"),
    ("∀x ∃y (y != x)", "∀x ∃y (y ≠ x)"),
    ("∀x ∃y y /= x", "∀x ∃y (y ≠ x)"),
    ("x = y", "x = y"),
    ("Uomo(socrate) ∧ Uomo(platone)", "Uomo(socrate) ∧ Uomo(platone)"),
    ("P(1) ∨ P(2)", "P(1) ∨ P(2)"),
    ("Piove → ∀x Bagnato(x)", "Piove → ∀x Bagnato(x)"),
    ("F(x) ∧ V(x)", "F(x) ∧ V(x)"),
    ("(∀x P(x)) ∨ (∀x Q(x))", "∀x P(x) ∨ ∀x Q(x)"),
    ("∀x (P(x) ∧ (Q(x) ∨ R(x, x)))", "∀x (P(x) ∧ (Q(x) ∨ R(x, x)))"),
    ("∃x (P(x) ∧ ∀y (Q(y) → R(x, y)))", "∃x (P(x) ∧ ∀y (Q(y) → R(x, y)))"),
    ("∀x ⊤", "∀x ⊤"),
]

PREDICATI_ERRORI = [
    ("", "vuota"), ("∀x (P(x) ∧", "finisce troppo presto"), ("P(x,)", "virgola"), ("P(x", "chiusi"),
    ("∀ (P(x))", "variabile"), ("∀", "finisce troppo presto"), ("P(x) ∧ P(x, y)", "stesso numero"),
    ("P(x) Q(x)", "connettivo"), ("P(x))", "in più"), ("()", "vuote"), ("3", "numero"), ("x =", "argomento"),
    ("P(x) ∧ x(P)", "sia come predicato"), ("P(x) # Q", "«#»"),
]

VALIDE_NEI_DOMINI_FINITI = [
    "∀x P(x) → ∃x P(x)",
    "∀x P(x) → P(a)",
    "P(a) → ∃x P(x)",
    "¬∀x P(x) ↔ ∃x ¬P(x)",
    "¬∃x P(x) ↔ ∀x ¬P(x)",
    "∀x (P(x) ∧ Q(x)) ↔ (∀x P(x) ∧ ∀x Q(x))",
    "∃x (P(x) ∨ Q(x)) ↔ (∃x P(x) ∨ ∃x Q(x))",
    "(∀x P(x) ∨ ∀x Q(x)) → ∀x (P(x) ∨ Q(x))",
    "∃x (P(x) ∧ Q(x)) → (∃x P(x) ∧ ∃x Q(x))",
    "∃y ∀x R(x, y) → ∀x ∃y R(x, y)",
    "(∀x (P(x) → Q(x)) ∧ ∀x P(x)) → ∀x Q(x)",
    "(Uomo(socrate) ∧ ∀x (Uomo(x) → Mortale(x))) → Mortale(socrate)",
    "∀x (x = x)",
    "∀x ∀y (x = y → (P(x) → P(y)))",
    "∃x (P(x) → ∀y P(y))",
]

NON_VALIDE = [
    "∃x P(x) → ∀x P(x)",
    "∀x (P(x) ∨ Q(x)) → (∀x P(x) ∨ ∀x Q(x))",
    "(∃x P(x) ∧ ∃x Q(x)) → ∃x (P(x) ∧ Q(x))",
    "∀x ∃y R(x, y) → ∃y ∀x R(x, y)",
    "∀x ∀y (R(x, y) → R(y, x))",
    "∀x R(x, x)",
    "∃x ∃y (x ≠ y)",
    "(∀x (P(x) → Q(x)) ∧ Q(a)) → P(a)",
    "∀x (P(x) → Q(x)) → ∀x (Q(x) → P(x))",
]


def predicato_casuale(rnd, profondita, legate):
    """Formula chiusa casuale con P, Q (un argomento), R (due argomenti) e l'uguaglianza."""
    if profondita == 0 or (legate and rnd.random() < 0.25):
        if not legate:
            return rnd.choice(["⊤", "⊥", "S"])
        scelta = rnd.random()
        if scelta < 0.35:
            return f"{rnd.choice('PQ')}({rnd.choice(legate)})"
        if scelta < 0.75:
            return f"R({rnd.choice(legate)}, {rnd.choice(legate)})"
        if scelta < 0.85:
            return "S"
        return f"({rnd.choice(legate)} {rnd.choice(['=', '≠'])} {rnd.choice(legate)})"
    caso = rnd.random()
    if caso < 0.35 or not legate:
        v = rnd.choice(["x", "y", "z"])
        return f"{rnd.choice(['∀', '∃'])}{v} ({predicato_casuale(rnd, profondita - 1, legate + [v])})"
    if caso < 0.5:
        return f"¬({predicato_casuale(rnd, profondita - 1, legate)})"
    op = rnd.choice(["∧", "∨", "→", "↔", "⊕"])
    return (f"({predicato_casuale(rnd, profondita - 1, legate)}) {op} "
            f"({predicato_casuale(rnd, profondita - 1, legate)})")


class TestPredicati(unittest.TestCase):
    def test_letture(self):
        for testo, atteso in PREDICATI_LETTURE:
            with self.subTest(testo=testo):
                formula = M.leggi_predicati(testo)
                self.assertEqual(formula.testo, atteso)
                # riletta, la formula riscritta è la stessa
                self.assertEqual(M.leggi_predicati(formula.testo).testo, atteso)
                conta(self)

    def test_dati_della_formula(self):
        f = M.leggi_predicati("Uomo(socrate) ∧ ∀x (Uomo(x) → Mortale(x)) ∧ Piove")
        self.assertEqual(f.predicati, {"Uomo": 1, "Mortale": 1, "Piove": 0})
        self.assertEqual(f.costanti, {"socrate"})
        self.assertTrue(f.quantificata)
        self.assertEqual(f.avvisi, [])
        self.assertTrue(M.leggi_predicati("∀ P(x)").avvisi)
        self.assertEqual(M.leggi_predicati("∀x P(x) → Q(x)").costanti, {"x"})
        conta(self, 6)

    def test_errori(self):
        for testo, pezzo in PREDICATI_ERRORI:
            with self.subTest(testo=testo):
                with self.assertRaises(M.FormulaError) as c:
                    M.leggi_predicati(testo)
                self.assertIn(pezzo, str(c.exception))
                conta(self)

    def test_modelli_noti(self):
        dominio = ["a", "b", "c"]
        ama = {"Ama": {("a", "b"), ("b", "c"), ("c", "a")}}
        casi = [
            ("∀x ∃y Ama(x, y)", ama, True), ("∃y ∀x Ama(x, y)", ama, False),
            ("∀x ∀y (Ama(x, y) → Ama(y, x))", ama, False), ("∀x ¬Ama(x, x)", ama, True),
            ("∃x Ama(x, x)", ama, False), ("∀x ∃y (y ≠ x ∧ Ama(x, y))", ama, True),
            ("Ama(a, b) ∧ ¬Ama(b, a)", ama, True),
            ("∀x (Uomo(x) → Mortale(x))", {"Uomo": {("a",)}, "Mortale": {("a",), ("b",)}}, True),
            ("∀x (Uomo(x) → Mortale(x))", {"Uomo": {("a",), ("c",)}, "Mortale": {("a",)}}, False),
            ("Piove → ∀x Bagnato(x)", {"Piove": True, "Bagnato": {("a",), ("b",)}}, False),
            ("Piove → ∀x Bagnato(x)", {"Piove": False}, True),
            ("∃x ∃y (x ≠ y)", {}, True), ("∀x ∀y (x = y)", {}, False),
        ]
        for formula, interpretazione, atteso in casi:
            with self.subTest(formula=formula):
                r = M.valuta_predicati(formula, dominio, interpretazione)
                self.assertIs(r["valore"], atteso)
                self.assertTrue(r["spiegazione"])
                self.assertIn("vera" if atteso else "falsa", r["spiegazione"][0])
                conta(self)
        self.assertIs(M.valuta_predicati("∀x ∀y (x = y)", ["solo"], {})["valore"], True)
        conta(self)

    def test_spiegazione_con_controesempio(self):
        r = M.valuta_predicati("∀x (Uomo(x) → Mortale(x))", ["a", "b", "c"],
                               {"Uomo": {("a",), ("c",)}, "Mortale": {("a",)}})
        self.assertIn("non vale per x = c", r["spiegazione"][0])
        self.assertIn("Uomo(c) → Mortale(c)", r["spiegazione"][1])
        r = M.valuta_predicati("∃x Mortale(x)", ["a", "b"], {"Mortale": {("b",)}})
        self.assertIn("per esempio x = b", r["spiegazione"][0])
        conta(self, 3)

    def test_errori_del_modello(self):
        with self.assertRaises(M.FormulaError) as c:
            M.valuta_predicati("∀x P(x) → Q(x)", ["a"], {})
        self.assertIn("parentesi", str(c.exception))
        with self.assertRaises(M.FormulaError) as c:
            M.valuta_predicati("Uomo(socrate)", ["a"], {})
        self.assertIn("non è un elemento del dominio", str(c.exception))
        with self.assertRaises(M.FormulaError):
            M.valuta_predicati("P(a)", ["a"], {"P": {("z",)}})
        conta(self, 3)

    def test_confronto_con_la_traduzione_proposizionale(self):
        """Due calcoli indipendenti: la verifica diretta e la formula tradotta sul dominio."""
        rnd = random.Random(21)
        for numero in range(300):
            testo = predicato_casuale(rnd, rnd.randint(1, 4), [])
            dominio = ["a", "b", "c"][:rnd.randint(1, 3)]
            interpretazione = {
                "P": {(e,) for e in dominio if rnd.random() < 0.5},
                "Q": {(e,) for e in dominio if rnd.random() < 0.5},
                "R": {(a, b) for a in dominio for b in dominio if rnd.random() < 0.5},
                "S": rnd.random() < 0.5,
            }
            with self.subTest(numero=numero, testo=testo, dominio=dominio):
                formula = M.leggi_predicati(testo)
                diretto = M.valuta_predicati(formula, dominio, interpretazione)["valore"]
                tradotta = M._radica(formula.radice, dominio, M._Costruttore())
                valori = {}
                for nome in M.variables(tradotta):
                    if "(" in nome:
                        predicato, argomenti = nome[:-1].split("(")
                        valori[nome] = tuple(argomenti.split(",")) in interpretazione[predicato]
                    else:
                        valori[nome] = interpretazione[nome]
                self.assertEqual(diretto, M.evaluate(tradotta, valori))
                conta(self)

    def test_ricerca_di_controesempi(self):
        for formula in VALIDE_NEI_DOMINI_FINITI:
            with self.subTest(formula=formula):
                self.assertIsNone(M.cerca_modello(formula, vera=False, max_elementi=3))
                self.assertIsNotNone(M.cerca_modello(formula, vera=True, max_elementi=3))
                conta(self)
        for formula in NON_VALIDE:
            with self.subTest(formula=formula):
                trovato = M.cerca_modello(formula, vera=False, max_elementi=3)
                self.assertIsNotNone(trovato)
                r = M.valuta_predicati(formula, trovato["dominio"], trovato["interpretazione"])
                self.assertFalse(r["valore"])
                conta(self)
        self.assertIsNone(M.cerca_modello(
            "Uomo(socrate) ∧ ∀x (Uomo(x) → Mortale(x)) ∧ ¬Mortale(socrate)", vera=True))
        # il controesempio più piccolo ha due elementi
        self.assertEqual(M.cerca_modello("∃x ∃y (x ≠ y)", vera=True)["elementi"], 2)
        conta(self, 2)

    def test_domini_e_relazioni(self):
        self.assertEqual(M.leggi_dominio("a, b, c"), ["a", "b", "c"])
        self.assertEqual(M.leggi_dominio("{1, 2, 3, 2}"), ["1", "2", "3"])
        self.assertEqual(M.leggi_dominio("anna bruno"), ["anna", "bruno"])
        for sbagliato in ("", "   ", "{}", "a, b-c"):
            with self.assertRaises(M.FormulaError):
                M.leggi_dominio(sbagliato)
        dominio = ["a", "b", "c"]
        self.assertEqual(M.leggi_relazione("a, c", 1, dominio), {("a",), ("c",)})
        self.assertEqual(M.leggi_relazione("{(a, b), (b,c)}", 2, dominio), {("a", "b"), ("b", "c")})
        self.assertEqual(M.leggi_relazione("", 2, dominio), set())
        self.assertIs(M.leggi_relazione("V", 0, dominio), True)
        for testo, arita in (("z", 1), ("(a, b, c)", 2), ("a, b", 2), ("(a, z)", 2), ("forse", 0)):
            with self.assertRaises(M.FormulaError):
                M.leggi_relazione(testo, arita, dominio)
        for valori, arita in (({("a",), ("c",)}, 1), ({("a", "b"), ("b", "c")}, 2), (True, 0)):
            testo = M.testo_relazione(valori, arita)
            self.assertEqual(M.leggi_relazione(testo, arita, dominio), valori)
        conta(self, 17)


ARGOMENTI_VALIDI = [
    (["p → q", "p"], "q"), (["p → q", "¬q"], "¬p"), (["p → q", "q → r"], "p → r"), (["p ∨ q", "¬p"], "q"),
    (["p ∧ q"], "q ∧ p"), (["p"], "p ∨ q"), (["p", "¬p"], "q"), ([], "p ∨ ¬p"), ([], "¬(p ∧ ¬p)"),
    (["¬(p ∧ q)"], "¬p ∨ ¬q"), (["¬p ∨ ¬q"], "¬(p ∧ q)"), (["¬(p ∨ q)"], "¬p ∧ ¬q"), (["¬¬p"], "p"),
    (["p ↔ q", "p"], "q"), (["p → q", "q → p"], "p ↔ q"), (["p ↔ q"], "¬(p ⊕ q)"), (["p ⊕ q", "p"], "¬q"),
    (["p ↑ q"], "¬p ∨ ¬q"), (["¬(p ↓ q)"], "p ∨ q"), ([], "((p → q) → p) → p"), (["p → (q → r)"], "(p ∧ q) → r"),
    (["(p ∧ q) → r"], "p → (q → r)"), (["p ∨ q", "p → r", "q → r"], "r"), (["¬(p → q)"], "p ∧ ¬q"),
    (["p → q"], "¬q → ¬p"), (["¬q → ¬p"], "p → q"), ([], "⊤"), (["⊥"], "p"), (["p ∨ (q ∧ r)"], "(p ∨ q) ∧ (p ∨ r)"),
    (["¬(p ↔ q)"], "p ⊕ q"), (["p ↔ q", "q ↔ r"], "p ↔ r"),
]


class TestDeduzioneNaturale(unittest.TestCase):
    def controlla(self, premesse, conclusione):
        r = M.deduzione_naturale(premesse, conclusione)
        self.assertTrue(r["valida"])
        self.assertEqual(M.controlla_deduzione(r["righe"], r["premesse"], r["conclusione"]), [])
        ultima = r["righe"][-1]
        self.assertEqual((ultima["livello"], ultima["testo"]), (0, r["conclusione"]))
        for riga in r["righe"]:
            self.assertIn(riga["regola"], M.REGOLE_DEDUZIONE)
        return r

    def test_argomenti_classici(self):
        for premesse, conclusione in ARGOMENTI_VALIDI:
            with self.subTest(premesse=premesse, conclusione=conclusione):
                self.controlla(premesse, conclusione)
                conta(self)

    def test_dimostrazioni_brevi_per_i_casi_semplici(self):
        self.assertEqual(len(self.controlla(["p → q", "p"], "q")["righe"]), 3)
        self.assertEqual([r["regola"] for r in self.controlla(["p → q", "q → r"], "p → r")["righe"]],
                         ["Premessa", "Premessa", "Ipotesi", "→E", "→E", "→I"])
        self.assertEqual(self.controlla(["p → q", "¬q"], "¬p")["righe"][-1]["regola"], "¬I")
        conta(self, 3)

    def test_tautologie(self):
        for f in TAUTOLOGIE:
            with self.subTest(formula=f):
                self.controlla([], f)
                conta(self)

    def test_formule_casuali(self):
        rnd = random.Random(77)
        provate = 0
        while provate < 200:
            nomi = ["p", "q", "r"]
            premesse = [scrivi_minimo(formula_casuale(rnd, rnd.randint(1, 3), nomi), rnd)
                        for _ in range(rnd.randint(0, 3))]
            conclusione = scrivi_minimo(formula_casuale(rnd, rnd.randint(1, 3), nomi), rnd)
            if not M.consequence(premesse, conclusione)["valida"]:
                r = M.deduzione_naturale(premesse, conclusione)
                self.assertFalse(r["valida"])
                self.assertEqual(r["righe"], [])
                continue
            provate += 1
            with self.subTest(premesse=premesse, conclusione=conclusione):
                self.controlla(premesse, conclusione)
                conta(self)

    def test_argomenti_non_validi(self):
        for premesse, conclusione in [(["p → q", "q"], "p"), (["p → q", "¬p"], "¬q"), ([], "p"), (["p ∨ q"], "p")]:
            with self.subTest(premesse=premesse, conclusione=conclusione):
                r = M.deduzione_naturale(premesse, conclusione)
                self.assertFalse(r["valida"])
                valori = r["controesempio"]
                self.assertTrue(all(M.evaluate(x, valori) for x in premesse))
                self.assertFalse(M.evaluate(conclusione, valori))
                conta(self)

    def test_il_verificatore_trova_gli_errori(self):
        r = self.controlla(["p → q", "q → r"], "p → r")
        righe = r["righe"]

        def guasta(modifica):
            copia = [dict(x, riferimenti=list(x["riferimenti"])) for x in righe]
            modifica(copia)
            return M.controlla_deduzione(copia, r["premesse"], r["conclusione"])

        casi = [
            lambda c: c[3].update(regola="∧E"),                       # regola sbagliata
            lambda c: c[3].update(riferimenti=[2, 3]),                # righe sbagliate
            lambda c: c[4].update(testo="q"),                         # formula sbagliata
            lambda c: c[5].update(riferimenti=[(3, 4)]),              # sottodimostrazione sbagliata
            lambda c: c[2].update(ipotesi=False, regola="Premessa"),  # ipotesi spacciata per premessa
            lambda c: c.append(dict(c[4], numero=7, livello=0)),      # uso di una riga chiusa
            lambda c: c[5].update(testo="p → q"),                     # conclusione sbagliata
        ]
        for i, modifica in enumerate(casi):
            with self.subTest(caso=i):
                self.assertTrue(guasta(modifica))
                conta(self)


class TestTableaux(unittest.TestCase):
    def test_proposizionali_contro_la_tavola(self):
        rnd = random.Random(31)
        for numero in range(300):
            nomi = ["p", "q", "r", "s"]
            premesse = [scrivi_minimo(formula_casuale(rnd, rnd.randint(1, 3), nomi), rnd)
                        for _ in range(rnd.randint(0, 2))]
            conclusione = scrivi_minimo(formula_casuale(rnd, rnd.randint(1, 4), nomi), rnd)
            with self.subTest(numero=numero, premesse=premesse, conclusione=conclusione):
                r = M.tableau(premesse, conclusione)
                valida = M.consequence(premesse, conclusione)["valida"]
                self.assertEqual(r["chiuso"], valida)
                self.assertTrue(r["concluso"])
                if not valida:
                    valori = dict.fromkeys(M.variables(" ∧ ".join(["⊤"] + [f"({x})" for x in premesse]
                                                                  + [f"({conclusione})"])), False)
                    valori.update(r["controesempio"]["valori"])
                    self.assertTrue(all(M.evaluate(x, valori) for x in premesse))
                    self.assertFalse(M.evaluate(conclusione, valori))
                conta(self)

    def test_struttura_dell_albero(self):
        r = M.tableau(["p → q", "p"], "q")
        albero = r["albero"]
        self.assertEqual([f["testo"] for f in albero["formule"]], ["p → q", "p", "¬q"])
        self.assertEqual(albero["formule"][2]["regola"], "negazione della conclusione")
        self.assertEqual(len(albero["figli"]), 2)
        self.assertEqual([f["testo"] for f in albero["figli"][0]["formule"]], ["¬p"])
        self.assertEqual(albero["figli"][0]["formule"][0]["da"], 1)
        self.assertTrue(all(f["stato"] == "chiuso" for f in albero["figli"]))
        self.assertIn("¬p", albero["figli"][0]["motivo"])
        numeri = []
        pila = [albero]
        while pila:
            nodo = pila.pop()
            numeri += [f["numero"] for f in nodo["formule"]]
            pila.extend(nodo["figli"])
        self.assertEqual(sorted(numeri), list(range(1, len(numeri) + 1)))
        conta(self, 7)

    def test_predicati_validi(self):
        for formula in VALIDE_NEI_DOMINI_FINITI:
            if "=" in formula and "x = x" not in formula:
                continue   # l'uguaglianza tra termini diversi non è gestita dai tableaux
            with self.subTest(formula=formula):
                r = M.tableau([], formula)
                self.assertTrue(r["chiuso"])
                conta(self)
        r = M.tableau(["∀x (Uomo(x) → Mortale(x))", "Uomo(socrate)"], "Mortale(socrate)")
        self.assertTrue(r["chiuso"] and r["predicati"])
        conta(self)

    def test_predicati_non_validi(self):
        for formula in NON_VALIDE:
            with self.subTest(formula=formula):
                r = M.tableau([], formula)
                self.assertFalse(r["chiuso"])
                modello = r["controesempio"]
                self.assertIsNotNone(modello)
                self.assertFalse(M.valuta_predicati(formula, modello["dominio"], modello["interpretazione"])["valore"])
                conta(self)

    def test_errori(self):
        with self.assertRaises(M.FormulaError) as c:
            M.tableau(["p ∧"], "q")
        self.assertTrue(str(c.exception).startswith("Premessa 1"))
        with self.assertRaises(M.FormulaError) as c:
            M.tableau([], "∀x (P(x)")
        self.assertTrue(str(c.exception).startswith("Conclusione"))
        conta(self, 2)


class TestCircuiti(unittest.TestCase):
    def stesso_comportamento(self, circ, formula):
        nomi = M.variables(formula)
        for r in range(1 << len(nomi)):
            valori = M.assegnazione(nomi, r)
            completi = dict.fromkeys(circ["variabili"], False) | valori
            self.assertEqual(M.valuta_circuito(circ, completi)[1], M.evaluate(formula, valori))

    def test_circuito_uguale_alla_formula(self):
        rnd = random.Random(88)
        for numero in range(250):
            testo = scrivi_minimo(formula_casuale(rnd, rnd.randint(1, 5), ["p", "q", "r", "s"]), rnd)
            for solo in (None, "NAND", "NOR"):
                with self.subTest(numero=numero, testo=testo, solo=solo):
                    circ = M.circuito(testo, solo)
                    self.stesso_comportamento(circ, testo)
                    if solo:
                        self.assertTrue(set(circ["conteggio"]) <= {solo})
                    for porta in circ["porte"]:
                        self.assertIn(porta["tipo"], M.PORTE)
                        self.assertEqual(len(porta["ingressi"]) == 1, porta["tipo"] == "NOT")
                        self.assertLessEqual(len(porta["ingressi"]), M.MAX_INGRESSI_PORTA)
                        for tipo, v in porta["ingressi"]:
                            if tipo == "porta":
                                self.assertLess(v, porta["numero"])   # ogni porta usa solo porte precedenti
                    conta(self)

    def test_dal_testo_e_ritorno(self):
        rnd = random.Random(89)
        for numero in range(150):
            testo = scrivi_minimo(formula_casuale(rnd, rnd.randint(1, 5), ["p", "q", "r"]), rnd)
            with self.subTest(numero=numero, testo=testo):
                circ = M.circuito(testo)
                riletto = M.leggi_circuito(M.testo_circuito(circ))
                self.assertTrue(M.are_equivalent(testo, riletto["formula"]))
                self.stesso_comportamento(riletto, testo)
                conta(self)

    def test_esempi(self):
        c = M.circuito("(p → q) ∧ ¬r")
        self.assertEqual(c["conteggio"], {"NOT": 2, "OR": 1, "AND": 1})
        self.assertEqual(c["profondita"], 3)
        self.assertEqual(M.circuito("a ∧ b ∧ c ∧ d")["conteggio"], {"AND": 1})
        self.assertEqual(len(M.circuito("a ∧ b ∧ c ∧ d")["porte"][0]["ingressi"]), 4)
        self.assertEqual(M.circuito("(a ∧ b) ∨ (a ∧ b)")["conteggio"], {"AND": 1, "OR": 1})
        self.assertEqual(M.circuito("p ↔ q")["conteggio"], {"XNOR": 1})
        self.assertEqual(M.circuito("p ⊕ q", "NAND")["conteggio"], {"NAND": 4})
        self.assertEqual(M.circuito("¬p", "NOR")["conteggio"], {"NOR": 1})
        self.assertEqual(M.circuito("p")["uscita"], ("var", "p"))
        self.assertEqual(M.circuito("p")["porte"], [])
        semiaddizionatore = M.leggi_circuito("s = XOR(a, b)\nc = AND(a, b)\nuscita = OR(s, c)")
        self.assertEqual(semiaddizionatore["formula"], "(a ⊕ b) ∨ (a ∧ b)")
        self.assertTrue(M.are_equivalent(semiaddizionatore["formula"], "a ∨ b"))
        conta(self, 12)

    def test_lettura_del_testo(self):
        c = M.leggi_circuito("# commento\n\nuscita = nand(x, y, z)\n")
        self.assertEqual(c["formula"], "¬(x ∧ y ∧ z)")
        c = M.leggi_circuito("uscita = OR(g1, 0)\ng1 = NOT(a)")      # ordine qualsiasi
        self.assertEqual(c["formula"], "¬a ∨ ⊥")
        c = M.leggi_circuito("g1 = AND(a, b)\ng2 = OR(a, b)\nuscita = XNOR(g1, c, g2)")
        self.assertTrue(M.are_equivalent(c["formula"], "¬((a ∧ b) ⊕ c ⊕ (a ∨ b))"))
        c = M.leggi_circuito("g1 = AND(a, b)\nuscita = NOT(a)")
        self.assertEqual(c["inutilizzate"], ["g1"])
        self.assertEqual(M.leggi_circuito("y = E(a, b)")["formula"], "a ∧ b")
        conta(self, 5)

    def test_errori_del_testo(self):
        casi = [("g1 = FOO(a, b)", "non è una porta"), ("g1 = NOT(a, b)", "un solo ingresso"),
                ("g1 = AND(a)", "almeno due"), ("g1 = AND(g2, a)\ng2 = OR(g1, b)", "anello"),
                ("ciao", "Riga 1"), ("", "vuoto"), ("g1 = AND(a, b)\ng1 = OR(a, b)", "già definita"),
                ("g1 = AND(a, b-c)", "non è un ingresso"), ("x = AND(a, b)\n\ny = NOT(", "Riga 3")]
        for testo, pezzo in casi:
            with self.subTest(testo=testo):
                with self.assertRaises(M.FormulaError) as c:
                    M.leggi_circuito(testo)
                self.assertIn(pezzo, str(c.exception))
                conta(self)


def bilanciato(testo, aperta="{", chiusa="}"):
    profondita = 0
    i = 0
    while i < len(testo):
        if testo[i] == "\\":   # \{ e \} non contano
            i += 2
            continue
        if testo[i] == aperta:
            profondita += 1
        elif testo[i] == chiusa:
            profondita -= 1
            if profondita < 0:
                return False
        i += 1
    return profondita == 0


class TestEsportazioneTesto(unittest.TestCase):
    def test_formule_in_latex(self):
        casi = [("(p → q) ∧ ¬r", r"(p \to q )\land \lnot r"), ("p ↔ q", r"p \leftrightarrow q"),
                ("Pioggia", r"\mathit{Pioggia}"), ("x_1", r"\mathit{x\_1}"), ("∀x ∃y (y ≠ x)", r"\forall x \exists y (y \neq x )"),
                ("p ⊕ q ↑ r ↓ s", r"p \oplus q \uparrow r \downarrow s"), ("⊤ ∨ ⊥", r"\top \lor \bot")]
        for testo, atteso in casi:
            with self.subTest(testo=testo):
                self.assertEqual(M.latex_formula(testo), atteso)
                conta(self)

    def test_formule_casuali_solo_ascii(self):
        rnd = random.Random(90)
        for numero in range(200):
            testo = M.to_text(scrivi_minimo(formula_casuale(rnd, rnd.randint(1, 5), ["p", "q", "r", "Pioggia"]), rnd))
            with self.subTest(testo=testo):
                latex = M.latex_formula(testo)
                self.assertTrue(latex.isascii())
                self.assertTrue(bilanciato(latex))
                self.assertNotIn("?", latex)
                conta(self)

    def test_testo_protetto(self):
        self.assertEqual(M.latex_testo("100% & _#"), r"100\% \& \_\#")
        self.assertEqual(M.latex_testo("p ∧ q"), r"p $\land$ q")
        self.assertEqual(M.latex_testo("{a}"), r"\{a\}")
        conta(self, 3)

    def test_tavola(self):
        intestazione, righe = M.truth_table("(p -> q) & !r")
        latex = M.latex_tavola(intestazione, righe)
        self.assertTrue(latex.startswith(r"\begin{tabular}{ccc|ccc}"))
        self.assertEqual(latex.count(r"\\"), len(righe) + 1)
        testo = M.csv_tavola(intestazione, righe)
        lette = list(csv.reader(io.StringIO(testo), delimiter=";"))
        self.assertEqual(lette, [intestazione] + righe)
        self.assertIn("p → q", testo)
        conta(self, 4)

    def test_passaggi_deduzione_tableau_karnaugh_circuito(self):
        pezzi = [
            M.latex_passaggi(M.forma_normale_passo_passo("¬(p ∧ q) → r")),
            M.latex_deduzione(M.deduzione_naturale(["¬(p ∧ q)"], "¬p ∨ ¬q")["righe"]),
            M.latex_tableau(M.tableau(["∀x (Uomo(x) → Mortale(x))", "Uomo(socrate)"], "Mortale(socrate)")["albero"]),
            M.latex_karnaugh(M.mappa_karnaugh("(a ∧ b) ∨ (c ∧ d) ∨ (e ∧ f)")),
            M.latex_circuito(M.circuito("(p → q) ∧ ¬r")),
        ]
        for numero, latex in enumerate(pezzi):
            with self.subTest(numero=numero):
                self.assertTrue(latex.isascii() or "è" in latex or "à" in latex or "ù" in latex)
                self.assertTrue(bilanciato(latex))
                conta(self)
        self.assertTrue(bilanciato(pezzi[2], "[", "]"))
        self.assertEqual(pezzi[1].count(r"\\"), 25)
        self.assertEqual(pezzi[3].count(r"\begin{tabular}"), 4)
        documento = M.documento_latex(pezzi[2], "Tableau di Socrate", ["forest"])
        self.assertIn(r"\usepackage{forest}", documento)
        self.assertTrue(documento.index(r"\begin{document}") < documento.index(r"\end{document}"))
        conta(self, 5)


class TestAlbero(unittest.TestCase):
    def test_albero(self):
        radice = M.tree("(p -> q) & !r")
        self.assertEqual((radice["label"], radice["kind"], radice["text"]), ("∧", "op", "(p → q) ∧ ¬r"))
        self.assertEqual([f["label"] for f in radice["children"]], ["→", "¬"])
        self.assertEqual(M.tree_depth(radice), 3)
        self.assertEqual(M.tree("p")["kind"], "var")
        self.assertEqual(M.tree("p ↑ q")["name"], "congiunzione negata (NAND)")
        # sottoformula ripetuta: due nodi distinti nel disegno
        doppia = M.tree("(p ∧ q) ∨ (p ∧ q)")
        self.assertIsNot(doppia["children"][0], doppia["children"][1])
        with self.assertRaises(M.FormulaError):
            M.tree("¬" * 100 + "p")
        conta(self, 7)

    def test_sottoformule(self):
        self.assertEqual([M.to_text(s) for s in M.subformulas("(p → q) ∧ ¬r")], ["p → q", "¬r", "(p → q) ∧ ¬r"])
        self.assertEqual(M.subformulas("p"), [])
        conta(self, 2)


class TestAiutiInterfaccia(unittest.TestCase):
    def test_leggi_valore(self):
        casi = [("V", True), ("v", True), (" vero ", True), ("T", True), ("true", True), ("1", True), ("⊤", True),
                ("F", False), ("f", False), ("Falso", False), ("false", False), ("0", False), ("⊥", False),
                ("", None), ("x", None), ("p ∧ q", None)]
        for testo, atteso in casi:
            with self.subTest(testo=testo):
                self.assertIs(M.leggi_valore(testo), atteso)
                conta(self)

    def test_converti_simboli(self):
        casi = [("p->q", "p→q"), ("p<->q", "p↔q"), ("p<=>q", "p↔q"), ("p=>q", "p⇒q"), ("p&q", "p∧q"),
                ("p|q", "p∨q"), ("!p", "¬p"), ("~p", "¬p"), ("p^q", "p∧q"), ("p∧&q", "p∧q"), ("p∨|q", "p∨q")]
        for testo, atteso in casi:
            with self.subTest(testo=testo):
                self.assertEqual(M.converti_simboli(testo), atteso)
                # il testo convertito si legge come quello originale
                # (∧& e ∨| sono gli stati intermedi mentre si scrive && e ||)
                originale = testo.replace("∧&", "&&").replace("∨|", "||")
                self.assertEqual(M.to_text(atteso), M.to_text(originale))
                conta(self)


class TestControlloIncrociato(unittest.TestCase):
    """Centinaia di formule casuali: il motore deve dare gli stessi valori di un calcolo indipendente."""

    def test_formule_casuali(self):
        rnd = random.Random(2026)
        nomi = ["p", "q", "r", "s"]
        for numero in range(400):
            albero = formula_casuale(rnd, rnd.randint(1, 5), nomi)
            testo = scrivi_minimo(albero, rnd)
            with self.subTest(numero=numero, testo=testo):
                presenti = M.variables(testo)
                colonna = M.colonna(testo, presenti)
                for r in range(1 << len(presenti)):
                    valori = M.assegnazione(presenti, r)
                    completi = dict.fromkeys(nomi, False) | valori
                    self.assertEqual(bool((colonna >> r) & 1), valuta_riferimento(albero, completi))
                # riscrivere la formula e rileggerla non cambia nulla
                self.assertTrue(M.are_equivalent(testo, M.to_text(testo)))
                conta(self)

    def test_tutte_le_coppie_di_connettivi(self):
        """Ogni coppia di connettivi binari scritta senza parentesi segue la tabella delle precedenze."""
        for op1, op2 in itertools.product(LIVELLO, repeat=2):
            testo = f"p {op1} q {op2} r"
            l1, l2 = LIVELLO[op1], LIVELLO[op2]
            if l1 > l2 or (l1 == l2 and op2 != "→"):
                atteso = (op2, (op1, ("var", "p"), ("var", "q")), ("var", "r"))
            elif l1 == l2 and op1 == "→" and op2 == "→":
                atteso = (op1, ("var", "p"), (op2, ("var", "q"), ("var", "r")))
            elif l1 == l2:
                atteso = (op2, (op1, ("var", "p"), ("var", "q")), ("var", "r"))
            else:
                atteso = (op1, ("var", "p"), (op2, ("var", "q"), ("var", "r")))
            with self.subTest(testo=testo):
                for r in range(8):
                    valori = M.assegnazione(["p", "q", "r"], r)
                    self.assertEqual(M.evaluate(testo, valori), valuta_riferimento(atteso, valori))
                conta(self)


def tearDownModule():
    print(f"\nCasi verificati: {CASI[0]}")


if __name__ == "__main__":
    unittest.main(verbosity=1)
