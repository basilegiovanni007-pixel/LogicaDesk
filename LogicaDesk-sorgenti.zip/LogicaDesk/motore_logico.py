# motore_logico.py - motore di calcolo della logica proposizionale di LogicaDesk
#
# Questo file deve restare IDENTICO in LogicaDesk e in LogicaDesk Pro:
# se lo modifichi in una cartella, copialo anche nell'altra.
# Non contiene codice grafico: solo Python puro (nessuna libreria esterna).
"""Motore logico di LogicaDesk.

COME SI SCRIVONO LE FORMULE

  Connettivo                  Si può scrivere anche
  ¬  negazione                not  non  !  ~
  ∧  congiunzione             and  &  &&  ^
  ∨  disgiunzione             or   |  ||
  ⊕  disgiunzione esclusiva   xor  ⊻
  ↑  NAND                     nand
  ↓  NOR                      nor
  →  implicazione             ->  =>  ⇒  ⊃
  ↔  doppia implicazione      <->  <=>  ⇔  ≡  iff
  ⊤  vero                     V  1  vero  true
  ⊥  falso                    F  0  falso  false

  Le parole (and, or, not, vero...) si possono scrivere in maiuscolo o minuscolo.
  V e F maiuscole sono le costanti vero e falso; v e f minuscole sono variabili.

  Le variabili iniziano con una lettera e possono contenere lettere, numeri,
  il trattino basso e l'apostrofo: p, q, p1, p10, A, Pioggia, x_2, p'.

PRECEDENZA (dal legame più forte al più debole)

  ¬   poi   ∧ ↑   poi   ⊕   poi   ∨ ↓   poi   →   poi   ↔

  Così  ¬p ∧ q ∨ r → s  si legge  (((¬p) ∧ q) ∨ r) → s.
  → è associativa a destra:  p → q → r  vale  p → (q → r).
  Gli altri connettivi si raggruppano da sinistra:  p ↑ q ↑ r  vale  (p ↑ q) ↑ r.
  Nel dubbio usa le parentesi: si possono annidare a qualsiasi profondità.

COME FUNZIONA

  Il testo viene diviso in simboli (tokenizzatore), poi trasformato in un albero
  (parser) e infine calcolato. Tutte le righe della tavola si calcolano insieme:
  ogni colonna è un numero intero in cui il bit i vale 1 se la colonna è vera
  nella riga i. Per questo il calcolo è esatto e molto veloce.
  Nessuna funzione usa la ricorsione sulla formula: anche formule lunghissime
  o molto annidate non bloccano il programma.
"""

import bisect
import csv
import heapq
import io
import itertools
import re
import time

VERSIONE_MOTORE = "1.0"

MAX_VARIABILI = 5            # tavola di verità mostrata nella finestra principale
MAX_VARIABILI_ANALISI = 20   # analisi, equivalenza e conseguenza logica (oltre un milione di righe)
LIMITE_RIGHE_ELENCO = 1024  # oltre questo numero di righe non si elencano tutte
LIMITE_SECONDI_SAT = 10       # tempo massimo del risolutore SAT per ogni domanda
MAX_VARIABILI_FORME = 6      # forme normali
MAX_LIVELLI_ALBERO = 60      # albero disegnato

# ---------- connettivi ----------

NEG, AND, OR, XOR, NAND, NOR, IMP, IFF = "¬", "∧", "∨", "⊕", "↑", "↓", "→", "↔"
BINARI = (AND, OR, XOR, NAND, NOR, IMP, IFF)

# più è alto il numero, più il connettivo lega forte
PRECEDENZA = {AND: 5, NAND: 5, XOR: 4, OR: 3, NOR: 3, IMP: 2, IFF: 1}
ASSOCIATIVI_A_DESTRA = {IMP}
# quando si riscrive una formula, le catene di questi connettivi non hanno parentesi interne
CATENE_SENZA_PARENTESI = {AND, OR}

NOMI_CONNETTIVI = {
    NEG: "negazione", AND: "congiunzione", OR: "disgiunzione", XOR: "disgiunzione esclusiva",
    NAND: "congiunzione negata (NAND)", NOR: "disgiunzione negata (NOR)",
    IMP: "implicazione", IFF: "doppia implicazione",
}

# simboli scritti con la tastiera: si prova sempre prima la sequenza più lunga
_SIMBOLI = {
    "¬": NEG, "!": NEG, "~": NEG,
    "∧": AND, "&": AND, "&&": AND, "^": AND,
    "∨": OR, "|": OR, "||": OR,
    "⊕": XOR, "⊻": XOR,
    "↑": NAND,
    "↓": NOR,
    "→": IMP, "->": IMP, "=>": IMP, "⇒": IMP, "⊃": IMP,
    "↔": IFF, "<->": IFF, "<=>": IFF, "⇔": IFF, "≡": IFF,
    "(": "(", ")": ")",
    "⊤": True, "⊥": False,
}
_SIMBOLI_PER_LUNGHEZZA = sorted(_SIMBOLI, key=len, reverse=True)

# parole riservate (maiuscole o minuscole)
_PAROLE = {
    "not": NEG, "non": NEG, "and": AND, "or": OR, "xor": XOR, "nand": NAND, "nor": NOR, "iff": IFF,
    "vero": True, "true": True, "falso": False, "false": False,
}
# costanti scritte con una sola lettera maiuscola
_COSTANTI_MAIUSCOLE = {"V": True, "F": False}

# suggerimenti per i caratteri che gli studenti scrivono più spesso per sbaglio
_SUGGERIMENTI = {
    "+": "per «o» usa ∨ oppure |",
    "*": "per «e» usa ∧ oppure &",
    "·": "per «e» usa ∧ oppure &",
    "=": "per l'equivalenza usa ↔ oppure <->",
    "<": "per l'equivalenza usa ↔ oppure <->",
    ">": "per l'implicazione usa → oppure ->",
    "-": "per l'implicazione usa → oppure ->; per la negazione usa ¬ oppure !",
    "[": "usa le parentesi tonde ( )",
    "]": "usa le parentesi tonde ( )",
    "{": "usa le parentesi tonde ( )",
    "}": "usa le parentesi tonde ( )",
}

# conversione dei simboli mentre si scrive in un campo formula (l'ordine conta)
ALIAS_TASTIERA = (
    ("<->", "↔"), ("<=>", "↔"), ("->", "→"), ("=>", "⇒"),
    ("∧&", "∧"), ("∨|", "∨"), ("&", "∧"), ("|", "∨"), ("^", "∧"), ("!", "¬"), ("~", "¬"),
)


class FormulaError(Exception):
    """Formula scritta male. `posizione` è l'indice (da 0) del carattere sbagliato, se si conosce."""

    def __init__(self, messaggio, posizione=None, lunghezza=1):
        super().__init__(messaggio)
        self.messaggio = messaggio
        self.posizione = posizione
        self.lunghezza = max(1, lunghezza)

    @property
    def carattere(self):
        """Posizione per l'utente: il primo carattere è il numero 1."""
        return None if self.posizione is None else self.posizione + 1

    def con_prefisso(self, prefisso):
        return FormulaError(f"{prefisso}: {self.messaggio}", self.posizione, self.lunghezza)


class TroppeVariabili(FormulaError):
    """La tavola sarebbe troppo grande: `variabili` è quante ne ha la formula, `massimo` il limite."""

    def __init__(self, messaggio, variabili, massimo):
        super().__init__(messaggio)
        self.variabili = variabili
        self.massimo = massimo

    def con_prefisso(self, prefisso):
        return TroppeVariabili(f"{prefisso}: {self.messaggio}", self.variabili, self.massimo)


def numero_leggibile(n):
    """1048576 -> «1.048.576» (come si scrive in italiano)."""
    return f"{n:,}".replace(",", ".")


def _al_carattere(posizione):
    return f"al carattere {posizione + 1}"


# ---------- tokenizzatore ----------

class Token:
    __slots__ = ("tipo", "valore", "posizione", "testo")

    def __init__(self, tipo, valore, posizione, testo):
        self.tipo = tipo            # "var", "const", "op", "(", ")"
        self.valore = valore        # nome, True/False oppure il simbolo del connettivo
        self.posizione = posizione  # indice del primo carattere nel testo
        self.testo = testo          # come l'ha scritto l'utente

    def __repr__(self):
        return f"Token({self.tipo!r}, {self.valore!r}, {self.posizione})"


def _carattere_di_nome(ch):
    return ch.isalnum() or ch in "_'"


def tokenize(testo):
    """Divide il testo in simboli. Solleva FormulaError con la posizione dell'errore."""
    tokens = []
    i, n = 0, len(testo)
    while i < n:
        ch = testo[i]
        if ch.isspace():
            i += 1
            continue
        for simbolo in _SIMBOLI_PER_LUNGHEZZA:
            if testo.startswith(simbolo, i):
                valore = _SIMBOLI[simbolo]
                if simbolo in "()":
                    tipo = simbolo
                elif isinstance(valore, bool):
                    tipo = "const"
                else:
                    tipo = "op"
                tokens.append(Token(tipo, valore, i, simbolo))
                i += len(simbolo)
                break
        else:
            if ch.isdigit():
                j = i
                while j < n and _carattere_di_nome(testo[j]):
                    j += 1
                parola = testo[i:j]
                if parola in ("0", "1"):
                    tokens.append(Token("const", parola == "1", i, parola))
                else:
                    raise FormulaError(f"«{parola}» {_al_carattere(i)} non è valido: i nomi delle variabili "
                                       f"devono iniziare con una lettera (per esempio p1). "
                                       f"Come costanti si possono usare solo 1 e 0.", i, j - i)
                i = j
            elif ch.isalpha() or ch == "_":
                j = i + 1
                while j < n and _carattere_di_nome(testo[j]):
                    j += 1
                parola = testo[i:j]
                chiave = parola.casefold()
                if chiave in _PAROLE:
                    valore = _PAROLE[chiave]
                    tipo = "const" if isinstance(valore, bool) else "op"
                    tokens.append(Token(tipo, valore, i, parola))
                elif parola in _COSTANTI_MAIUSCOLE:
                    tokens.append(Token("const", _COSTANTI_MAIUSCOLE[parola], i, parola))
                else:
                    tokens.append(Token("var", parola, i, parola))
                i = j
            else:
                messaggio = f"Simbolo «{ch}» non riconosciuto {_al_carattere(i)}"
                if ch in _SUGGERIMENTI:
                    messaggio += f" ({_SUGGERIMENTI[ch]})"
                raise FormulaError(messaggio + ".", i)
    return tokens


# ---------- albero della formula ----------

class Formula:
    """Un nodo dell'albero: una variabile, una costante o un connettivo con i suoi argomenti.

    Le sottoformule uguali dentro la stessa formula sono lo stesso oggetto,
    quindi si possono confrontare con «is».
    """
    __slots__ = ("op", "figli", "nome", "valore")

    def __init__(self, op, figli=(), nome=None, valore=None):
        self.op = op          # "var", "const" oppure il simbolo del connettivo
        self.figli = figli    # tupla di Formula (vuota per variabili e costanti)
        self.nome = nome      # nome della variabile
        self.valore = valore  # True/False per le costanti

    def __repr__(self):
        return f"Formula({to_text(self)!r})"

    def __str__(self):
        return to_text(self)


class _Costruttore:
    """Crea i nodi riusando quelli già esistenti (sottoformule uguali = stesso oggetto)."""

    def __init__(self):
        self.nodi = {}

    def nodo(self, op, figli=(), nome=None, valore=None):
        chiave = (op, nome, valore) + tuple(id(f) for f in figli)
        trovato = self.nodi.get(chiave)
        if trovato is None:
            trovato = self.nodi[chiave] = Formula(op, tuple(figli), nome, valore)
        return trovato


def _descrivi(token):
    return f"«{token.testo}»"


def parse(testo):
    """Legge una formula e restituisce il suo albero (Formula). Solleva FormulaError se è scritta male."""
    if isinstance(testo, Formula):
        return testo
    tokens = tokenize(testo)
    if not tokens:
        raise FormulaError("La formula è vuota.")
    costruttore = _Costruttore()
    uscita = []       # formule già costruite
    operatori = []    # connettivi e parentesi aperte in attesa (token)
    precedente = None
    serve_formula = True  # True quando ci si aspetta una variabile, una costante, ¬ oppure «(»

    def applica(token):
        if token.valore == NEG:
            argomento = uscita.pop()
            uscita.append(costruttore.nodo(NEG, (argomento,)))
        else:
            destra = uscita.pop()
            sinistra = uscita.pop()
            uscita.append(costruttore.nodo(token.valore, (sinistra, destra)))

    for token in tokens:
        pos = token.posizione
        if serve_formula:
            if token.tipo == "var":
                uscita.append(costruttore.nodo("var", nome=token.valore))
                serve_formula = False
            elif token.tipo == "const":
                uscita.append(costruttore.nodo("const", valore=token.valore))
                serve_formula = False
            elif token.tipo == "(" or (token.tipo == "op" and token.valore == NEG):
                operatori.append(token)
            elif token.tipo == ")":
                if precedente is None:
                    raise FormulaError(f"Parentesi chiusa «)» {_al_carattere(pos)} senza una parentesi aperta "
                                       f"prima.", pos)
                if precedente.tipo == "(":
                    raise FormulaError(f"Parentesi vuote «()» {_al_carattere(precedente.posizione)}: "
                                       f"dentro le parentesi manca una formula.", precedente.posizione, 2)
                raise FormulaError(f"Manca una formula dopo {_descrivi(precedente)} "
                                   f"{_al_carattere(precedente.posizione)}.", precedente.posizione,
                                   len(precedente.testo))
            else:  # connettivo binario dove serviva una formula
                if precedente is None:
                    raise FormulaError(f"La formula non può iniziare con {_descrivi(token)} {_al_carattere(pos)}: "
                                       f"prima del connettivo manca una formula.", pos, len(token.testo))
                if precedente.tipo == "(":
                    raise FormulaError(f"Dopo la parentesi aperta manca una formula prima di {_descrivi(token)} "
                                       f"{_al_carattere(pos)}.", pos, len(token.testo))
                raise FormulaError(f"Due connettivi di seguito: {_descrivi(precedente)} e {_descrivi(token)} "
                                   f"{_al_carattere(pos)}. Tra i due manca una formula.", pos, len(token.testo))
        else:
            if token.tipo == "op" and token.valore != NEG:
                livello = PRECEDENZA[token.valore]
                while operatori and operatori[-1].tipo == "op":
                    cima = operatori[-1]
                    livello_cima = 99 if cima.valore == NEG else PRECEDENZA[cima.valore]
                    if livello_cima > livello or (livello_cima == livello
                                                  and token.valore not in ASSOCIATIVI_A_DESTRA):
                        applica(operatori.pop())
                    else:
                        break
                operatori.append(token)
                serve_formula = True
            elif token.tipo == ")":
                while operatori and operatori[-1].tipo != "(":
                    applica(operatori.pop())
                if not operatori:
                    raise FormulaError(f"Parentesi chiusa «)» in più {_al_carattere(pos)}: "
                                       f"non c'è una parentesi aperta da chiudere.", pos)
                operatori.pop()
            else:  # due formule vicine senza connettivo
                messaggio = (f"Manca un connettivo tra {_descrivi(precedente)} e {_descrivi(token)} "
                             f"{_al_carattere(pos)}")
                if token.tipo == "var" and token.valore in ("v", "o"):
                    messaggio += " (per «o» usa ∨ oppure |)"
                elif token.tipo == "var" and token.valore == "e":
                    messaggio += " (per «e» usa ∧ oppure &)"
                raise FormulaError(messaggio + ".", pos, len(token.testo))
        precedente = token

    if serve_formula:
        if precedente.tipo == "(":
            raise FormulaError(f"La formula finisce con una parentesi aperta {_al_carattere(precedente.posizione)}.",
                               precedente.posizione)
        raise FormulaError(f"La formula finisce troppo presto: dopo {_descrivi(precedente)} "
                           f"{_al_carattere(precedente.posizione)} manca una formula.",
                           precedente.posizione, len(precedente.testo))
    aperte = [t for t in operatori if t.tipo == "("]
    if aperte:
        if len(aperte) == 1:
            raise FormulaError(f"Parentesi non chiusa {_al_carattere(aperte[0].posizione)}: manca «)».",
                               aperte[0].posizione)
        elenco = ", ".join(str(t.posizione + 1) for t in aperte[:-1]) + f" e {aperte[-1].posizione + 1}"
        raise FormulaError(f"{len(aperte)} parentesi non chiuse (ai caratteri {elenco}): mancano altrettante «)».",
                           aperte[0].posizione)
    while operatori:
        applica(operatori.pop())
    return uscita[0]


# ---------- visite dell'albero (senza ricorsione) ----------

def _postordine(radice):
    """Tutti i nodi diversi, ogni figlio prima del padre, da sinistra a destra."""
    visti = set()
    ordine = []
    pila = [(radice, False)]
    while pila:
        nodo, pronto = pila.pop()
        if pronto:
            if id(nodo) not in visti:
                visti.add(id(nodo))
                ordine.append(nodo)
            continue
        if id(nodo) in visti:
            continue
        pila.append((nodo, True))
        for figlio in reversed(nodo.figli):
            pila.append((figlio, False))
    return ordine


def _chiave_naturale(nome):
    """Ordine «umano»: p1, p2, p10 (non p1, p10, p2); a parità di lettere, maiuscola prima."""
    parti = re.split(r"([0-9]+)", nome)
    return [int(p) if i % 2 else (p.casefold(), p) for i, p in enumerate(parti)]


def ordina_variabili(nomi):
    return sorted(set(nomi), key=_chiave_naturale)


def variables(formula):
    """Nomi delle variabili in ordine alfabetico naturale (p, q, r, p1, p2, p10...)."""
    radice = parse(formula)
    return ordina_variabili(n.nome for n in _postordine(radice) if n.op == "var")


def subformulas(formula):
    """Sottoformule composte in ordine di calcolo, senza ripetizioni: l'ultima è la formula intera.

    Se la formula è una sola variabile o costante, la lista è vuota.
    """
    return [n for n in _postordine(parse(formula)) if n.op not in ("var", "const")]


def _testi(radice):
    """Per ogni nodo (tramite id) il testo da usare quando sta dentro un'altra formula."""
    testi = {}
    for nodo in _postordine(radice):
        if nodo.op == "var":
            testo = nodo.nome
        elif nodo.op == "const":
            testo = "⊤" if nodo.valore else "⊥"
        elif nodo.op == NEG:
            testo = NEG + testi[id(nodo.figli[0])]
        else:
            sinistra, destra = nodo.figli
            testo_sinistra = testi[id(sinistra)]
            # catene di ∧ o di ∨ raggruppate da sinistra: p ∧ q ∧ r invece di (p ∧ q) ∧ r
            if sinistra.op == nodo.op and nodo.op in CATENE_SENZA_PARENTESI:
                testo_sinistra = testo_sinistra[1:-1]
            testo = f"({testo_sinistra} {nodo.op} {testi[id(destra)]})"
        testi[id(nodo)] = testo
    return testi


def _senza_parentesi_esterne(nodo, testo):
    return testo[1:-1] if nodo.op in BINARI else testo


def to_text(formula, top=True):
    """La formula scritta con i simboli logici e con tutte le parentesi necessarie."""
    radice = parse(formula)
    testo = _testi(radice)[id(radice)]
    return _senza_parentesi_esterne(radice, testo) if top else testo


def profondita(formula):
    """Numero di livelli dell'albero (una variabile da sola ha 1 livello)."""
    livelli = {}
    for nodo in _postordine(parse(formula)):
        livelli[id(nodo)] = 1 + max((livelli[id(f)] for f in nodo.figli), default=0)
    return livelli[id(parse(formula))]


# ---------- calcolo ----------

def _applica(op, valori, pieno):
    """Calcola un connettivo su colonne intere (bit i = valore nella riga i)."""
    if op == NEG:
        return pieno ^ valori[0]
    a, b = valori
    if op == AND:
        return a & b
    if op == OR:
        return a | b
    if op == XOR:
        return a ^ b
    if op == NAND:
        return pieno ^ (a & b)
    if op == NOR:
        return pieno ^ (a | b)
    if op == IMP:
        return (pieno ^ a) | b
    return pieno ^ (a ^ b)  # IFF


def colonna_variabile(indice, quante):
    """Colonna della variabile numero `indice` su `quante`: la prima riga è tutta vera.

    Come nei libri: la prima variabile cambia ogni metà tavola, l'ultima a ogni riga.
    """
    blocco = 1 << (quante - 1 - indice)          # righe vere consecutive
    periodo = 2 * blocco
    righe = 1 << quante
    return ((1 << blocco) - 1) * (((1 << righe) - 1) // ((1 << periodo) - 1))


def calcola(formula, nomi=None):
    """Calcola tutte le righe insieme.

    Restituisce (nomi, righe, colonne): `colonne` associa ogni nodo (tramite id) alla sua colonna,
    un intero in cui il bit i vale 1 se il nodo è vero nella riga i (riga 0 = tutte le variabili vere).
    """
    radice = parse(formula)
    if nomi is None:
        nomi = variables(radice)
    quante = len(nomi)
    righe = 1 << quante
    pieno = (1 << righe) - 1
    indice = {nome: i for i, nome in enumerate(nomi)}
    colonne = {}
    for nodo in _postordine(radice):
        if nodo.op == "var":
            colonne[id(nodo)] = colonna_variabile(indice[nodo.nome], quante)
        elif nodo.op == "const":
            colonne[id(nodo)] = pieno if nodo.valore else 0
        else:
            colonne[id(nodo)] = _applica(nodo.op, [colonne[id(f)] for f in nodo.figli], pieno)
    return nomi, righe, colonne


def colonna(formula, nomi=None):
    """Solo la colonna finale della formula (vedi `calcola`)."""
    radice = parse(formula)
    nomi, righe, colonne = calcola(radice, nomi)
    return colonne[id(radice)]


def evaluate(formula, valori):
    """Valore della formula (True/False) per un'assegnazione {nome: True/False}."""
    radice = parse(formula)
    risultati = {}
    for nodo in _postordine(radice):
        if nodo.op == "var":
            if nodo.nome not in valori:
                raise FormulaError(f"Manca il valore della variabile «{nodo.nome}».")
            risultati[id(nodo)] = bool(valori[nodo.nome])
        elif nodo.op == "const":
            risultati[id(nodo)] = nodo.valore
        else:
            risultati[id(nodo)] = bool(_applica(nodo.op, [int(risultati[id(f)]) for f in nodo.figli], 1))
    return risultati[id(radice)]


def assegnazione(nomi, riga):
    """Valori delle variabili nella riga numero `riga` (da 0) della tavola."""
    quante = len(nomi)
    return {nome: not (riga >> (quante - 1 - i)) & 1 for i, nome in enumerate(nomi)}


def _controlla_variabili(nomi, massimo, che_cosa):
    if massimo is not None and len(nomi) > massimo:
        raise TroppeVariabili(f"{che_cosa} ha {len(nomi)} variabili: la tavola avrebbe "
                              f"{numero_leggibile(2 ** len(nomi))} righe. Il massimo è {massimo} variabili "
                              f"({numero_leggibile(2 ** massimo)} righe).", len(nomi), massimo)


def truth_table(formula, max_variabili=MAX_VARIABILI):
    """Tavola di verità: (intestazione, righe) con valori "V"/"F".

    Prima le variabili, poi una colonna per ogni sottoformula composta (dalla più interna);
    l'ultima colonna è sempre la formula intera.
    """
    radice = parse(formula)
    nomi = variables(radice)
    _controlla_variabili(nomi, max_variabili, "La formula")
    nomi, quante_righe, colonne = calcola(radice, nomi)
    composte = subformulas(radice)
    if radice.op == "const":
        composte = [radice]
    indice = {nome: i for i, nome in enumerate(nomi)}
    valori_colonne = [colonna_variabile(indice[n], len(nomi)) for n in nomi]
    valori_colonne += [colonne[id(c)] for c in composte]
    testi = _testi(radice)
    intestazione = list(nomi) + [_senza_parentesi_esterne(c, testi[id(c)]) for c in composte]
    righe = [["V" if (c >> r) & 1 else "F" for c in valori_colonne] for r in range(quante_righe)]
    return intestazione, righe


VERDETTI = {
    "tautologia": "Tautologia",
    "contraddizione": "Contraddizione",
    "contingente": "Contingente (a volte vera, a volte falsa)",
}


def classify(righe):
    """Verdetto a partire dalle righe di `truth_table` (guarda l'ultima colonna)."""
    risultati = [riga[-1] for riga in righe]
    if all(r == "V" for r in risultati):
        return VERDETTI["tautologia"]
    if all(r == "F" for r in risultati):
        return VERDETTI["contraddizione"]
    return VERDETTI["contingente"]


def classifica(formula):
    """"tautologia", "contraddizione" oppure "contingente"."""
    radice = parse(formula)
    nomi, righe, colonne = calcola(radice)
    valore = colonne[id(radice)]
    if valore == (1 << righe) - 1:
        return "tautologia"
    if valore == 0:
        return "contraddizione"
    return "contingente"


def _leggi(testo, prefisso):
    try:
        return parse(testo)
    except FormulaError as errore:
        raise errore.con_prefisso(prefisso) from None


def are_equivalent(formula_a, formula_b):
    a, b = _leggi(formula_a, "Formula A"), _leggi(formula_b, "Formula B")
    nomi = ordina_variabili(variables(a) + variables(b))
    return colonna(a, nomi) == colonna(b, nomi)


def _indici(maschera, limite=None):
    """Numeri (da 0) delle righe in cui una colonna è vera, in ordine; al massimo `limite`."""
    indici = []
    while maschera and (limite is None or len(indici) < limite):
        bit = maschera & -maschera
        indici.append(bit.bit_length() - 1)
        maschera ^= bit
    return indici


def _prima_riga(maschera):
    """Numero (da 0) della prima riga in cui la colonna è vera, oppure None."""
    return (maschera & -maschera).bit_length() - 1 if maschera else None


def descrivi_assegnazione(valori, nomi=None):
    """«p = V, q = F»: i valori delle variabili scritti per l'utente."""
    nomi = list(valori) if nomi is None else nomi
    return ", ".join(f"{n} = {'V' if valori[n] else 'F'}" for n in nomi)


def analizza(formula, max_variabili=MAX_VARIABILI_ANALISI, usa_sat=True, limite_secondi=LIMITE_SECONDI_SAT):
    """Analisi completa di una formula, senza costruire la tavola riga per riga.

    Restituisce un dizionario con:
      formula             la formula riscritta con i simboli logici
      variabili, righe    i nomi delle variabili e quante righe ha la tavola
      classificazione     "tautologia", "contraddizione" oppure "contingente"
      verdetto            lo stesso, come lo scrive `classify`
      righe_vere, righe_false   in quante righe è vera / falsa
      soddisfacibile      True se almeno una riga la rende vera
      controesempio       valori delle variabili che la rendono falsa (None se è una tautologia)
      riga_controesempio  numero della riga (da 1) del controesempio
      esempio             valori che la rendono vera (None se è una contraddizione)
      riga_esempio        numero della riga (da 1) dell'esempio
      metodo              "tavola" oppure "sat"

    Con più di `max_variabili` variabili (e `usa_sat` vero) si usa il risolutore SAT: la risposta
    è esatta, ma righe_vere e righe_false sono None (si conoscono solo per tautologie e contraddizioni).
    """
    radice = parse(formula)
    nomi = variables(radice)
    if usa_sat and len(nomi) > max_variabili:
        return _analizza_sat(radice, nomi, limite_secondi)
    _controlla_variabili(nomi, max_variabili, "La formula")
    valore = colonna(radice, nomi)
    righe = 1 << len(nomi)
    falsa = ((1 << righe) - 1) ^ valore
    vere = bin(valore).count("1")
    riga_falsa, riga_vera = _prima_riga(falsa), _prima_riga(valore)
    if vere == righe:
        classificazione = "tautologia"
    elif vere == 0:
        classificazione = "contraddizione"
    else:
        classificazione = "contingente"
    return {
        "formula": to_text(radice),
        "variabili": nomi,
        "righe": righe,
        "classificazione": classificazione,
        "verdetto": VERDETTI[classificazione],
        "righe_vere": vere,
        "righe_false": righe - vere,
        "soddisfacibile": vere > 0,
        "controesempio": None if riga_falsa is None else assegnazione(nomi, riga_falsa),
        "riga_controesempio": None if riga_falsa is None else riga_falsa + 1,
        "esempio": None if riga_vera is None else assegnazione(nomi, riga_vera),
        "riga_esempio": None if riga_vera is None else riga_vera + 1,
        "metodo": "tavola",
    }


def compare(formula_a, formula_b, max_variabili=MAX_VARIABILI_ANALISI, usa_sat=True,
            limite_secondi=LIMITE_SECONDI_SAT):
    """Confronta due formule riga per riga.

    Restituisce un dizionario con:
      equivalenti    True se hanno sempre lo stesso valore
      variabili      i nomi delle variabili, in ordine
      righe          quante righe ha la tavola
      tutte          tutte le righe della tavola: (valori, valore_a, valore_b);
                     None se sono più di LIMITE_RIGHE_ELENCO
      differenze     le righe in cui differiscono, nello stesso formato (al massimo LIMITE_RIGHE_ELENCO)
      righe_diverse  in quante righe differiscono (il numero esatto)
      controesempio  la prima riga in cui differiscono, oppure None
      a, b           le due formule riscritte con i simboli logici
      metodo         "tavola" oppure "sat"

    Con più di `max_variabili` variabili si usa il risolutore SAT: righe_diverse è None
    se le formule non sono equivalenti, e differenze contiene un solo controesempio.
    """
    a, b = _leggi(formula_a, "Formula A"), _leggi(formula_b, "Formula B")
    nomi = ordina_variabili(variables(a) + variables(b))
    if usa_sat and len(nomi) > max_variabili:
        return _compare_sat(a, b, nomi, limite_secondi)
    _controlla_variabili(nomi, max_variabili, "Il confronto")
    colonna_a, colonna_b = colonna(a, nomi), colonna(b, nomi)
    righe = 1 << len(nomi)
    diverse = colonna_a ^ colonna_b

    def riga(r):
        return assegnazione(nomi, r), bool((colonna_a >> r) & 1), bool((colonna_b >> r) & 1)

    differenze = [riga(r) for r in _indici(diverse, LIMITE_RIGHE_ELENCO)]
    return {
        "equivalenti": not diverse,
        "variabili": nomi,
        "righe": righe,
        "tutte": [riga(r) for r in range(righe)] if righe <= LIMITE_RIGHE_ELENCO else None,
        "differenze": differenze,
        "righe_diverse": bin(diverse).count("1"),
        "controesempio": differenze[0] if differenze else None,
        "a": to_text(a),
        "b": to_text(b),
        "metodo": "tavola",
    }


def consequence(premesse, conclusione, max_variabili=MAX_VARIABILI_ANALISI, usa_sat=True,
                limite_secondi=LIMITE_SECONDI_SAT):
    """Verifica se la conclusione è conseguenza logica delle premesse (premesse ⊨ conclusione).

    La conseguenza vale se in ogni riga in cui tutte le premesse sono vere anche la
    conclusione è vera. Le premesse vuote vengono ignorate.

    Restituisce un dizionario con:
      valida              True se premesse ⊨ conclusione
      variabili           i nomi delle variabili, in ordine
      righe               quante righe ha la tavola
      tutte               ogni riga: (valori, [valori delle premesse], valore della conclusione);
                          None se sono più di LIMITE_RIGHE_ELENCO
      critiche            le righe con tutte le premesse vere (al massimo LIMITE_RIGHE_ELENCO)
      righe_critiche      quante righe hanno tutte le premesse vere (il numero esatto)
      controesempi        le righe con premesse vere e conclusione falsa (al massimo LIMITE_RIGHE_ELENCO)
      numero_controesempi quanti sono i controesempi (il numero esatto)
      premesse, conclusione  le formule riscritte con i simboli logici
      metodo              "tavola" oppure "sat"

    Con più di `max_variabili` variabili si usa il risolutore SAT: si trova al più un controesempio,
    numero_controesempi è None se ce ne sono, righe_critiche è 0 se le premesse sono contraddittorie
    e None altrimenti.
    """
    alberi = []
    for numero, testo in enumerate(premesse, start=1):
        if isinstance(testo, str) and not testo.strip():
            continue
        alberi.append(_leggi(testo, f"Premessa {numero}"))
    albero_c = _leggi(conclusione, "Conclusione")
    nomi = ordina_variabili(itertools.chain(variables(albero_c), *(variables(a) for a in alberi)))
    if usa_sat and len(nomi) > max_variabili:
        return _consequence_sat(alberi, albero_c, nomi, limite_secondi)
    _controlla_variabili(nomi, max_variabili, "Il ragionamento")
    colonne_p = [colonna(a, nomi) for a in alberi]
    colonna_c = colonna(albero_c, nomi)
    righe = 1 << len(nomi)
    critiche = (1 << righe) - 1
    for c in colonne_p:
        critiche &= c
    controesempi = critiche & ~colonna_c

    def riga(r):
        return assegnazione(nomi, r), [bool((c >> r) & 1) for c in colonne_p], bool((colonna_c >> r) & 1)

    return {
        "valida": not controesempi,
        "variabili": nomi,
        "righe": righe,
        "tutte": [riga(r) for r in range(righe)] if righe <= LIMITE_RIGHE_ELENCO else None,
        "critiche": [riga(r) for r in _indici(critiche, LIMITE_RIGHE_ELENCO)],
        "righe_critiche": bin(critiche).count("1"),
        "controesempi": [riga(r) for r in _indici(controesempi, LIMITE_RIGHE_ELENCO)],
        "numero_controesempi": bin(controesempi).count("1"),
        "premesse": [to_text(a) for a in alberi],
        "conclusione": to_text(albero_c),
        "metodo": "tavola",
    }


# ---------- albero da disegnare ----------

def tree(formula):
    """Albero sintattico della formula: ogni nodo ha etichetta, tipo, sottoformula e figli."""
    radice = parse(formula)
    livelli = profondita(radice)
    if livelli > MAX_LIVELLI_ALBERO:
        raise FormulaError(f"La formula ha {livelli} livelli: sono troppi per disegnare l'albero "
                           f"(massimo {MAX_LIVELLI_ALBERO}).")
    costruiti = {}
    testi = _testi(radice)
    for nodo in _postordine(radice):
        if nodo.op == "var":
            costruiti[id(nodo)] = {"label": nodo.nome, "kind": "var", "text": nodo.nome, "children": []}
        elif nodo.op == "const":
            simbolo = "⊤" if nodo.valore else "⊥"
            costruiti[id(nodo)] = {"label": simbolo, "kind": "const", "text": simbolo, "children": []}
        else:
            costruiti[id(nodo)] = {"label": nodo.op, "kind": "op",
                                   "text": _senza_parentesi_esterne(nodo, testi[id(nodo)]),
                                   "name": NOMI_CONNETTIVI[nodo.op],
                                   "children": [costruiti[id(f)] for f in nodo.figli]}

    # le sottoformule ripetute compaiono più volte nel disegno: ognuna con il suo dizionario
    def copia(d):
        risultato = dict(d)
        pila = [risultato]
        while pila:
            corrente = pila.pop()
            corrente["children"] = [dict(f) for f in corrente["children"]]
            pila.extend(corrente["children"])
        return risultato

    return copia(costruiti[id(radice)])


def tree_depth(nodo):
    """Livelli di un albero restituito da `tree`."""
    massimo = 0
    pila = [(nodo, 1)]
    while pila:
        corrente, livello = pila.pop()
        massimo = max(massimo, livello)
        pila.extend((f, livello + 1) for f in corrente["children"])
    return massimo


# ---------- forme normali ----------

def _letterale(nome, vero):
    return nome if vero else NEG + nome


def _unisci(termini, connettivo, vuoto):
    if not termini:
        return vuoto
    if len(termini) == 1:
        return termini[0]
    return f" {connettivo} ".join(f"({x})" if (" " in x) else x for x in termini)


def _quine_mccluskey(uni, n, limite_secondi=3.0):
    """Metodo di Quine-McCluskey sui termini `uni` (numeri: bit a 1 = variabile vera, la prima a sinistra).

    Restituisce un dizionario con:
      giri        i passaggi del metodo: per ogni giro, gli implicanti con i termini che coprono,
                  se sono stati combinati in un giro successivo e quanti 1 contengono
      primi       gli implicanti primi (stringhe di '1', '0', '-') -> insieme dei termini coperti
      essenziali  i primi che sono gli unici a coprire qualche termine
      scelti      la copertura più economica: meno termini e, a parità, meno letterali
      garantita   True se la scelta è sicuramente la più corta (ricerca completata entro `limite_secondi`)
    """
    uni = sorted(set(uni))
    corrente = {format(m, f"0{n}b") if n else "": frozenset([m]) for m in uni}
    giri, primi = [], {}
    while corrente:
        prossimo, usati = {}, set()
        for a in corrente:
            # il compagno di a ha un 1 al posto di uno dei suoi 0, e tutto il resto uguale
            for i, cifra in enumerate(a):
                if cifra == "0":
                    b = a[:i] + "1" + a[i + 1:]
                    if b in corrente:
                        prossimo[a[:i] + "-" + a[i + 1:]] = corrente[a] | corrente[b]
                        usati.update((a, b))
        giri.append([{"implicante": imp, "copre": sorted(corrente[imp]), "usato": imp in usati,
                      "uni": imp.count("1")}
                     for imp in sorted(corrente, key=lambda x: (x.count("1"), x))])
        for imp in corrente:
            if imp not in usati:
                primi[imp] = corrente[imp]
        corrente = prossimo

    letterali = {p: n - p.count("-") for p in primi}
    essenziali = []
    for m in uni:
        coprenti = [p for p in primi if m in primi[p]]
        if len(coprenti) == 1 and coprenti[0] not in essenziali:
            essenziali.append(coprenti[0])
    restanti = set(uni).difference(*(primi[p] for p in essenziali))
    candidati = [p for p in primi if p not in essenziali and primi[p] & restanti]
    coprenti = {m: [p for p in candidati if m in primi[p]] for m in restanti}
    meno_letterali = min((letterali[p] for p in candidati), default=0)
    migliore = {"scelta": None, "costo": None}
    scadenza = time.perf_counter() + limite_secondi
    interrotta = [False]

    def cerca(scelti, scoperti):
        if interrotta[0] or time.perf_counter() > scadenza:
            interrotta[0] = True
            return
        costo = (len(scelti), sum(letterali[p] for p in scelti))
        if not scoperti:
            if migliore["costo"] is None or costo < migliore["costo"]:
                migliore["scelta"], migliore["costo"] = list(scelti), costo
            return
        if migliore["costo"] is not None and (costo[0] + 1, costo[1] + meno_letterali) >= migliore["costo"]:
            return
        termine = min(scoperti, key=lambda m: len(coprenti[m]))
        opzioni = sorted(coprenti[termine], key=lambda p: (-len(primi[p] & scoperti), letterali[p], p))
        for p in opzioni:
            cerca(scelti + [p], scoperti - primi[p])

    cerca([], restanti)
    garantita = not interrotta[0]
    scelta = migliore["scelta"]
    if scelta is None:
        # ricerca interrotta senza soluzioni: scelta golosa (corretta, forse non la più corta)
        scelta, scoperti = [], set(restanti)
        while scoperti:
            p = max(candidati, key=lambda p: (len(primi[p] & scoperti), -letterali[p]))
            scelta.append(p)
            scoperti -= primi[p]
    ordine = lambda p: [(0 if c == "1" else 1 if c == "0" else 2) for c in p]
    return {
        "giri": giri,
        "primi": primi,
        "essenziali": sorted(essenziali, key=ordine),
        "scelti": sorted(essenziali + scelta, key=ordine),
        "garantita": garantita,
    }


def _copertura_minima(uni, n):
    return _quine_mccluskey(uni, n)["scelti"] if uni else []


def _termine_da_implicante(nomi, implicante, per_fnd):
    """Testo di un implicante: congiunzione (FND) o disgiunzione (FNC) di letterali."""
    letterali = []
    for nome, c in zip(nomi, implicante):
        if c == "-":
            continue
        vero = c == "1"
        letterali.append(_letterale(nome, vero if per_fnd else not vero))
    if not letterali:
        return "⊤" if per_fnd else "⊥"
    return (" ∧ " if per_fnd else " ∨ ").join(letterali)


def normal_forms(formula, max_variabili=MAX_VARIABILI_FORME):
    """Forme normali disgiuntiva (FND) e congiuntiva (FNC), canoniche e minime.

    FND canonica: un mintermine (congiunzione) per ogni riga in cui la formula è vera.
    FNC canonica: un maxtermine (disgiunzione) per ogni riga in cui la formula è falsa.
    Le forme minime sono equivalenti ma più corte (metodo di Quine-McCluskey).
    """
    albero = parse(formula)
    nomi = variables(albero)
    if len(nomi) > max_variabili:
        raise FormulaError(f"La formula ha {len(nomi)} variabili: il massimo per le forme normali "
                           f"è {max_variabili}.")
    n = len(nomi)
    valori_formula = colonna(albero, nomi)
    righe = []
    for r in range(1 << n):
        valori = assegnazione(nomi, r)
        codice = (1 << n) - 1 - r  # bit a 1 per le variabili vere, la prima variabile a sinistra
        righe.append((r + 1, valori, codice, bool((valori_formula >> r) & 1)))
    vere = [r for r in righe if r[3]]
    false = [r for r in righe if not r[3]]

    def mintermine(valori):
        return " ∧ ".join(_letterale(x, valori[x]) for x in nomi)

    def maxtermine(valori):
        return " ∨ ".join(_letterale(x, not valori[x]) for x in nomi)

    if n == 0:
        costante = "⊤" if valori_formula else "⊥"
        fnd_c = fnc_c = fnd_m = fnc_m = costante
    else:
        fnd_c = _unisci([mintermine(r[1]) for r in vere], "∨", "⊥")
        fnc_c = _unisci([maxtermine(r[1]) for r in false], "∧", "⊤")

        def termine_da_implicante(imp, per_fnd):
            return _termine_da_implicante(nomi, imp, per_fnd)

        if not vere:
            fnd_m = "⊥"
        else:
            fnd_m = _unisci([termine_da_implicante(p, True) for p in _copertura_minima([r[2] for r in vere], n)],
                            "∨", "⊥")
        if not false:
            fnc_m = "⊤"
        else:
            fnc_m = _unisci([termine_da_implicante(p, False) for p in _copertura_minima([r[2] for r in false], n)],
                            "∧", "⊤")
    return {
        "variabili": nomi,
        "righe": len(righe),
        "righe_vere": [r[0] for r in vere],
        "righe_false": [r[0] for r in false],
        "fnd_canonica": fnd_c,
        "fnc_canonica": fnc_c,
        "fnd_minima": fnd_m,
        "fnc_minima": fnc_m,
        "formula": to_text(albero),
        "verdetto": classify([[("V" if r[3] else "F")] for r in righe]),
    }


# ---------- semplificazione e mappe di Karnaugh ----------

MAX_VARIABILI_MINIMIZZA = 10   # Quine-McCluskey (1024 righe)
MAX_VARIABILI_KARNAUGH = 6     # mappa disegnata


def minimizza(formula, tipo="FND", max_variabili=MAX_VARIABILI_MINIMIZZA):
    """Forma minima (FND o FNC) con il metodo di Quine-McCluskey, con tutti i dati per mostrarne i passaggi.

    In FND si coprono i termini in cui la formula è vera (mintermini), in FNC quelli in cui è falsa
    (maxtermini). Il numero di un termine è la riga scritta in binario con 1 = V, la prima variabile a sinistra.

    Restituisce un dizionario con:
      tipo, formula, variabili, righe
      termini            i numeri dei termini da coprire
      giri               i passaggi di Quine-McCluskey (vedi `_quine_mccluskey`), con il testo di ogni implicante
      primi              gli implicanti primi: implicante, testo, copre, essenziale, scelto
      scelti             gli implicanti della forma minima, con testo e termini coperti
      risultato          la forma minima
      termini_minimi, letterali   quanti termini e quanti letterali ha la forma minima
      garantita          True se è sicuramente la più corta
    """
    tipo = tipo.upper()
    if tipo not in ("FND", "FNC"):
        raise ValueError("tipo deve essere \"FND\" oppure \"FNC\"")
    per_fnd = tipo == "FND"
    radice = parse(formula)
    nomi = variables(radice)
    if len(nomi) > max_variabili:
        raise FormulaError(f"La formula ha {len(nomi)} variabili: il massimo per la semplificazione "
                           f"è {max_variabili}.")
    n = len(nomi)
    righe = 1 << n
    valori = colonna(radice, nomi)
    if not per_fnd:
        valori = ((1 << righe) - 1) ^ valori
    termini = sorted(righe - 1 - r for r in _indici(valori))
    qm = _quine_mccluskey(termini, n) if termini else {"giri": [], "primi": {}, "essenziali": [], "scelti": [],
                                                       "garantita": True}

    def testo(imp):
        return _termine_da_implicante(nomi, imp, per_fnd)

    giri = [[dict(voce, testo=testo(voce["implicante"])) for voce in giro] for giro in qm["giri"]]
    ordine = lambda p: [(0 if c == "1" else 1 if c == "0" else 2) for c in p]
    primi = [{"implicante": p, "testo": testo(p), "copre": sorted(qm["primi"][p]),
              "essenziale": p in qm["essenziali"], "scelto": p in qm["scelti"]}
             for p in sorted(qm["primi"], key=ordine)]
    scelti = [{"implicante": p, "testo": testo(p), "copre": sorted(qm["primi"][p])} for p in qm["scelti"]]
    if not termini:
        risultato = "⊥" if per_fnd else "⊤"
    else:
        risultato = _unisci([v["testo"] for v in scelti], "∨" if per_fnd else "∧", "⊥" if per_fnd else "⊤")
    letterali = sum(n - p.count("-") for p in qm["scelti"])
    return {
        "tipo": tipo,
        "formula": to_text(radice),
        "variabili": nomi,
        "righe": righe,
        "termini": termini,
        "giri": giri,
        "primi": primi,
        "scelti": scelti,
        "risultato": risultato,
        "termini_minimi": len(scelti),
        "letterali": letterali,
        "garantita": qm["garantita"],
    }


def codice_gray(bit):
    """Le combinazioni di `bit` cifre nell'ordine di Gray (due vicine differiscono per una cifra): 00 01 11 10."""
    if bit == 0:
        return [""]
    return [format(i ^ (i >> 1), f"0{bit}b") for i in range(1 << bit)]


def _segmenti(indici):
    """Divide un insieme di indici in tratti consecutivi: {0, 1, 3} -> [(0, 1), (3, 3)]."""
    tratti = []
    for i in sorted(indici):
        if tratti and i == tratti[-1][1] + 1:
            tratti[-1][1] = i
        else:
            tratti.append([i, i])
    return [tuple(t) for t in tratti]


def mappa_karnaugh(formula, tipo="FND", max_variabili=MAX_VARIABILI_KARNAUGH):
    """Mappa di Karnaugh della formula, con i raggruppamenti della forma minima.

    In FND si raggruppano gli 1 (righe vere), in FNC gli 0 (righe false). Fino a 4 variabili la mappa
    è una sola; con 5 o 6 variabili ci sono 2 o 4 mappe 4×4, una per ogni valore delle prime variabili.

    Restituisce un dizionario con:
      tipo, formula, variabili, risultato, garantita   come `minimizza`
      variabili_mappe, variabili_righe, variabili_colonne   come sono divise le variabili
      gruppi       per ogni gruppo: implicante, testo, copre (numeri dei termini)
      mappe        per ogni mappa: titolo, etichette_righe, etichette_colonne,
                   celle (righe di dizionari: valore 1/0, numero, gruppi = indici dei gruppi che la contengono),
                   rettangoli (gruppo, prima_riga, ultima_riga, prima_colonna, ultima_colonna):
                   un gruppo che «gira» oltre il bordo della mappa è diviso in più rettangoli
    """
    radice = parse(formula)
    nomi = variables(radice)
    if not nomi:
        raise FormulaError("La formula non ha variabili: la mappa di Karnaugh non serve.")
    if len(nomi) > max_variabili:
        raise FormulaError(f"La formula ha {len(nomi)} variabili: la mappa di Karnaugh si disegna fino a "
                           f"{max_variabili} variabili.")
    minima = minimizza(radice, tipo)
    n = len(nomi)
    quante_mappe = max(0, n - 4)
    resto = nomi[quante_mappe:]
    variabili_mappe = nomi[:quante_mappe]
    variabili_righe = resto[:len(resto) // 2]
    variabili_colonne = resto[len(resto) // 2:]
    valori = colonna(radice, nomi)
    righe_totali = 1 << n
    gruppi = [{"implicante": g["implicante"], "testo": g["testo"], "copre": g["copre"]} for g in minima["scelti"]]
    insiemi = [set(g["copre"]) for g in gruppi]
    mappe = []
    for codice_mappa in codice_gray(len(variabili_mappe)):
        etichette_righe = codice_gray(len(variabili_righe))
        etichette_colonne = codice_gray(len(variabili_colonne))
        celle = []
        for codice_riga in etichette_righe:
            riga = []
            for codice_colonna in etichette_colonne:
                numero = int(codice_mappa + codice_riga + codice_colonna, 2)
                vera = bool((valori >> (righe_totali - 1 - numero)) & 1)
                riga.append({"valore": 1 if vera else 0, "numero": numero,
                             "gruppi": [i for i, insieme in enumerate(insiemi) if numero in insieme]})
            celle.append(riga)
        rettangoli = []
        for i in range(len(gruppi)):
            righe_gruppo = {r for r, riga in enumerate(celle) if any(i in c["gruppi"] for c in riga)}
            colonne_gruppo = {k for riga in celle for k, c in enumerate(riga) if i in c["gruppi"]}
            for r0, r1 in _segmenti(righe_gruppo):
                for c0, c1 in _segmenti(colonne_gruppo):
                    rettangoli.append((i, r0, r1, c0, c1))
        titolo = ", ".join(f"{v} = {b}" for v, b in zip(variabili_mappe, codice_mappa))
        mappe.append({"titolo": titolo, "etichette_righe": etichette_righe, "etichette_colonne": etichette_colonne,
                      "celle": celle, "rettangoli": rettangoli})
    return {
        "tipo": minima["tipo"],
        "formula": minima["formula"],
        "variabili": nomi,
        "variabili_mappe": variabili_mappe,
        "variabili_righe": variabili_righe,
        "variabili_colonne": variabili_colonne,
        "gruppi": gruppi,
        "mappe": mappe,
        "risultato": minima["risultato"],
        "garantita": minima["garantita"],
    }


# ---------- forme normali passo per passo ----------

# chiave -> (nome della legge, la legge scritta con lettere generiche)
LEGGI = {
    "iff_fnc": ("Eliminazione della doppia implicazione", "A ↔ B  ≡  (A → B) ∧ (B → A)"),
    "iff_fnd": ("Doppia implicazione in forma disgiuntiva", "A ↔ B  ≡  (A ∧ B) ∨ (¬A ∧ ¬B)"),
    "xor_fnc": ("Eliminazione della disgiunzione esclusiva", "A ⊕ B  ≡  (A ∨ B) ∧ (¬A ∨ ¬B)"),
    "xor_fnd": ("Eliminazione della disgiunzione esclusiva", "A ⊕ B  ≡  (A ∧ ¬B) ∨ (¬A ∧ B)"),
    "nand": ("Definizione di NAND", "A ↑ B  ≡  ¬(A ∧ B)"),
    "nor": ("Definizione di NOR", "A ↓ B  ≡  ¬(A ∨ B)"),
    "imp": ("Eliminazione dell'implicazione", "A → B  ≡  ¬A ∨ B"),
    "dneg": ("Doppia negazione", "¬¬A  ≡  A"),
    "demorgan": ("Leggi di De Morgan", "¬(A ∧ B)  ≡  ¬A ∨ ¬B        ¬(A ∨ B)  ≡  ¬A ∧ ¬B"),
    "negconst": ("Negazione delle costanti", "¬⊤  ≡  ⊥        ¬⊥  ≡  ⊤"),
    "costanti": ("Identità e dominazione", "A ∧ ⊤ ≡ A      A ∨ ⊥ ≡ A      A ∨ ⊤ ≡ ⊤      A ∧ ⊥ ≡ ⊥"),
    "distr_fnc": ("Distributività di ∨ rispetto a ∧", "A ∨ (B ∧ C)  ≡  (A ∨ B) ∧ (A ∨ C)"),
    "distr_fnd": ("Distributività di ∧ rispetto a ∨", "A ∧ (B ∨ C)  ≡  (A ∧ B) ∨ (A ∧ C)"),
    "assoc": ("Associatività", "(A ∧ B) ∧ C  ≡  A ∧ (B ∧ C)        (A ∨ B) ∨ C  ≡  A ∨ (B ∨ C)"),
    "idem": ("Idempotenza", "A ∨ A  ≡  A        A ∧ A  ≡  A"),
    "terzo": ("Terzo escluso e identità", "A ∨ ¬A  ≡  ⊤        B ∧ ⊤  ≡  B"),
    "noncontr": ("Non contraddizione e identità", "A ∧ ¬A  ≡  ⊥        B ∨ ⊥  ≡  B"),
    "assorb_fnc": ("Assorbimento", "A ∧ (A ∨ B)  ≡  A"),
    "assorb_fnd": ("Assorbimento", "A ∨ (A ∧ B)  ≡  A"),
}

MAX_LIVELLI_PASSAGGI = 60      # livelli della formula di partenza
MAX_SIMBOLI_PASSAGGI = 4000    # lunghezza massima di una formula intermedia
MAX_PASSAGGI = 300
_ESEMPI_PER_PASSAGGIO = 3


def _regole_di_riscrittura(c):
    """Le leggi che riscrivono un solo nodo: ognuna restituisce il nodo nuovo oppure None."""
    def neg(a):
        return c.nodo(NEG, (a,))

    def e(a, b):
        return c.nodo(AND, (a, b))

    def o(a, b):
        return c.nodo(OR, (a, b))

    def binario(op):
        return lambda n: n.figli if n.op == op else None

    def regola(op, costruisci):
        def applica(n):
            figli = binario(op)(n)
            return None if figli is None else costruisci(*figli)
        return applica

    def dneg(n):
        if n.op == NEG and n.figli[0].op == NEG:
            return n.figli[0].figli[0]
        return None

    def demorgan(n):
        if n.op == NEG and n.figli[0].op in (AND, OR):
            a, b = n.figli[0].figli
            return o(neg(a), neg(b)) if n.figli[0].op == AND else e(neg(a), neg(b))
        return None

    def negconst(n):
        if n.op == NEG and n.figli[0].op == "const":
            return c.nodo("const", valore=not n.figli[0].valore)
        return None

    def distr(esterno, interno):
        def applica(n):
            if n.op != esterno:
                return None
            a, b = n.figli
            if b.op == interno:
                return c.nodo(interno, (c.nodo(esterno, (a, b.figli[0])), c.nodo(esterno, (a, b.figli[1]))))
            if a.op == interno:
                return c.nodo(interno, (c.nodo(esterno, (a.figli[0], b)), c.nodo(esterno, (a.figli[1], b))))
            return None
        return applica

    return {
        "iff_fnc": regola(IFF, lambda a, b: e(c.nodo(IMP, (a, b)), c.nodo(IMP, (b, a)))),
        "iff_fnd": regola(IFF, lambda a, b: o(e(a, b), e(neg(a), neg(b)))),
        "xor_fnc": regola(XOR, lambda a, b: e(o(a, b), o(neg(a), neg(b)))),
        "xor_fnd": regola(XOR, lambda a, b: o(e(a, neg(b)), e(neg(a), b))),
        "nand": regola(NAND, lambda a, b: neg(e(a, b))),
        "nor": regola(NOR, lambda a, b: neg(o(a, b))),
        "imp": regola(IMP, lambda a, b: o(neg(a), b)),
        "dneg": dneg,
        "demorgan": demorgan,
        "negconst": negconst,
        "distr_fnc": distr(OR, AND),
        "distr_fnd": distr(AND, OR),
    }


def _passata(nodo, regola, c, coppie):
    """Applica la regola dall'alto in basso in tutti i punti in cui vale (senza sovrapposizioni)."""
    nuovo = regola(nodo)
    if nuovo is not None:
        coppie.append((nodo, nuovo))
        return nuovo
    if not nodo.figli:
        return nodo
    figli = tuple(_passata(f, regola, c, coppie) for f in nodo.figli)
    if all(a is b for a, b in zip(figli, nodo.figli)):
        return nodo
    return c.nodo(nodo.op, figli)


def _togli_costanti(radice, c, coppie):
    """Identità e dominazione, dal basso verso l'alto: toglie ⊤ e ⊥ dentro ∧ e ∨."""
    nuovi = {}
    for nodo in _postordine(radice):
        if not nodo.figli:
            nuovi[id(nodo)] = nodo
            continue
        figli = tuple(nuovi[id(f)] for f in nodo.figli)
        risultato = None
        if nodo.op in (AND, OR):
            dominante = nodo.op == OR   # ⊤ domina ∨, ⊥ domina ∧
            for x, y in ((figli[0], figli[1]), (figli[1], figli[0])):
                if x.op == "const":
                    risultato = x if x.valore == dominante else y
                    break
        elif nodo.op == NEG and figli[0].op == "const":
            risultato = c.nodo("const", valore=not figli[0].valore)
        prima = nodo if all(a is b for a, b in zip(figli, nodo.figli)) else c.nodo(nodo.op, figli)
        if risultato is not None:
            coppie.append((prima, risultato))
            nuovi[id(nodo)] = risultato
        else:
            nuovi[id(nodo)] = prima
    return nuovi[id(radice)]


def _operandi(nodo, op):
    """Gli elementi di una catena dello stesso connettivo: (p ∧ q) ∧ r -> [p, q, r]."""
    elementi, pila = [], [nodo]
    while pila:
        x = pila.pop()
        if x.op == op:
            pila.extend(reversed(x.figli))
        else:
            elementi.append(x)
    return elementi


def _catena(c, op, elementi):
    risultato = elementi[0]
    for elemento in elementi[1:]:
        risultato = c.nodo(op, (risultato, elemento))
    return risultato


def _nodo_letterale(c, nome, positivo):
    variabile = c.nodo("var", nome=nome)
    return variabile if positivo else c.nodo(NEG, (variabile,))


def e_forma_normale(formula, tipo):
    """True se la formula è già in FNC (tipo "FNC") o in FND (tipo "FND")."""
    radice = parse(formula)
    esterno, interno = (AND, OR) if tipo.upper() == "FNC" else (OR, AND)
    if radice.op == "const":
        return True
    for termine in _operandi(radice, esterno):
        for letterale in _operandi(termine, interno):
            if letterale.op == NEG:
                letterale = letterale.figli[0]
            if letterale.op != "var":
                return False
    return True


def forma_normale_passo_passo(formula, tipo="FNC"):
    """Trasforma la formula in FNC o FND con le leggi del calcolo, un passaggio alla volta.

    Ogni passaggio applica una sola legge, in tutti i punti in cui serve, e ogni formula
    intermedia è equivalente a quella di partenza.

    Restituisce un dizionario con:
      tipo          "FNC" oppure "FND"
      formula       la formula di partenza riscritta con i simboli logici
      passaggi      elenco di dizionari: legge, regola, formula (dopo il passaggio),
                    esempi (alcune trasformazioni fatte, in testo), quante (in quanti punti),
                    nota (una spiegazione, per i passaggi che non hanno esempi)
      risultato     la forma normale ottenuta
      termini       le clausole (FNC) o i termini (FND): liste di letterali in testo
      verificata    True se l'equivalenza con la formula di partenza è stata controllata
                    sulla tavola (fino a MAX_VARIABILI_ANALISI variabili), altrimenti None
    """
    tipo = tipo.upper()
    if tipo not in ("FNC", "FND"):
        raise ValueError("tipo deve essere \"FNC\" oppure \"FND\"")
    fnc = tipo == "FNC"
    radice = parse(formula)
    livelli = profondita(radice)
    if livelli > MAX_LIVELLI_PASSAGGI:
        raise FormulaError(f"La formula ha {livelli} livelli: sono troppi per mostrare i passaggi "
                           f"(massimo {MAX_LIVELLI_PASSAGGI}).")
    c = _Costruttore()
    regole = _regole_di_riscrittura(c)
    passaggi = []
    stato = {"formula": radice}

    def registra(chiave, nuovo, coppie, esempi=None, nota=""):
        testo = to_text(nuovo)
        if len(testo) > MAX_SIMBOLI_PASSAGGI or len(passaggi) >= MAX_PASSAGGI or profondita(nuovo) > 400:
            altra = "FND" if fnc else "FNC"
            raise FormulaError(f"La {tipo} di questa formula diventa troppo lunga da mostrare passo per passo: "
                               f"la proprietà distributiva la fa crescere troppo. Prova con la {altra}, "
                               f"con le forme ricavate dalla tavola di verità o con una formula più corta.")
        if esempi is None:
            esempi = []
            for prima, dopo in coppie:
                riga = f"{to_text(prima)}   diventa   {to_text(dopo)}"
                if riga not in esempi:
                    esempi.append(riga)
        nome, regola = LEGGI[chiave]
        passaggi.append({"legge": nome, "regola": regola, "formula": testo,
                         "esempi": esempi[:_ESEMPI_PER_PASSAGGIO], "quante": len(esempi), "nota": nota})
        stato["formula"] = nuovo

    def applica_finche_serve(chiavi):
        cambiato = True
        while cambiato:
            cambiato = False
            for chiave in chiavi:
                coppie = []
                nuovo = _passata(stato["formula"], regole[chiave], c, coppie)
                if coppie:
                    registra(chiave, nuovo, coppie)
                    cambiato = True
                    break

    # 1. via ⊕ ↑ ↓ ↔, poi →: restano solo ¬ ∧ ∨
    applica_finche_serve(["xor_fnc" if fnc else "xor_fnd", "nand", "nor", "iff_fnc" if fnc else "iff_fnd"])
    applica_finche_serve(["imp"])
    # 2. le negazioni scendono fino alle variabili
    applica_finche_serve(["dneg", "demorgan", "negconst"])
    # 3. via le costanti
    coppie = []
    nuovo = _togli_costanti(stato["formula"], c, coppie)
    if coppie:
        registra("costanti", nuovo, coppie)

    esterno, interno = (AND, OR) if fnc else (OR, AND)
    if stato["formula"].op != "const":
        # 4. distributività finché serve, poi via le parentesi superflue
        applica_finche_serve(["distr_fnc" if fnc else "distr_fnd"])
        corrente = stato["formula"]
        riassociata = _catena(c, esterno, [_catena(c, interno, _operandi(t, interno))
                                           for t in _operandi(corrente, esterno)])
        if to_text(riassociata) != to_text(corrente):
            registra("assoc", riassociata, [], [], "Si tolgono le parentesi che non cambiano il significato.")

        # 5. semplificazioni sui termini (clausole in FNC, congiunzioni in FND)
        termini = [[(l.nome, True) if l.op == "var" else (l.figli[0].nome, False) for l in _operandi(t, interno)]
                   for t in _operandi(stato["formula"], esterno)]

        def testo(termine):
            letterali = [n if v else NEG + n for n, v in termine]
            return f" {interno} ".join(letterali)

        def ricostruisci(lista):
            if not lista:
                return c.nodo("const", valore=fnc)
            return _catena(c, esterno, [_catena(c, interno, [_nodo_letterale(c, n, v) for n, v in t]) for t in lista])

        # idempotenza: letterali ripetuti in un termine, termini ripetuti
        esempi, nuovi, visti = [], [], []
        for termine in termini:
            senza_doppi = list(dict.fromkeys(termine))
            if len(senza_doppi) < len(termine):
                esempi.append(f"{testo(termine)}   diventa   {testo(senza_doppi)}")
            if set(senza_doppi) in visti:
                esempi.append(f"{testo(senza_doppi)}   compare più volte: se ne tiene una")
                continue
            visti.append(set(senza_doppi))
            nuovi.append(senza_doppi)
        if esempi:
            termini = nuovi
            registra("idem", ricostruisci(termini), [], esempi)

        # terzo escluso (FNC) / non contraddizione (FND): termini con p e ¬p
        esempi, nuovi = [], []
        for termine in termini:
            if any((n, not v) in termine for n, v in termine):
                esempi.append(f"{testo(termine)}   è sempre {'vera' if fnc else 'falsa'}: si toglie")
            else:
                nuovi.append(termine)
        if esempi:
            termini = nuovi
            registra("terzo" if fnc else "noncontr", ricostruisci(termini), [], esempi)

        # assorbimento: un termine che contiene tutti i letterali di un altro si toglie
        esempi, nuovi = [], []
        for i, termine in enumerate(termini):
            piu_piccolo = next((altro for j, altro in enumerate(termini)
                                if j != i and set(altro) < set(termine)), None)
            if piu_piccolo is not None:
                esempi.append(f"{testo(termine)}   si toglie: contiene già {testo(piu_piccolo)}")
            else:
                nuovi.append(termine)
        if esempi:
            termini = nuovi
            registra("assorb_fnc" if fnc else "assorb_fnd", ricostruisci(termini), [], esempi)

    finale = stato["formula"]
    if finale.op == "const":
        termini_testo = []
    else:
        termini_testo = [[to_text(l) for l in _operandi(t, interno)] for t in _operandi(finale, esterno)]
    nomi = ordina_variabili(variables(radice) + variables(finale))
    verificata = None
    if len(nomi) <= MAX_VARIABILI_ANALISI:
        verificata = colonna(radice, nomi) == colonna(finale, nomi)
    return {
        "tipo": tipo,
        "formula": to_text(radice),
        "passaggi": passaggi,
        "risultato": to_text(finale),
        "termini": termini_testo,
        "verificata": verificata,
    }


# ---------- tavola grande, a pagine ----------

MAX_VARIABILI_TAVOLA_GRANDE = 20   # 1.048.576 righe
FILTRI = ("tutte", "vere", "false")
_BYTE_PER_BLOCCO = 4096
_UNI_NEL_BYTE = [bin(i).count("1") for i in range(256)]


class TavolaPaginata:
    """Tavola di verità grande, letta una pagina alla volta, con il filtro «tutte / vere / false».

    Le colonne sono calcolate una volta sola (un intero per colonna); una pagina estrae solo le righe
    che servono, quindi anche con un milione di righe si sfoglia senza attese.

      intestazione     nomi delle colonne (variabili, poi sottoformule; l'ultima è la formula)
      variabili        i nomi delle variabili
      righe            quante righe ha la tavola
      vere, false      in quante righe la formula è vera / falsa
    """

    def __init__(self, formula, sottoformule=True, max_variabili=MAX_VARIABILI_TAVOLA_GRANDE):
        radice = parse(formula)
        nomi = variables(radice)
        _controlla_variabili(nomi, max_variabili, "La formula")
        self.formula = to_text(radice)
        self.variabili = nomi
        self.righe = 1 << len(nomi)
        nomi, righe, colonne = calcola(radice, nomi)
        if radice.op == "const":
            composte = [radice]
        elif sottoformule:
            composte = subformulas(radice)
        else:
            composte = [radice] if radice.op != "var" else []
        testi = _testi(radice)
        self.intestazione = list(nomi) + [_senza_parentesi_esterne(c, testi[id(c)]) for c in composte]
        self._colonne = [colonne[id(c)] for c in composte]
        finale = colonne[id(radice)]
        del colonne
        self.vere = bin(finale).count("1")
        self.false = self.righe - self.vere
        lunghezza = max(1, (self.righe + 7) // 8)
        self._byte = {"vere": finale.to_bytes(lunghezza, "little"),
                      "false": (((1 << self.righe) - 1) ^ finale).to_bytes(lunghezza, "little")}
        self._prefissi_calcolati = {}

    def conta(self, filtro="tutte"):
        """Quante righe passano il filtro."""
        return {"tutte": self.righe, "vere": self.vere, "false": self.false}[filtro]

    def pagine(self, dimensione=50, filtro="tutte"):
        return max(1, -(-self.conta(filtro) // dimensione))

    def _prefissi(self, filtro):
        """Quante righe del filtro ci sono prima di ogni blocco di byte (per saltare subito al punto giusto)."""
        if filtro not in self._prefissi_calcolati:
            dati, prefissi, totale = self._byte[filtro], [], 0
            for inizio in range(0, len(dati), _BYTE_PER_BLOCCO):
                prefissi.append(totale)
                totale += bin(int.from_bytes(dati[inizio:inizio + _BYTE_PER_BLOCCO], "little")).count("1")
            self._prefissi_calcolati[filtro] = prefissi
        return self._prefissi_calcolati[filtro]

    def _posizioni(self, filtro, da, quante):
        """Numeri (da 0) delle righe che passano il filtro, dalla `da`-esima per `quante` righe."""
        if filtro == "tutte":
            return list(range(da, min(da + quante, self.righe)))
        dati, prefissi = self._byte[filtro], self._prefissi(filtro)
        blocco = bisect.bisect_right(prefissi, da) - 1
        if blocco < 0:
            return []
        contate, posizione, trovate = prefissi[blocco], blocco * _BYTE_PER_BLOCCO, []
        while posizione < len(dati) and len(trovate) < quante:
            byte = dati[posizione]
            if byte:
                uni = _UNI_NEL_BYTE[byte]
                if contate + uni <= da:
                    contate += uni
                else:
                    for bit in range(8):
                        if (byte >> bit) & 1:
                            if contate >= da and len(trovate) < quante:
                                trovate.append(posizione * 8 + bit)
                            contate += 1
            posizione += 1
        return [r for r in trovate if r < self.righe]

    def pagina(self, numero=1, dimensione=50, filtro="tutte"):
        """Le righe della pagina `numero` (da 1): lista di (numero della riga da 1, valori "V"/"F")."""
        if filtro not in FILTRI:
            raise ValueError(f"filtro deve essere uno di {FILTRI}")
        posizioni = self._posizioni(filtro, (numero - 1) * dimensione, dimensione)
        if not posizioni:
            return []
        primo, ultimo = posizioni[0], posizioni[-1]
        maschera = (1 << (ultimo - primo + 1)) - 1
        finestre = [(c >> primo) & maschera for c in self._colonne]
        quante = len(self.variabili)
        risultato = []
        for r in posizioni:
            valori = ["F" if (r >> (quante - 1 - i)) & 1 else "V" for i in range(quante)]
            valori += ["V" if (f >> (r - primo)) & 1 else "F" for f in finestre]
            risultato.append((r + 1, valori))
        return risultato

    def pagina_della_riga(self, riga, dimensione=50):
        """Pagina (senza filtro) in cui si trova la riga indicata (da 1)."""
        return (max(1, min(riga, self.righe)) - 1) // dimensione + 1


# ---------- risolutore SAT ----------
#
# Per le formule con tante variabili la tavola di verità è troppo grande (2^n righe).
# Il risolutore SAT risponde alla domanda «esiste un'assegnazione che rende vera la formula?»
# senza costruire la tavola:
#   1. la formula diventa un insieme di clausole (trasformazione di Tseitin: una variabile
#      nuova per ogni sottoformula, quindi le clausole crescono come la formula, non in modo esponenziale);
#   2. le clausole si risolvono con il metodo CDCL: si sceglie un valore, si propagano le conseguenze
#      e, quando si arriva a una contraddizione, si «impara» una clausola nuova che evita di ripetere l'errore.


def _tseitin(radice):
    """Clausole equisoddisfacibili con la formula. Restituisce (clausole, numero di variabili, nome -> numero)."""
    clausole = []
    numeri = {}
    letterali = {}
    contatore = [0]

    def nuova():
        contatore[0] += 1
        return contatore[0]

    vero = None
    for nodo in _postordine(radice):
        if nodo.op == "var":
            if nodo.nome not in numeri:
                numeri[nodo.nome] = nuova()
            letterali[id(nodo)] = numeri[nodo.nome]
            continue
        if nodo.op == "const":
            if vero is None:
                vero = nuova()
                clausole.append([vero])
            letterali[id(nodo)] = vero if nodo.valore else -vero
            continue
        if nodo.op == NEG:
            letterali[id(nodo)] = -letterali[id(nodo.figli[0])]
            continue
        a, b = (letterali[id(f)] for f in nodo.figli)
        x = nuova()
        op = nodo.op
        if op in (AND, NAND):
            clausole += [[-x, a], [-x, b], [x, -a, -b]]
        elif op in (OR, NOR):
            clausole += [[x, -a], [x, -b], [-x, a, b]]
        elif op == XOR:
            clausole += [[-x, a, b], [-x, -a, -b], [x, -a, b], [x, a, -b]]
        elif op == IFF:
            clausole += [[-x, -a, b], [-x, a, -b], [x, a, b], [x, -a, -b]]
        else:  # IMP
            clausole += [[x, a], [x, -b], [-x, -a, b]]
        letterali[id(nodo)] = -x if op in (NAND, NOR) else x
    clausole.append([letterali[id(radice)]])
    return clausole, contatore[0], numeri


class _Risolutore:
    """Risolutore CDCL: due letterali osservati per clausola, apprendimento 1UIP,
    scelta delle variabili più «attive», memoria della polarità e ripartenze."""

    def __init__(self, quante, clausole):
        self.n = quante
        self.valore = [0] * (quante + 1)       # 1 vero, -1 falso, 0 libero
        self.livello = [0] * (quante + 1)
        self.motivo = [None] * (quante + 1)
        self.fase = [-1] * (quante + 1)
        self.attivita = [0.0] * (quante + 1)
        self.incremento = 1.0
        self.traccia = []
        self.inizi = []                          # dove inizia ogni livello di decisione nella traccia
        self.testa = 0
        self.osservate = [[] for _ in range(2 * quante + 2)]
        self.coda = [(0.0, v) for v in range(1, quante + 1)]
        self.conflitti = 0
        self.impossibile = False
        for clausola in clausole:
            self._aggiungi(clausola)

    @staticmethod
    def _indice(letterale):
        return 2 * letterale if letterale > 0 else -2 * letterale + 1

    def _vale(self, letterale):
        v = self.valore[abs(letterale)]
        return v if letterale > 0 else -v

    def _assegna(self, letterale, motivo):
        v = abs(letterale)
        self.valore[v] = 1 if letterale > 0 else -1
        self.livello[v] = len(self.inizi)
        self.motivo[v] = motivo
        self.traccia.append(letterale)

    def _aggiungi(self, clausola):
        clausola = list(dict.fromkeys(clausola))
        if any(-l in clausola for l in clausola):
            return
        if not clausola:
            self.impossibile = True
        elif len(clausola) == 1:
            stato = self._vale(clausola[0])
            if stato == -1:
                self.impossibile = True
            elif stato == 0:
                self._assegna(clausola[0], None)
        else:
            self.osservate[self._indice(clausola[0])].append(clausola)
            self.osservate[self._indice(clausola[1])].append(clausola)

    def _propaga(self):
        while self.testa < len(self.traccia):
            falso = -self.traccia[self.testa]
            self.testa += 1
            lista = self.osservate[self._indice(falso)]
            i = j = 0
            while i < len(lista):
                c = lista[i]
                i += 1
                if c[0] == falso:
                    c[0], c[1] = c[1], c[0]
                if self._vale(c[0]) == 1:
                    lista[j] = c
                    j += 1
                    continue
                for k in range(2, len(c)):
                    if self._vale(c[k]) != -1:
                        c[1], c[k] = c[k], c[1]
                        self.osservate[self._indice(c[1])].append(c)
                        break
                else:
                    lista[j] = c
                    j += 1
                    if self._vale(c[0]) == -1:
                        while i < len(lista):
                            lista[j] = lista[i]
                            i += 1
                            j += 1
                        del lista[j:]
                        return c
                    self._assegna(c[0], c)
            del lista[j:]
        return None

    def _premia(self, v):
        self.attivita[v] += self.incremento
        if self.attivita[v] > 1e100:
            self.attivita = [a * 1e-100 for a in self.attivita]
            self.incremento *= 1e-100
            self.coda = [(-self.attivita[x], x) for x in range(1, self.n + 1) if self.valore[x] == 0]
            heapq.heapify(self.coda)
        else:
            heapq.heappush(self.coda, (-self.attivita[v], v))

    def _analizza(self, conflitto):
        """Clausola appresa con il primo punto di implicazione unico (1UIP) e livello a cui tornare."""
        appresa = [0]
        visti = set()
        da_vedere = 0
        livello_attuale = len(self.inizi)
        indice = len(self.traccia) - 1
        clausola, salta = conflitto, 0
        while True:
            for letterale in clausola[salta:]:
                v = abs(letterale)
                if v not in visti and self.livello[v] > 0:
                    visti.add(v)
                    self._premia(v)
                    if self.livello[v] == livello_attuale:
                        da_vedere += 1
                    else:
                        appresa.append(letterale)
            while abs(self.traccia[indice]) not in visti:
                indice -= 1
            p = self.traccia[indice]
            indice -= 1
            da_vedere -= 1
            if da_vedere == 0:
                break
            clausola, salta = self.motivo[abs(p)], 1
        appresa[0] = -p
        if len(appresa) == 1:
            return appresa, 0
        # il letterale con il livello più alto (dopo il primo) va in seconda posizione
        k = max(range(1, len(appresa)), key=lambda i: self.livello[abs(appresa[i])])
        appresa[1], appresa[k] = appresa[k], appresa[1]
        return appresa, self.livello[abs(appresa[1])]

    def _torna(self, livello):
        if len(self.inizi) <= livello:
            return
        inizio = self.inizi[livello]
        for letterale in self.traccia[inizio:]:
            v = abs(letterale)
            self.fase[v] = self.valore[v]
            self.valore[v] = 0
            self.motivo[v] = None
            heapq.heappush(self.coda, (-self.attivita[v], v))
        del self.traccia[inizio:]
        del self.inizi[livello:]
        self.testa = len(self.traccia)

    def _scegli(self):
        while self.coda:
            _, v = heapq.heappop(self.coda)
            if self.valore[v] == 0:
                return v if self.fase[v] == 1 else -v
        return None

    def risolvi(self, limite_secondi):
        """True (soddisfacibile), False (impossibile) oppure None (tempo scaduto)."""
        if self.impossibile:
            return False
        if self._propaga() is not None:
            return False
        scadenza = time.perf_counter() + limite_secondi
        prossima_ripartenza = 100
        while True:
            conflitto = self._propaga()
            if conflitto is not None:
                self.conflitti += 1
                if not self.inizi:
                    return False
                appresa, livello = self._analizza(conflitto)
                self._torna(livello)
                if len(appresa) == 1:
                    self._assegna(appresa[0], None)
                else:
                    self.osservate[self._indice(appresa[0])].append(appresa)
                    self.osservate[self._indice(appresa[1])].append(appresa)
                    self._assegna(appresa[0], appresa)
                self.incremento /= 0.95
                if self.conflitti % 64 == 0 and time.perf_counter() > scadenza:
                    return None
                if self.conflitti >= prossima_ripartenza:
                    prossima_ripartenza = int(prossima_ripartenza * 1.5) + 100
                    self._torna(0)
                continue
            scelta = self._scegli()
            if scelta is None:
                return True
            self.inizi.append(len(self.traccia))
            self._assegna(scelta, None)


def sat(formula, limite_secondi=LIMITE_SECONDI_SAT):
    """Cerca un'assegnazione che renda vera la formula, senza costruire la tavola di verità.

    Restituisce un dizionario con:
      soddisfacibile  True, False oppure None se il tempo è scaduto prima di una risposta
      modello         i valori delle variabili che rendono vera la formula (se soddisfacibile)
      variabili       i nomi delle variabili, in ordine
      clausole        quante clausole ha prodotto la trasformazione di Tseitin
      conflitti       quante contraddizioni ha incontrato la ricerca
      secondi         il tempo impiegato
    """
    inizio = time.perf_counter()
    radice = parse(formula)
    nomi = variables(radice)
    clausole, quante, numeri = _tseitin(radice)
    risolutore = _Risolutore(quante, clausole)
    esito = risolutore.risolvi(limite_secondi)
    modello = None
    if esito:
        modello = {nome: risolutore.valore[numeri[nome]] == 1 for nome in nomi}
        if not evaluate(radice, modello):   # controllo di sicurezza: non dovrebbe mai succedere
            raise RuntimeError("Il risolutore SAT ha prodotto un modello sbagliato.")
    return {
        "soddisfacibile": esito,
        "modello": modello,
        "variabili": nomi,
        "clausole": len(clausole),
        "conflitti": risolutore.conflitti,
        "secondi": time.perf_counter() - inizio,
    }


def _sat_o_errore(radice, limite_secondi, domanda):
    risultato = sat(radice, limite_secondi)
    if risultato["soddisfacibile"] is None:
        raise FormulaError(f"Il risolutore SAT non ha trovato una risposta entro {limite_secondi} secondi "
                           f"({domanda}). La formula è troppo difficile: prova a semplificarla.")
    return risultato


def riga_di(nomi, valori):
    """Numero della riga (da 1) della tavola che corrisponde ai valori delle variabili."""
    quante = len(nomi)
    return 1 + sum((0 if valori[nome] else 1) << (quante - 1 - i) for i, nome in enumerate(nomi))


def _negazione(radice):
    return Formula(NEG, (radice,))


def _analizza_sat(radice, nomi, limite_secondi):
    vera = _sat_o_errore(radice, limite_secondi, "è soddisfacibile?")
    falsa = _sat_o_errore(_negazione(radice), limite_secondi, "è una tautologia?")
    if not vera["soddisfacibile"]:
        classificazione = "contraddizione"
    elif not falsa["soddisfacibile"]:
        classificazione = "tautologia"
    else:
        classificazione = "contingente"
    righe = 1 << len(nomi)
    return {
        "formula": to_text(radice),
        "variabili": nomi,
        "righe": righe,
        "classificazione": classificazione,
        "verdetto": VERDETTI[classificazione],
        "righe_vere": righe if classificazione == "tautologia" else 0 if classificazione == "contraddizione" else None,
        "righe_false": 0 if classificazione == "tautologia" else righe if classificazione == "contraddizione" else None,
        "soddisfacibile": bool(vera["soddisfacibile"]),
        "controesempio": falsa["modello"],
        "riga_controesempio": riga_di(nomi, falsa["modello"]) if falsa["modello"] else None,
        "esempio": vera["modello"],
        "riga_esempio": riga_di(nomi, vera["modello"]) if vera["modello"] else None,
        "metodo": "sat",
        "secondi": vera["secondi"] + falsa["secondi"],
    }


def _compare_sat(a, b, nomi, limite_secondi):
    differenza = _sat_o_errore(Formula(XOR, (a, b)), limite_secondi, "sono equivalenti?")
    differenze = []
    if differenza["soddisfacibile"]:
        valori = {n: differenza["modello"].get(n, False) for n in nomi}
        differenze = [(valori, evaluate(a, valori), evaluate(b, valori))]
    return {
        "equivalenti": not differenze,
        "variabili": nomi,
        "righe": 1 << len(nomi),
        "tutte": None,
        "differenze": differenze,
        "righe_diverse": 0 if not differenze else None,
        "controesempio": differenze[0] if differenze else None,
        "a": to_text(a),
        "b": to_text(b),
        "metodo": "sat",
    }


def _consequence_sat(alberi, albero_c, nomi, limite_secondi):
    def congiunzione(formule):
        risultato = formule[0]
        for f in formule[1:]:
            risultato = Formula(AND, (risultato, f))
        return risultato

    controesempio = _sat_o_errore(congiunzione(alberi + [_negazione(albero_c)]), limite_secondi,
                                  "la conclusione segue dalle premesse?")
    righe_critiche = None
    controesempi = []
    if controesempio["soddisfacibile"]:
        valori = {n: controesempio["modello"].get(n, False) for n in nomi}
        controesempi = [(valori, [evaluate(a, valori) for a in alberi], evaluate(albero_c, valori))]
    elif alberi:
        coerenti = _sat_o_errore(congiunzione(alberi), limite_secondi, "le premesse possono essere vere insieme?")
        if not coerenti["soddisfacibile"]:
            righe_critiche = 0
    return {
        "valida": not controesempi,
        "variabili": nomi,
        "righe": 1 << len(nomi),
        "tutte": None,
        "critiche": [],
        "righe_critiche": righe_critiche,
        "controesempi": controesempi,
        "numero_controesempi": 0 if not controesempi else None,
        "premesse": [to_text(a) for a in alberi],
        "conclusione": to_text(albero_c),
        "metodo": "sat",
    }


# ---------- logica dei predicati ----------
#
# Formule con quantificatori e predicati, per esempio  ∀x (Uomo(x) → Mortale(x))  oppure  ∀x ∃y Ama(x, y).
#
#   ∀  per ogni      (si scrive anche forall)
#   ∃  esiste        (si scrive anche exists)
#   P(x), R(x, y)    predicati con uno o più argomenti; senza parentesi (P) è una proposizione
#   x = y, x ≠ y     uguaglianza tra elementi (≠ si scrive anche != oppure /=)
#
# Un quantificatore lega come la negazione: ∀x P(x) → Q(x) si legge (∀x P(x)) → Q(x).
# Per estendere il suo campo d'azione si usano le parentesi, ∀x (P(x) → Q(x)), oppure il punto:
# ∀x. P(x) → Q(x) vale fino alla fine (della formula o della parentesi in cui si trova).
# Gli argomenti che non sono variabili quantificate sono costanti: nomi di elementi del dominio.

PER_OGNI, ESISTE = "∀", "∃"
UGUALE, DIVERSO = "=", "≠"
MAX_ELEMENTI_DOMINIO = 30
MAX_ELEMENTI_RICERCA = 5
LIMITE_PASSI_PREDICATI = 2_000_000
_PAROLE_QUANTIFICATORI = {"forall": PER_OGNI, "exists": ESISTE}
_SIMBOLI_PREDICATI = {"∀": ("quant", PER_OGNI), "∃": ("quant", ESISTE), ",": (",", ","), ".": (".", "."),
                      ":": (".", "."), "=": ("=", UGUALE), "≠": ("=", DIVERSO), "!=": ("=", DIVERSO),
                      "/=": ("=", DIVERSO)}


class NodoPredicati:
    """Nodo di una formula con predicati: tipo è "pred", "=", "const", "¬", un connettivo binario, "∀" o "∃"."""
    __slots__ = ("tipo", "figli", "nome", "termini", "variabile", "valore")

    def __init__(self, tipo, figli=(), nome=None, termini=(), variabile=None, valore=None):
        self.tipo = tipo
        self.figli = figli
        self.nome = nome            # nome del predicato
        self.termini = termini      # argomenti del predicato o dell'uguaglianza
        self.variabile = variabile  # variabile del quantificatore
        self.valore = valore        # per le costanti ⊤ e ⊥ e per "=" / "≠"


def _tokenizza_predicati(testo):
    tokens = []
    i, n = 0, len(testo)
    simboli = sorted(list(_SIMBOLI) + list(_SIMBOLI_PREDICATI), key=len, reverse=True)
    while i < n:
        ch = testo[i]
        if ch.isspace():
            i += 1
            continue
        for simbolo in simboli:
            if testo.startswith(simbolo, i):
                if simbolo in _SIMBOLI_PREDICATI:
                    tipo, valore = _SIMBOLI_PREDICATI[simbolo]
                else:
                    valore = _SIMBOLI[simbolo]
                    tipo = simbolo if simbolo in "()" else "const" if isinstance(valore, bool) else "op"
                tokens.append(Token(tipo, valore, i, simbolo))
                i += len(simbolo)
                break
        else:
            if ch.isalnum() or ch == "_":
                j = i + 1
                while j < n and _carattere_di_nome(testo[j]):
                    j += 1
                parola = testo[i:j]
                k = j
                while k < n and testo[k].isspace():
                    k += 1
                segue_parentesi = k < n and testo[k] == "("
                chiave = parola.casefold()
                if ch.isdigit():
                    tokens.append(Token("num", parola, i, parola))
                elif segue_parentesi:
                    tokens.append(Token("id", parola, i, parola))
                elif chiave in _PAROLE_QUANTIFICATORI:
                    tokens.append(Token("quant", _PAROLE_QUANTIFICATORI[chiave], i, parola))
                elif chiave in _PAROLE:
                    valore = _PAROLE[chiave]
                    tokens.append(Token("const" if isinstance(valore, bool) else "op", valore, i, parola))
                elif parola in _COSTANTI_MAIUSCOLE:
                    tokens.append(Token("const", _COSTANTI_MAIUSCOLE[parola], i, parola))
                else:
                    tokens.append(Token("id", parola, i, parola))
                i = j
            else:
                messaggio = f"Simbolo «{ch}» non riconosciuto {_al_carattere(i)}"
                if ch in _SUGGERIMENTI and ch not in "=<>-":
                    messaggio += f" ({_SUGGERIMENTI[ch]})"
                raise FormulaError(messaggio + ".", i)
    return tokens


class _LettorePredicati:
    """Parser a discesa ricorsiva per le formule con predicati e quantificatori."""

    def __init__(self, testo):
        self.testo = testo
        self.tokens = _tokenizza_predicati(testo)
        self.pos = 0
        self.annidamento = 0

    def guarda(self, avanti=0):
        k = self.pos + avanti
        return self.tokens[k] if k < len(self.tokens) else None

    def prendi(self):
        token = self.guarda()
        self.pos += 1
        return token

    def errore_fine(self, cosa):
        ultimo = self.tokens[-1]
        return FormulaError(f"La formula finisce troppo presto: dopo «{ultimo.testo}» "
                            f"{_al_carattere(ultimo.posizione)} manca {cosa}.", ultimo.posizione, len(ultimo.testo))

    def leggi(self):
        if not self.tokens:
            raise FormulaError("La formula è vuota.")
        radice = self.espressione(0)
        token = self.guarda()
        if token is not None:
            if token.tipo == ")":
                raise FormulaError(f"Parentesi chiusa «)» in più {_al_carattere(token.posizione)}: "
                                   f"non c'è una parentesi aperta da chiudere.", token.posizione)
            raise FormulaError(f"Manca un connettivo prima di «{token.testo}» {_al_carattere(token.posizione)}.",
                               token.posizione, len(token.testo))
        return radice

    def espressione(self, livello_minimo):
        self.annidamento += 1
        if self.annidamento > 150:
            raise FormulaError("La formula è troppo annidata.")
        sinistra = self.unario()
        while True:
            token = self.guarda()
            if token is None or token.tipo != "op" or token.valore == NEG:
                break
            livello = PRECEDENZA[token.valore]
            if livello < livello_minimo:
                break
            self.prendi()
            if self.guarda() is None:
                raise self.errore_fine("una formula")
            prossimo = livello if token.valore in ASSOCIATIVI_A_DESTRA else livello + 1
            destra = self.espressione(prossimo)
            sinistra = NodoPredicati(token.valore, (sinistra, destra))
        self.annidamento -= 1
        return sinistra

    def termine(self, dopo):
        token = self.prendi()
        if token is None:
            raise self.errore_fine("un argomento")
        if token.tipo not in ("id", "num"):
            raise FormulaError(f"Dopo {dopo} serve il nome di una variabile o di un elemento, non «{token.testo}» "
                               f"{_al_carattere(token.posizione)}.", token.posizione, len(token.testo))
        return token.valore

    def unario(self):
        token = self.prendi()
        if token is None:
            raise self.errore_fine("una formula")
        if token.tipo == "op" and token.valore == NEG:
            return NodoPredicati(NEG, (self.unario(),))
        if token.tipo == "quant":
            variabili = [self.variabile_quantificata(token)]
            while self.guarda() is not None and self.guarda().tipo == ",":
                self.prendi()
                variabili.append(self.variabile_quantificata(token))
            if self.guarda() is not None and self.guarda().tipo == ".":
                self.prendi()
                corpo = self.espressione(0)
            else:
                corpo = self.unario()
            for variabile in reversed(variabili):
                corpo = NodoPredicati(token.valore, (corpo,), variabile=variabile)
            return corpo
        if token.tipo == "(":
            if self.guarda() is not None and self.guarda().tipo == ")":
                raise FormulaError(f"Parentesi vuote «()» {_al_carattere(token.posizione)}: dentro manca una formula.",
                                   token.posizione, 2)
            interno = self.espressione(0)
            chiusa = self.prendi()
            if chiusa is None or chiusa.tipo != ")":
                raise FormulaError(f"Parentesi non chiusa {_al_carattere(token.posizione)}: manca «)».", token.posizione)
            return interno
        if token.tipo == "const":
            return NodoPredicati("const", valore=token.valore)
        if token.tipo in ("id", "num"):
            seguente = self.guarda()
            if seguente is not None and seguente.tipo == "=":
                self.prendi()
                return NodoPredicati("=", termini=(token.valore, self.termine(f"«{seguente.testo}»")),
                                     valore=seguente.valore == UGUALE)
            if token.tipo == "num" and token.valore in ("0", "1"):
                return NodoPredicati("const", valore=token.valore == "1")
            if token.tipo == "num":
                raise FormulaError(f"«{token.testo}» {_al_carattere(token.posizione)} non è una formula: un numero "
                                   f"può stare solo dentro un predicato, come P({token.testo}).", token.posizione,
                                   len(token.testo))
            if seguente is not None and seguente.tipo == "(":
                aperta = self.prendi()
                termini = [self.termine(f"«{token.testo}(»")]
                while self.guarda() is not None and self.guarda().tipo == ",":
                    self.prendi()
                    termini.append(self.termine("la virgola"))
                chiusa = self.prendi()
                if chiusa is None or chiusa.tipo != ")":
                    raise FormulaError(f"Gli argomenti di «{token.testo}» {_al_carattere(aperta.posizione)} vanno "
                                       f"separati da virgole e chiusi con «)».", aperta.posizione)
                return NodoPredicati("pred", nome=token.valore, termini=tuple(termini))
            return NodoPredicati("pred", nome=token.valore, termini=())
        if token.tipo == ")":
            raise FormulaError(f"Manca una formula prima di «)» {_al_carattere(token.posizione)}.", token.posizione)
        raise FormulaError(f"Simbolo inatteso «{token.testo}» {_al_carattere(token.posizione)}: qui serve una formula.",
                           token.posizione, len(token.testo))

    def variabile_quantificata(self, quantificatore):
        token = self.prendi()
        if token is None:
            raise self.errore_fine("la variabile del quantificatore")
        if token.tipo != "id":
            raise FormulaError(f"Dopo «{quantificatore.testo}» {_al_carattere(quantificatore.posizione)} serve il nome "
                               f"di una variabile, per esempio {quantificatore.valore}x.", token.posizione,
                               len(token.testo))
        return token.valore


class FormulaPredicati:
    """Formula con predicati già letta.

      radice       l'albero (NodoPredicati)
      testo        la formula riscritta con i simboli
      predicati    nome -> numero di argomenti (0 per le proposizioni)
      costanti     i nomi usati come argomenti che non sono variabili quantificate
      quantificata True se contiene almeno un quantificatore
      variabili_quantificate  i nomi delle variabili usate dai quantificatori
      avvisi       frasi che segnalano probabili errori (la formula però è valida)
    """

    def __init__(self, testo):
        self.radice = _LettorePredicati(testo).leggi()
        self.predicati = {}
        self.costanti = set()
        self.quantificata = False
        self.variabili_quantificate = set()
        self.avvisi = []
        pila = [(self.radice, frozenset())]
        while pila:
            nodo, legate = pila.pop()
            if nodo.tipo in (PER_OGNI, ESISTE):
                self.quantificata = True
                self.variabili_quantificate.add(nodo.variabile)
                if not _usa_variabile(nodo.figli[0], nodo.variabile):
                    self.avvisi.append(f"La variabile «{nodo.variabile}» di {nodo.tipo}{nodo.variabile} non compare "
                                       f"nella formula che segue: forse manca la variabile, come in "
                                       f"{nodo.tipo}x P(x)?")
                pila.append((nodo.figli[0], legate | {nodo.variabile}))
                continue
            if nodo.tipo == "pred":
                arita = len(nodo.termini)
                if self.predicati.setdefault(nodo.nome, arita) != arita:
                    raise FormulaError(f"Il predicato «{nodo.nome}» è usato una volta con {self.predicati[nodo.nome]} "
                                       f"e una volta con {arita} argomenti: deve averne sempre lo stesso numero.")
            if nodo.tipo in ("pred", "="):
                self.costanti.update(t for t in nodo.termini if t not in legate)
            pila.extend((f, legate) for f in nodo.figli)
        for nome in sorted(self.costanti & self.variabili_quantificate):
            self.avvisi.append(f"La variabile «{nome}» compare anche fuori dal campo d'azione del suo quantificatore. "
                               f"Forse mancano le parentesi: per esempio ∀{nome} (P({nome}) → Q({nome})) invece di "
                               f"∀{nome} P({nome}) → Q({nome}).")
        clash = self.costanti & set(self.predicati)
        if clash:
            nome = sorted(clash)[0]
            raise FormulaError(f"«{nome}» è usato sia come predicato sia come argomento: usa due nomi diversi.")
        self.testo = testo_predicati(self.radice)


def _usa_variabile(nodo, variabile):
    """True se la variabile compare libera nel nodo (cioè non legata da un quantificatore più interno)."""
    pila = [nodo]
    while pila:
        n = pila.pop()
        if n.tipo in (PER_OGNI, ESISTE) and n.variabile == variabile:
            continue
        if n.tipo in ("pred", "=") and variabile in n.termini:
            return True
        pila.extend(n.figli)
    return False


def leggi_predicati(testo):
    """Legge una formula con predicati e quantificatori (solleva FormulaError con la posizione dell'errore)."""
    return testo if isinstance(testo, FormulaPredicati) else FormulaPredicati(testo)


def testo_predicati(nodo, ambiente=None, dentro=False):
    """La formula scritta con i simboli; con `ambiente` le variabili libere sono sostituite dai loro valori."""
    ambiente = ambiente or {}
    tipo = nodo.tipo
    if tipo == "pred":
        termini = [ambiente.get(t, t) for t in nodo.termini]
        return f"{nodo.nome}({', '.join(termini)})" if termini else nodo.nome
    if tipo == "=":
        a, b = (ambiente.get(t, t) for t in nodo.termini)
        testo = f"{a} {UGUALE if nodo.valore else DIVERSO} {b}"
        return f"({testo})" if dentro else testo
    if tipo == "const":
        return "⊤" if nodo.valore else "⊥"
    if tipo == NEG:
        return NEG + testo_predicati(nodo.figli[0], ambiente, True)
    if tipo in (PER_OGNI, ESISTE):
        interno = {k: v for k, v in ambiente.items() if k != nodo.variabile}
        corpo = nodo.figli[0]
        testo_corpo = testo_predicati(corpo, interno, True)
        return f"{tipo}{nodo.variabile} {testo_corpo}"
    sinistra, destra = nodo.figli
    testo_sinistra = testo_predicati(sinistra, ambiente, True)
    if sinistra.tipo == tipo and tipo in CATENE_SENZA_PARENTESI:
        testo_sinistra = testo_sinistra[1:-1]
    testo = f"{testo_sinistra} {tipo} {testo_predicati(destra, ambiente, True)}"
    return f"({testo})" if dentro else testo


# ---------- modelli finiti ----------

def _elementi(testo, che_cosa):
    """Nomi separati da virgole o spazi, con o senza parentesi graffe."""
    pulito = testo.strip()
    if pulito.startswith("{") and pulito.endswith("}"):
        pulito = pulito[1:-1]
    nomi = [n for n in re.split(r"[\s,;]+", pulito) if n]
    for nome in nomi:
        if not all(_carattere_di_nome(c) for c in nome):
            raise FormulaError(f"«{nome}» non è un nome valido per {che_cosa}: usa lettere, numeri e _.")
    return nomi


def leggi_dominio(testo):
    """Il dominio scritto come «a, b, c» oppure «{1, 2, 3}»: lista di nomi senza ripetizioni."""
    nomi = list(dict.fromkeys(_elementi(testo, "un elemento")))
    if not nomi:
        raise FormulaError("Il dominio è vuoto: scrivi almeno un elemento, per esempio a, b, c.")
    if len(nomi) > MAX_ELEMENTI_DOMINIO:
        raise FormulaError(f"Il dominio ha {len(nomi)} elementi: il massimo è {MAX_ELEMENTI_DOMINIO}.")
    return nomi


def leggi_relazione(testo, arita, dominio, nome="il predicato"):
    """Gli elementi (o le coppie, terne...) per cui il predicato è vero, scritti come «a, c» o «(a, b), (b, c)».

    Per arità 0 (proposizioni) si scrive V oppure F. Restituisce un insieme di tuple (oppure True/False).
    """
    if arita == 0:
        valore = leggi_valore(testo) if testo.strip() else False
        if valore is None:
            raise FormulaError(f"Per {nome} scrivi V oppure F.")
        return valore
    pulito = testo.strip()
    if pulito.startswith("{") and pulito.endswith("}"):
        pulito = pulito[1:-1]
    tuple_ = set()
    if arita == 1:
        gruppi = [[n] for n in _elementi(pulito, "un elemento")]
    else:
        gruppi = [_elementi(g, "un elemento") for g in re.findall(r"[(<\[]([^)>\]]*)[)>\]]", pulito)]
        resto = re.sub(r"[(<\[][^)>\]]*[)>\]]", "", pulito)
        if resto.strip(" ,;"):
            raise FormulaError(f"Per {nome} scrivi le {_nome_tuple(arita)} tra parentesi, per esempio "
                               f"({', '.join(dominio[:1] * arita) or 'a, b'}).")
    for gruppo in gruppi:
        if len(gruppo) != arita:
            raise FormulaError(f"In {nome} «({', '.join(gruppo)})» ha {len(gruppo)} elementi: ne servono {arita}.")
        for elemento in gruppo:
            if elemento not in dominio:
                raise FormulaError(f"In {nome} «{elemento}» non è un elemento del dominio.")
        tuple_.add(tuple(gruppo))
    return tuple_


def _nome_tuple(arita):
    return {2: "coppie", 3: "terne"}.get(arita, f"{arita}-uple")


def testo_relazione(valori, arita):
    """L'opposto di `leggi_relazione`: «a, c» oppure «(a, b), (b, c)» oppure V/F."""
    if arita == 0:
        return "V" if valori else "F"
    ordinate = sorted(valori)
    if arita == 1:
        return ", ".join(t[0] for t in ordinate)
    return ", ".join("(" + ", ".join(t) + ")" for t in ordinate)


def _valuta_predicati(nodo, ambiente, dominio, interpretazione, contatore):
    contatore[0] += 1
    if contatore[0] > LIMITE_PASSI_PREDICATI:
        raise FormulaError("La verifica richiede troppi passi: riduci il dominio o il numero di quantificatori.")
    tipo = nodo.tipo
    if tipo == "pred":
        if not nodo.termini:
            return bool(interpretazione.get(nodo.nome, False))
        return tuple(ambiente.get(t, t) for t in nodo.termini) in interpretazione.get(nodo.nome, ())
    if tipo == "=":
        a, b = (ambiente.get(t, t) for t in nodo.termini)
        return (a == b) == nodo.valore
    if tipo == "const":
        return nodo.valore
    if tipo == NEG:
        return not _valuta_predicati(nodo.figli[0], ambiente, dominio, interpretazione, contatore)
    if tipo in (PER_OGNI, ESISTE):
        cerca = tipo == ESISTE
        for elemento in dominio:
            interno = dict(ambiente)
            interno[nodo.variabile] = elemento
            if _valuta_predicati(nodo.figli[0], interno, dominio, interpretazione, contatore) == cerca:
                return cerca
        return not cerca
    a = _valuta_predicati(nodo.figli[0], ambiente, dominio, interpretazione, contatore)
    b = _valuta_predicati(nodo.figli[1], ambiente, dominio, interpretazione, contatore)
    return bool(_applica(tipo, [int(a), int(b)], 1))


def _controlla_modello(formula, dominio, interpretazione):
    mancanti = sorted(c for c in formula.costanti if c not in dominio)
    if mancanti:
        nome = mancanti[0]
        if nome in formula.variabili_quantificate:
            raise FormulaError(f"La variabile «{nome}» compare fuori dal campo d'azione del suo quantificatore. "
                               f"Forse mancano le parentesi: per esempio ∀{nome} (P({nome}) → Q({nome})) invece di "
                               f"∀{nome} P({nome}) → Q({nome}).")
        raise FormulaError(f"«{nome}» compare nella formula ma non è un elemento del dominio "
                           f"(e non è una variabile quantificata).")
    for nome, arita in formula.predicati.items():
        valori = interpretazione.get(nome, False if arita == 0 else set())
        if arita == 0:
            continue
        for tupla in valori:
            if len(tupla) != arita or any(e not in dominio for e in tupla):
                raise FormulaError(f"L'interpretazione di «{nome}» contiene ({', '.join(tupla)}), "
                                   f"che non va bene per questo dominio.")


def valuta_predicati(formula, dominio, interpretazione):
    """Verifica la formula nel modello finito (dominio + interpretazione dei predicati).

    `interpretazione` associa a ogni predicato l'insieme delle tuple per cui è vero (True/False per le
    proposizioni). Restituisce un dizionario con:
      valore       True o False
      formula      la formula riscritta
      spiegazione  righe che spiegano il risultato, con i testimoni e i controesempi dei quantificatori
    """
    formula = leggi_predicati(formula)
    dominio = list(dominio)
    _controlla_modello(formula, dominio, interpretazione)
    contatore = [0]
    valore = _valuta_predicati(formula.radice, {}, dominio, interpretazione, contatore)
    righe = []
    _spiega(formula.radice, {}, dominio, interpretazione, 0, righe, contatore)
    return {"valore": valore, "formula": formula.testo, "spiegazione": righe}


def _spiega(nodo, ambiente, dominio, interpretazione, livello, righe, contatore, massimo=40):
    """Spiega perché il nodo è vero o falso, seguendo i quantificatori e i connettivi principali."""
    if len(righe) >= massimo:
        return
    valore = _valuta_predicati(nodo, ambiente, dominio, interpretazione, contatore)
    testo = testo_predicati(nodo, ambiente)
    rientro = "    " * livello
    parola = "vera" if valore else "falsa"
    tipo = nodo.tipo
    if tipo in (PER_OGNI, ESISTE):
        corpo, v = nodo.figli[0], nodo.variabile
        valori = []
        for elemento in dominio:
            interno = dict(ambiente)
            interno[v] = elemento
            valori.append((elemento, _valuta_predicati(corpo, interno, dominio, interpretazione, contatore)))
        veri = [e for e, x in valori if x]
        falsi = [e for e, x in valori if not x]
        if tipo == PER_OGNI and valore:
            righe.append(f"{rientro}✓ {testo} è vera: vale per ogni {v} del dominio ({', '.join(dominio)}).")
        elif tipo == PER_OGNI:
            righe.append(f"{rientro}✗ {testo} è falsa: non vale per {v} = {falsi[0]}"
                         + (f" (e nemmeno per {', '.join(falsi[1:])})" if len(falsi) > 1 else "") + ".")
            _spiega(corpo, {**ambiente, v: falsi[0]}, dominio, interpretazione, livello + 1, righe, contatore)
        elif valore:
            righe.append(f"{rientro}✓ {testo} è vera: per esempio {v} = {veri[0]}"
                         + (f" (vale anche per {', '.join(veri[1:])})" if len(veri) > 1 else "") + ".")
            _spiega(corpo, {**ambiente, v: veri[0]}, dominio, interpretazione, livello + 1, righe, contatore)
        else:
            righe.append(f"{rientro}✗ {testo} è falsa: nessun {v} del dominio la rende vera.")
        return
    if tipo == "pred":
        if nodo.termini:
            tupla = tuple(ambiente.get(t, t) for t in nodo.termini)
            elemento = tupla[0] if len(tupla) == 1 else "(" + ", ".join(tupla) + ")"
            righe.append(f"{rientro}{'✓' if valore else '✗'} {testo} è {parola}: {elemento} "
                         f"{'∈' if valore else '∉'} {nodo.nome}.")
        else:
            righe.append(f"{rientro}{'✓' if valore else '✗'} {testo} è {parola} nel modello.")
        return
    if tipo in ("=", "const"):
        righe.append(f"{rientro}{'✓' if valore else '✗'} {testo} è {parola}.")
        return
    if tipo == NEG:
        righe.append(f"{rientro}{'✓' if valore else '✗'} {testo} è {parola} perché "
                     f"{testo_predicati(nodo.figli[0], ambiente)} è {'falsa' if valore else 'vera'}.")
        _spiega(nodo.figli[0], ambiente, dominio, interpretazione, livello + 1, righe, contatore, massimo)
        return
    a, b = nodo.figli
    va = _valuta_predicati(a, ambiente, dominio, interpretazione, contatore)
    vb = _valuta_predicati(b, ambiente, dominio, interpretazione, contatore)
    righe.append(f"{rientro}{'✓' if valore else '✗'} {testo} è {parola}: "
                 f"{testo_predicati(a, ambiente)} è {'V' if va else 'F'}, {testo_predicati(b, ambiente)} è "
                 f"{'V' if vb else 'F'}.")
    for figlio in (a, b):
        if figlio.tipo not in ("pred", "=", "const"):
            _spiega(figlio, ambiente, dominio, interpretazione, livello + 1, righe, contatore, massimo)


# ---------- ricerca di modelli e controesempi ----------

def _radica(radice, dominio, c, limite=300_000):
    """La formula «tradotta» sul dominio: ∀ diventa una congiunzione, ∃ una disgiunzione e ogni
    predicato applicato a elementi diventa una variabile proposizionale, per esempio «R(a,b)»."""
    creati = [0]

    def nodo(op, figli=(), nome=None, valore=None):
        creati[0] += 1
        if creati[0] > limite:
            raise FormulaError("Con questo dominio la formula diventa troppo grande da esaminare: "
                               "prova con meno elementi.")
        return c.nodo(op, figli, nome, valore)

    def catena(op, elementi):
        risultato = elementi[0]
        for e in elementi[1:]:
            risultato = nodo(op, (risultato, e))
        return risultato

    def visita(n, ambiente):
        tipo = n.tipo
        if tipo == "pred":
            termini = [ambiente.get(t, t) for t in n.termini]
            return nodo("var", nome=f"{n.nome}({','.join(termini)})" if termini else n.nome)
        if tipo == "=":
            a, b = (ambiente.get(t, t) for t in n.termini)
            return nodo("const", valore=(a == b) == n.valore)
        if tipo == "const":
            return nodo("const", valore=n.valore)
        if tipo in (PER_OGNI, ESISTE):
            istanze = [visita(n.figli[0], {**ambiente, n.variabile: e}) for e in dominio]
            return catena(AND if tipo == PER_OGNI else OR, istanze)
        return nodo(tipo, tuple(visita(f, ambiente) for f in n.figli))

    return visita(radice, {})


def _nomi_nuovi(quanti, gia_usati):
    nomi, k = [], 0
    while len(nomi) < quanti:
        nome = chr(ord("a") + k) if k < 26 else f"e{k - 25}"
        if nome not in gia_usati:
            nomi.append(nome)
        k += 1
    return nomi


def cerca_modello(formula, vera=True, max_elementi=MAX_ELEMENTI_RICERCA, limite_secondi=LIMITE_SECONDI_SAT):
    """Cerca un modello finito in cui la formula è vera (vera=True) o falsa (vera=False, un controesempio).

    Prova domini di 1, 2, ... max_elementi elementi (le costanti della formula sono sempre elementi
    diversi tra loro). Restituisce None se non c'è nessun modello fino a quella dimensione, altrimenti
    un dizionario con: dominio, interpretazione (nome -> insieme di tuple, o True/False), elementi.
    """
    formula = leggi_predicati(formula)
    costanti = sorted(formula.costanti)
    for quanti in range(max(1, len(costanti)), max(max_elementi, len(costanti)) + 1):
        dominio = costanti + _nomi_nuovi(quanti - len(costanti), set(costanti) | set(formula.predicati))
        c = _Costruttore()
        traduzione = _radica(formula.radice, dominio, c)
        obiettivo = traduzione if vera else c.nodo(NEG, (traduzione,))
        risultato = sat(obiettivo, limite_secondi)
        if risultato["soddisfacibile"] is None:
            raise FormulaError(f"La ricerca non ha trovato una risposta entro {limite_secondi} secondi "
                               f"con {quanti} elementi: prova con meno elementi.")
        if risultato["soddisfacibile"]:
            modello = risultato["modello"]
            interpretazione = {}
            for nome, arita in formula.predicati.items():
                if arita == 0:
                    interpretazione[nome] = bool(modello.get(nome, False))
                else:
                    interpretazione[nome] = {tupla for tupla in itertools.product(dominio, repeat=arita)
                                             if modello.get(f"{nome}({','.join(tupla)})", False)}
            if valuta_predicati(formula, dominio, interpretazione)["valore"] != vera:
                raise RuntimeError("La ricerca del modello ha prodotto un risultato sbagliato.")
            return {"dominio": dominio, "interpretazione": interpretazione, "elementi": quanti}
    return None


# ---------- tableaux semantici ----------
#
# Per dimostrare che le premesse implicano la conclusione si scrivono le premesse e la NEGAZIONE
# della conclusione, poi si scompongono le formule:
#   α (una sola strada):  A ∧ B  dà A e B;  ¬(A ∨ B) dà ¬A e ¬B;  ¬(A → B) dà A e ¬B;  ¬¬A dà A
#   β (il ramo si divide): A ∨ B  dà A | B;  A → B dà ¬A | B;  ¬(A ∧ B) dà ¬A | ¬B;  A ↔ B dà A,B | ¬A,¬B
#   δ (esiste):  ∃x φ  dà φ con una costante nuova;  ¬∀x φ  dà ¬φ con una costante nuova
#   γ (per ogni): ∀x φ  dà φ per ogni costante del ramo;  ¬∃x φ  dà ¬φ per ogni costante del ramo
# Un ramo si chiude quando contiene una formula e la sua negazione. Se tutti i rami si chiudono la
# conclusione segue dalle premesse; un ramo aperto e completo descrive un controesempio.

MAX_FORMULE_TABLEAU = 600
MAX_COSTANTI_TABLEAU = 6


def _da_formula(f):
    """Formula proposizionale -> NodoPredicati (le variabili diventano proposizioni)."""
    risultati = {}
    for nodo in _postordine(f):
        if nodo.op == "var":
            risultati[id(nodo)] = NodoPredicati("pred", nome=nodo.nome, termini=())
        elif nodo.op == "const":
            risultati[id(nodo)] = NodoPredicati("const", valore=nodo.valore)
        else:
            risultati[id(nodo)] = NodoPredicati(nodo.op, tuple(risultati[id(x)] for x in nodo.figli))
    return risultati[id(f)]


def _non(n):
    return NodoPredicati(NEG, (n,))


def _sostituisci(nodo, variabile, costante):
    tipo = nodo.tipo
    if tipo in ("pred", "="):
        return NodoPredicati(tipo, nome=nodo.nome, valore=nodo.valore,
                             termini=tuple(costante if t == variabile else t for t in nodo.termini))
    if tipo == "const":
        return nodo
    if tipo in (PER_OGNI, ESISTE):
        if nodo.variabile == variabile:
            return nodo
        return NodoPredicati(tipo, (_sostituisci(nodo.figli[0], variabile, costante),), variabile=nodo.variabile)
    return NodoPredicati(tipo, tuple(_sostituisci(f, variabile, costante) for f in nodo.figli))


def _regola_tableau(n):
    """Che cosa fare con una formula: (tipo, nome della regola, dati). tipo è α, β, δ, γ oppure None."""
    t = n.tipo
    if t == NEG:
        a = n.figli[0]
        u = a.tipo
        if u == NEG:
            return "α", "¬¬", [a.figli[0]]
        if u in (PER_OGNI, ESISTE):
            corpo = _non(a.figli[0])
            return ("δ" if u == PER_OGNI else "γ"), f"¬{u}", (a.variabile, corpo)
        if u in BINARI:
            x, y = a.figli
            regole = {
                OR: ("α", [_non(x), _non(y)]), IMP: ("α", [x, _non(y)]), NAND: ("α", [x, y]),
                NOR: ("β", [[x], [y]]), AND: ("β", [[_non(x)], [_non(y)]]),
                IFF: ("β", [[x, _non(y)], [_non(x), y]]), XOR: ("β", [[x, y], [_non(x), _non(y)]]),
            }
            tipo, dati = regole[u]
            return tipo, f"¬{u}", dati
        return None, None, None
    if t in BINARI:
        x, y = n.figli
        regole = {
            AND: ("α", [x, y]), NOR: ("α", [_non(x), _non(y)]),
            OR: ("β", [[x], [y]]), IMP: ("β", [[_non(x)], [y]]), NAND: ("β", [[_non(x)], [_non(y)]]),
            IFF: ("β", [[x, y], [_non(x), _non(y)]]), XOR: ("β", [[x, _non(y)], [_non(x), y]]),
        }
        tipo, dati = regole[t]
        return tipo, t, dati
    if t in (PER_OGNI, ESISTE):
        return ("γ" if t == PER_OGNI else "δ"), t, (n.variabile, n.figli[0])
    return None, None, None


def _contraddittoria(n):
    """⊥, ¬⊤, t ≠ t e ¬(t = t) chiudono il ramo da sole."""
    if n.tipo == "const":
        return not n.valore
    if n.tipo == NEG and n.figli[0].tipo == "const":
        return n.figli[0].valore
    if n.tipo == "=" and n.termini[0] == n.termini[1]:
        return not n.valore
    if n.tipo == NEG and n.figli[0].tipo == "=" and n.figli[0].termini[0] == n.figli[0].termini[1]:
        return n.figli[0].valore
    return False


class _Tableau:
    def __init__(self):
        self.numero = 0
        self.sospeso = False

    def nuova(self, formula, ramo, nodo_albero, origine, regola):
        if self.numero >= MAX_FORMULE_TABLEAU:
            raise _TroppoGrande()
        self.numero += 1
        voce = {"numero": self.numero, "testo": testo_predicati(formula), "da": origine, "regola": regola}
        nodo_albero["formule"].append(voce)
        ramo["formule"].append((self.numero, formula, voce["testo"]))
        if voce["testo"] not in ramo["testi"]:
            ramo["testi"][voce["testo"]] = self.numero
        for c in _costanti_di(formula):
            if c not in ramo["costanti"]:
                ramo["costanti"].append(c)
        return self.numero

    @staticmethod
    def chiusura(ramo):
        for numero, formula, testo in ramo["formule"]:
            if _contraddittoria(formula):
                return f"{testo} ({numero}) è contraddittoria"
            opposta = testo_predicati(_non(formula))
            if opposta in ramo["testi"]:
                return f"{testo} ({numero}) e {opposta} ({ramo['testi'][opposta]})"
        return None

    def espandi(self, ramo, nodo_albero, costanti_iniziali):
        while True:
            motivo = self.chiusura(ramo)
            if motivo:
                nodo_albero["stato"], nodo_albero["motivo"] = "chiuso", motivo
                return
            scelta = self.prossima(ramo)
            if scelta is None:
                nodo_albero["stato"] = "aperto"
                return
            numero, formula, tipo, nome, dati = scelta
            if tipo == "α":
                ramo["usate"].add(numero)
                for parte in dati:
                    self.nuova(parte, ramo, nodo_albero, numero, f"α {nome}")
            elif tipo == "δ":
                ramo["usate"].add(numero)
                if len(ramo["costanti"]) >= MAX_COSTANTI_TABLEAU:
                    self.sospeso = True
                    nodo_albero["stato"] = "sospeso"
                    return
                variabile, corpo = dati
                nuova = _nomi_nuovi(1, set(ramo["costanti"]) | ramo["nomi_usati"])[0]
                ramo["nomi_usati"].add(nuova)
                self.nuova(_sostituisci(corpo, variabile, nuova), ramo, nodo_albero, numero,
                           f"δ {nome}, {nuova} nuova")
            elif tipo == "γ":
                variabile, corpo, costante = dati
                ramo["istanze"].setdefault(numero, set()).add(costante)
                if costante not in ramo["costanti"]:
                    ramo["costanti"].append(costante)
                self.nuova(_sostituisci(corpo, variabile, costante), ramo, nodo_albero, numero,
                           f"γ {nome}, {variabile} = {costante}")
            else:  # β: il ramo si divide
                ramo["usate"].add(numero)
                nodo_albero["regola_divisione"] = f"β {nome} ({numero})"
                for alternativa in dati:
                    figlio = {"formule": [], "figli": [], "stato": None, "motivo": ""}
                    nodo_albero["figli"].append(figlio)
                    copia = {"formule": list(ramo["formule"]), "testi": dict(ramo["testi"]),
                             "usate": set(ramo["usate"]), "istanze": {k: set(v) for k, v in ramo["istanze"].items()},
                             "costanti": list(ramo["costanti"]), "nomi_usati": set(ramo["nomi_usati"])}
                    for parte in alternativa:
                        self.nuova(parte, copia, figlio, numero, f"β {nome}")
                    self.espandi(copia, figlio, costanti_iniziali)
                return

    @staticmethod
    def prossima(ramo):
        """La prossima regola da applicare: prima α, poi δ, poi β, infine γ."""
        candidati = {"α": None, "δ": None, "β": None}
        for numero, formula, testo in ramo["formule"]:
            if numero in ramo["usate"]:
                continue
            tipo, nome, dati = _regola_tableau(formula)
            if tipo in ("α", "δ") and candidati[tipo] is None:
                candidati[tipo] = (numero, formula, tipo, nome, dati)
            elif tipo == "β" and candidati["β"] is None:
                # β inutile se una delle due strade è già tutta nel ramo
                if any(all(testo_predicati(x) in ramo["testi"] for x in alt) for alt in dati):
                    ramo["usate"].add(numero)
                    continue
                candidati["β"] = (numero, formula, tipo, nome, dati)
        for tipo in ("α", "δ", "β"):
            if candidati[tipo] is not None:
                return candidati[tipo]
        for numero, formula, testo in ramo["formule"]:
            tipo, nome, dati = _regola_tableau(formula)
            if tipo != "γ":
                continue
            variabile, corpo = dati
            costanti = ramo["costanti"] or ["a"]
            fatte = ramo["istanze"].get(numero, set())
            for costante in costanti:
                if costante not in fatte:
                    return numero, formula, "γ", nome, (variabile, corpo, costante)
        return None


class _TroppoGrande(Exception):
    pass


def _costanti_di(formula):
    trovate, pila = [], [(formula, frozenset())]
    while pila:
        n, legate = pila.pop()
        if n.tipo in (PER_OGNI, ESISTE):
            pila.append((n.figli[0], legate | {n.variabile}))
            continue
        if n.tipo in ("pred", "="):
            trovate.extend(t for t in n.termini if t not in legate and t not in trovate)
        pila.extend((f, legate) for f in n.figli)
    return trovate


def _leggi_per_tableau(testo):
    """Prima prova come formula proposizionale, poi come formula con predicati."""
    try:
        return _da_formula(parse(testo)), False
    except FormulaError:
        formula = leggi_predicati(testo)
        return formula.radice, bool(formula.quantificata or any(formula.predicati.values()))


def tableau(premesse, conclusione):
    """Tableau semantico per «le premesse implicano la conclusione» (senza premesse: «è valida»).

    Restituisce un dizionario con:
      albero         il tableau: ogni nodo ha formule (numero, testo, da, regola), figli,
                     stato ("chiuso", "aperto", "sospeso" o None), motivo della chiusura e
                     regola_divisione (se il ramo si divide)
      chiuso         True se tutti i rami sono chiusi: la conclusione segue dalle premesse
      concluso       False se la costruzione si è fermata per i limiti (con i quantificatori può non finire)
      controesempio  un modello del primo ramo aperto (dominio e interpretazione), se è completo
      predicati      True se ci sono quantificatori o predicati con argomenti
    """
    radici, con_predicati = [], False
    for numero, testo in enumerate(premesse, start=1):
        if isinstance(testo, str) and not testo.strip():
            continue
        try:
            formula, predicati = _leggi_per_tableau(testo)
        except FormulaError as errore:
            raise errore.con_prefisso(f"Premessa {numero}") from None
        radici.append((formula, "premessa"))
        con_predicati |= predicati
    try:
        formula, predicati = _leggi_per_tableau(conclusione)
    except FormulaError as errore:
        raise errore.con_prefisso("Conclusione") from None
    con_predicati |= predicati
    radici.append((_non(formula), "negazione della conclusione"))
    costruttore = _Tableau()
    albero = {"formule": [], "figli": [], "stato": None, "motivo": ""}
    ramo = {"formule": [], "testi": {}, "usate": set(), "istanze": {}, "costanti": [], "nomi_usati": set()}
    for formula, ruolo in radici:
        costruttore.nuova(formula, ramo, albero, None, ruolo)
    ramo["nomi_usati"] = set(ramo["costanti"])
    completo = True
    try:
        costruttore.espandi(ramo, albero, list(ramo["costanti"]))
    except _TroppoGrande:
        completo = False
    chiuso, aperto = True, None
    pila = [(albero, [])]
    while pila:
        nodo, sopra = pila.pop()
        percorso = sopra + nodo["formule"]
        if not nodo["figli"]:
            if nodo["stato"] != "chiuso":
                chiuso = False
                if nodo["stato"] == "aperto" and aperto is None:
                    aperto = (nodo, percorso)
                elif nodo["stato"] is None:
                    nodo["stato"] = "sospeso"
        pila.extend((f, percorso) for f in reversed(nodo["figli"]))
    concluso = completo and not costruttore.sospeso and (chiuso or aperto is not None)
    controesempio, da_ricerca = None, False
    if aperto is not None and not chiuso:
        controesempio = _modello_dal_ramo(aperto[1], [f for f, _ in radici], con_predicati)
        aperto[0]["modello"] = controesempio
        concluso = concluso or controesempio is not None
    if not chiuso and controesempio is None and con_predicati:
        # il tableau non finisce: si cerca un controesempio in un dominio piccolo
        testi = [testo for testo in premesse if isinstance(testo, str) and testo.strip()]
        insieme = " ∧ ".join([f"({t})" for t in testi] + [f"¬({conclusione})"])
        try:
            trovato = cerca_modello(insieme, vera=True, max_elementi=4)
        except FormulaError:
            trovato = None
        if trovato is not None:
            controesempio = {"dominio": trovato["dominio"], "interpretazione": trovato["interpretazione"]}
            concluso, da_ricerca = True, True
    return {"albero": albero, "chiuso": chiuso, "concluso": chiuso or concluso,
            "controesempio": controesempio, "controesempio_da_ricerca": da_ricerca,
            "predicati": con_predicati, "formule": costruttore.numero}


def _modello_dal_ramo(voci, radici, con_predicati):
    """Modello descritto da un ramo aperto: vero ciò che compare senza negazione. Lo restituisce solo se
    rende davvero vere tutte le formule di partenza."""
    atomi = []
    for voce in voci:
        try:
            nodo = _LettorePredicati(voce["testo"]).leggi()
        except FormulaError:
            continue
        if nodo.tipo == "pred":
            atomi.append(nodo)
    costanti = []
    for f in radici:
        costanti += [c for c in _costanti_di(f) if c not in costanti]
    for a in atomi:
        costanti += [c for c in a.termini if c not in costanti]
    dominio = costanti or ["a"]
    interpretazione = {}
    for a in atomi:
        if a.termini:
            interpretazione.setdefault(a.nome, set()).add(tuple(a.termini))
        else:
            interpretazione[a.nome] = True
    for f in radici:
        for nome, arita in _predicati_di(f).items():
            interpretazione.setdefault(nome, set() if arita else False)
    try:
        for f in radici:
            if not _valuta_predicati(f, {}, dominio, interpretazione, [0]):
                return None
    except FormulaError:
        return None
    if not con_predicati:
        return {"valori": {n: bool(v) for n, v in interpretazione.items()}}
    return {"dominio": dominio, "interpretazione": interpretazione}


def _predicati_di(formula):
    trovati, pila = {}, [formula]
    while pila:
        n = pila.pop()
        if n.tipo == "pred":
            trovati[n.nome] = len(n.termini)
        pila.extend(n.figli)
    return trovati


# ---------- deduzione naturale ----------
#
# Dimostrazioni nello stile di Fitch: ogni riga ha una formula, la regola usata e le righe citate.
# Un'ipotesi apre una sottodimostrazione (rientrata), che si chiude con una regola che la «scarica».

REGOLE_DEDUZIONE = {
    "Premessa": "premessa del ragionamento",
    "Ipotesi": "ipotesi: apre una sottodimostrazione",
    "R": "ripetizione di una riga già dimostrata",
    "∧I": "introduzione di ∧: da A e B si ricava A ∧ B",
    "∧E": "eliminazione di ∧: da A ∧ B si ricava A (oppure B)",
    "∨I": "introduzione di ∨: da A si ricava A ∨ B",
    "∨E": "eliminazione di ∨ (ragionamento per casi): da A ∨ B, A ⊢ C e B ⊢ C si ricava C",
    "→I": "introduzione di →: se dall'ipotesi A si ricava B, allora A → B",
    "→E": "eliminazione di → (modus ponens): da A → B e A si ricava B",
    "¬I": "introduzione di ¬: se dall'ipotesi A si arriva a ⊥, allora ¬A",
    "¬E": "eliminazione di ¬: da A e ¬A si ricava ⊥ (contraddizione)",
    "⊥E": "dal falso segue qualsiasi cosa (ex falso quodlibet)",
    "RAA": "riduzione all'assurdo: se dall'ipotesi ¬A si arriva a ⊥, allora A",
    "↔I": "introduzione di ↔: da A ⊢ B e B ⊢ A si ricava A ↔ B",
    "↔E": "eliminazione di ↔: da A ↔ B e A si ricava B (o viceversa)",
    "⊤I": "il vero si può sempre scrivere",
    "Def": "definizione del connettivo: A ⊕ B ≡ ¬(A ↔ B), A ↑ B ≡ ¬(A ∧ B), A ↓ B ≡ ¬(A ∨ B)",
}
MAX_RIGHE_DEDUZIONE = 400
_FALSO = Formula("const", valore=False)
_VERO = Formula("const", valore=True)


def _neg(a):
    return Formula(NEG, (a,))


def _bin(op, a, b):
    return Formula(op, (a, b))


def _definizione(f):
    """La formula che definisce ⊕, ↑ e ↓ con i connettivi di base."""
    a, b = f.figli
    return {XOR: _neg(_bin(IFF, a, b)), NAND: _neg(_bin(AND, a, b)), NOR: _neg(_bin(OR, a, b))}[f.op]


class _Deduzione:
    """Costruisce una dimostrazione in deduzione naturale (stile Fitch) riga per riga."""

    def __init__(self):
        self.righe = []
        self.ambiti = [{}]   # per ogni sottodimostrazione aperta: testo della formula -> riga

    # --- righe e sottodimostrazioni ---
    def disponibile(self, f):
        testo = to_text(f)
        for ambito in reversed(self.ambiti):
            if testo in ambito:
                return ambito[testo]
        return None

    def aggiungi(self, f, regola, riferimenti=(), ipotesi=False):
        if len(self.righe) >= MAX_RIGHE_DEDUZIONE:
            raise FormulaError("La dimostrazione diventa troppo lunga da mostrare: prova con premesse più semplici.")
        numero = len(self.righe) + 1
        self.righe.append({"numero": numero, "formula": f, "testo": to_text(f), "regola": regola,
                           "riferimenti": list(riferimenti), "livello": len(self.ambiti) - 1, "ipotesi": ipotesi})
        self.ambiti[-1].setdefault(to_text(f), numero)
        return numero

    def apri(self, f):
        self.ambiti.append({})
        return self.aggiungi(f, "Ipotesi", ipotesi=True)

    def chiudi(self, inizio, attesa):
        """Chiude la sottodimostrazione: l'ultima riga deve essere la formula attesa (se serve, si ripete)."""
        if to_text(self.righe[-1]["formula"]) != to_text(attesa) or self.righe[-1]["livello"] != len(self.ambiti) - 1:
            self.aggiungi(attesa, "R", [self.disponibile(attesa)])
        fine = len(self.righe)
        self.ambiti.pop()
        return (inizio, fine)

    def accessibili(self):
        numeri = sorted(n for ambito in self.ambiti for n in ambito.values())
        return [(n, self.righe[n - 1]["formula"]) for n in numeri]

    # --- ricerca della dimostrazione ---
    def piano(self, g, profondita, visti):
        """Come ottenere g «in avanti» con ∧E, →E e ↔E dalle righe disponibili (senza ipotesi)."""
        if self.disponibile(g):
            return ("c'è",)
        testo = to_text(g)
        if profondita == 0 or testo in visti:
            return None
        visti = visti | {testo}
        for n, f in self.accessibili():
            if f.op == AND and testo in (to_text(f.figli[0]), to_text(f.figli[1])):
                return ("∧E", n)
            if f.op == IMP and to_text(f.figli[1]) == testo:
                sotto = self.piano(f.figli[0], profondita - 1, visti)
                if sotto:
                    return ("→E", n, f.figli[0], sotto)
            if f.op == IFF:
                for da, a in ((0, 1), (1, 0)):
                    if to_text(f.figli[a]) == testo:
                        sotto = self.piano(f.figli[da], profondita - 1, visti)
                        if sotto:
                            return ("↔E", n, f.figli[da], sotto)
        return None

    def esegui(self, g, piano):
        if piano[0] == "c'è":
            return self.disponibile(g)
        if piano[0] == "∧E":
            return self.aggiungi(g, "∧E", [piano[1]])
        premessa = self.esegui(piano[2], piano[3])
        return self.aggiungi(g, piano[0], [piano[1], premessa])

    def dimostra(self, g):
        """Dimostra g nell'ambito attuale e restituisce il numero della riga."""
        n = self.disponibile(g)
        if n:
            return n
        p = self.piano(g, 4, frozenset())
        if p:
            return self.esegui(g, p)
        op = g.op
        if op == "const" and g.valore:
            return self.aggiungi(g, "⊤I")
        if op == "const":
            return self.falso()
        if op == AND:
            a, b = self.dimostra(g.figli[0]), self.dimostra(g.figli[1])
            return self.aggiungi(g, "∧I", [a, b])
        if op == IMP:
            i = self.apri(g.figli[0])
            self.dimostra(g.figli[1])
            return self.aggiungi(g, "→I", [self.chiudi(i, g.figli[1])])
        if op == NEG:
            i = self.apri(g.figli[0])
            self.falso()
            return self.aggiungi(g, "¬I", [self.chiudi(i, _FALSO)])
        if op == IFF:
            a, b = g.figli
            i = self.apri(a)
            self.dimostra(b)
            s1 = self.chiudi(i, b)
            j = self.apri(b)
            self.dimostra(a)
            s2 = self.chiudi(j, a)
            return self.aggiungi(g, "↔I", [s1, s2])
        if op in (XOR, NAND, NOR):
            return self.aggiungi(g, "Def", [self.dimostra(_definizione(g))])
        if op == OR:
            for k in (0, 1):
                p = self.piano(g.figli[k], 4, frozenset())
                if p:
                    return self.aggiungi(g, "∨I", [self.esegui(g.figli[k], p)])
        # ultima risorsa: riduzione all'assurdo
        i = self.apri(_neg(g))
        self.falso()
        return self.aggiungi(g, "RAA", [self.chiudi(i, _FALSO)])

    def falso(self):
        """Ricava ⊥ dalle righe disponibili (che sono contraddittorie), come in un tableau."""
        while True:
            n = self.contraddizione()
            if n:
                return n
            if self.passo_alfa():
                continue
            beta = self.scegli_beta()
            if beta is None:
                raise RuntimeError("Deduzione naturale: le ipotesi non sono contraddittorie.")
            return self.dividi(*beta)

    def contraddizione(self):
        n = self.disponibile(_FALSO)
        if n:
            return n
        for numero, f in self.accessibili():
            if f.op == NEG and f.figli[0].op == "const" and f.figli[0].valore:
                vero = self.disponibile(_VERO) or self.aggiungi(_VERO, "⊤I")
                return self.aggiungi(_FALSO, "¬E", [vero, numero])
            opposta = self.disponibile(_neg(f))
            if opposta:
                return self.aggiungi(_FALSO, "¬E", [numero, opposta])
        return None

    def passo_alfa(self):
        """Un passo «sicuro» (senza dividere): ∧E, →E, ↔E, doppia negazione, De Morgan..."""
        for n, f in self.accessibili():
            op = f.op
            if op == AND:
                for parte in f.figli:
                    if not self.disponibile(parte):
                        self.aggiungi(parte, "∧E", [n])
                        return True
            elif op == IMP and self.disponibile(f.figli[0]) and not self.disponibile(f.figli[1]):
                self.aggiungi(f.figli[1], "→E", [n, self.disponibile(f.figli[0])])
                return True
            elif op == IFF:
                for da, a in ((0, 1), (1, 0)):
                    if self.disponibile(f.figli[da]) and not self.disponibile(f.figli[a]):
                        self.aggiungi(f.figli[a], "↔E", [n, self.disponibile(f.figli[da])])
                        return True
            elif op in (XOR, NAND, NOR):
                d = _definizione(f)
                if not self.disponibile(d):
                    self.aggiungi(d, "Def", [n])
                    return True
            elif op == NEG:
                a = f.figli[0]
                if a.op == NEG and not self.disponibile(a.figli[0]):
                    # ¬¬A: per assurdo da ¬A
                    i = self.apri(_neg(a.figli[0]))
                    self.aggiungi(_FALSO, "¬E", [i, n])
                    self.aggiungi(a.figli[0], "RAA", [self.chiudi(i, _FALSO)])
                    return True
                if a.op == OR:
                    for parte in a.figli:
                        if not self.disponibile(_neg(parte)):
                            # ¬(A ∨ B): se A, allora A ∨ B, assurdo; quindi ¬A
                            i = self.apri(parte)
                            k = self.aggiungi(a, "∨I", [i])
                            self.aggiungi(_FALSO, "¬E", [k, n])
                            self.aggiungi(_neg(parte), "¬I", [self.chiudi(i, _FALSO)])
                            return True
                if a.op == IMP:
                    x, y = a.figli
                    if not self.disponibile(x):
                        # ¬(A → B) dà A: per assurdo da ¬A si ricaverebbe A → B
                        i = self.apri(_neg(x))
                        j = self.apri(x)
                        f1 = self.aggiungi(_FALSO, "¬E", [j, i])
                        self.aggiungi(y, "⊥E", [f1])
                        k = self.aggiungi(a, "→I", [self.chiudi(j, y)])
                        self.aggiungi(_FALSO, "¬E", [k, n])
                        self.aggiungi(x, "RAA", [self.chiudi(i, _FALSO)])
                        return True
                    if not self.disponibile(_neg(y)):
                        # ¬(A → B) dà ¬B: se B, allora A → B, assurdo
                        i = self.apri(y)
                        j = self.apri(x)
                        k = self.aggiungi(a, "→I", [self.chiudi(j, y)])
                        self.aggiungi(_FALSO, "¬E", [k, n])
                        self.aggiungi(_neg(y), "¬I", [self.chiudi(i, _FALSO)])
                        return True
                if a.op in (XOR, NAND, NOR):
                    # ¬(A ⊕ B) dà A ↔ B, ¬(A ↑ B) dà A ∧ B, ¬(A ↓ B) dà A ∨ B
                    d = _definizione(a).figli[0]
                    if not self.disponibile(d):
                        i = self.apri(_neg(d))
                        k = self.aggiungi(a, "Def", [i])
                        self.aggiungi(_FALSO, "¬E", [k, n])
                        self.aggiungi(d, "RAA", [self.chiudi(i, _FALSO)])
                        return True
        return False

    def scegli_beta(self):
        for n, f in self.accessibili():
            if f.op in (OR, IMP, IFF):
                x, y = f.figli
                alternative = {OR: [[x], [y]], IMP: [[_neg(x)], [y]], IFF: [[x, y], [_neg(x), _neg(y)]]}[f.op]
            elif f.op == NEG and f.figli[0].op in (AND, IFF):
                x, y = f.figli[0].figli
                alternative = ([[_neg(x)], [_neg(y)]] if f.figli[0].op == AND
                               else [[x, _neg(y)], [_neg(x), y]])
            else:
                continue
            if any(all(self.disponibile(a) for a in alt) for alt in alternative):
                continue
            return n, f
        return None

    def dividi(self, n, f):
        """Ragionamento per casi, scritto con le regole di base."""
        if f.op == OR:
            x, y = f.figli
            i = self.apri(x)
            self.falso()
            s1 = self.chiudi(i, _FALSO)
            j = self.apri(y)
            self.falso()
            s2 = self.chiudi(j, _FALSO)
            return self.aggiungi(_FALSO, "∨E", [n, s1, s2])
        if f.op == IMP:
            x, y = f.figli
            i = self.apri(x)
            if not self.disponibile(y):
                self.aggiungi(y, "→E", [n, i])
            self.falso()
            self.aggiungi(_neg(x), "¬I", [self.chiudi(i, _FALSO)])
            return self.falso()
        if f.op == IFF:
            x, y = f.figli
            i = self.apri(x)
            if not self.disponibile(y):
                self.aggiungi(y, "↔E", [n, i])
            self.falso()
            non_x = self.aggiungi(_neg(x), "¬I", [self.chiudi(i, _FALSO)])
            j = self.apri(y)
            k = self.aggiungi(x, "↔E", [n, j])
            self.aggiungi(_FALSO, "¬E", [k, non_x])
            self.aggiungi(_neg(y), "¬I", [self.chiudi(j, _FALSO)])
            return self.falso()
        a = f.figli[0]
        x, y = a.figli
        if a.op == AND:   # ¬(A ∧ B)
            i = self.apri(x)
            j = self.apri(y)
            k = self.aggiungi(a, "∧I", [i, j])
            self.aggiungi(_FALSO, "¬E", [k, n])
            self.aggiungi(_neg(y), "¬I", [self.chiudi(j, _FALSO)])
            self.falso()
            self.aggiungi(_neg(x), "¬I", [self.chiudi(i, _FALSO)])
            return self.falso()
        # ¬(A ↔ B): casi A, ¬B oppure ¬A, B
        i = self.apri(x)
        j = self.apri(y)
        p1 = self.apri(x)
        s_ab = self.chiudi(p1, y)
        p2 = self.apri(y)
        s_ba = self.chiudi(p2, x)
        k = self.aggiungi(a, "↔I", [s_ab, s_ba])
        self.aggiungi(_FALSO, "¬E", [k, n])
        self.aggiungi(_neg(y), "¬I", [self.chiudi(j, _FALSO)])
        self.falso()
        non_x = self.aggiungi(_neg(x), "¬I", [self.chiudi(i, _FALSO)])
        r = self.apri(_neg(y))
        q1 = self.apri(x)
        f1 = self.aggiungi(_FALSO, "¬E", [q1, non_x])
        self.aggiungi(y, "⊥E", [f1])
        s1 = self.chiudi(q1, y)
        q2 = self.apri(y)
        f2 = self.aggiungi(_FALSO, "¬E", [q2, r])
        self.aggiungi(x, "⊥E", [f2])
        s2 = self.chiudi(q2, x)
        k = self.aggiungi(a, "↔I", [s1, s2])
        self.aggiungi(_FALSO, "¬E", [k, n])
        self.aggiungi(y, "RAA", [self.chiudi(r, _FALSO)])
        return self.falso()


def deduzione_naturale(premesse, conclusione):
    """Dimostrazione in deduzione naturale di «premesse ⊢ conclusione» (logica proposizionale).

    Se la conclusione non segue dalle premesse non esiste nessuna dimostrazione: in quel caso
    valida è False e c'è un controesempio. Altrimenti righe contiene la dimostrazione:
    per ogni riga numero, testo, regola, riferimenti (numeri o coppie (inizio, fine) delle
    sottodimostrazioni), livello (rientro) e ipotesi. La dimostrazione è ricontrollata
    da `controlla_deduzione` prima di essere restituita.
    """
    alberi = []
    for numero, testo in enumerate(premesse, start=1):
        if isinstance(testo, str) and not testo.strip():
            continue
        alberi.append(_leggi(testo, f"Premessa {numero}"))
    finale = _leggi(conclusione, "Conclusione")
    verifica = consequence(alberi, finale)
    risultato = {"premesse": [to_text(a) for a in alberi], "conclusione": to_text(finale),
                 "valida": verifica["valida"], "righe": [], "controesempio": None}
    if not verifica["valida"]:
        risultato["controesempio"] = verifica["controesempi"][0][0]
        return risultato
    d = _Deduzione()
    for a in alberi:
        d.aggiungi(a, "Premessa")
    d.dimostra(finale)
    if d.righe[-1]["livello"] != 0 or to_text(d.righe[-1]["formula"]) != to_text(finale):
        d.aggiungi(finale, "R", [d.disponibile(finale)])
    righe = [{k: v for k, v in r.items() if k != "formula"} for r in d.righe]
    errori = controlla_deduzione(righe, risultato["premesse"], risultato["conclusione"])
    if errori:
        raise RuntimeError("Deduzione naturale non corretta: " + "; ".join(errori))
    risultato["righe"] = righe
    return risultato


def controlla_deduzione(righe, premesse, conclusione):
    """Controlla una dimostrazione riga per riga. Restituisce l'elenco degli errori (vuoto se è corretta)."""
    errori = []
    formule = []
    for r in righe:
        try:
            formule.append(parse(r["testo"]))
        except FormulaError as e:
            return [f"riga {r['numero']}: formula non valida ({e})"]
    testo = [to_text(f) for f in formule]
    percorsi, aperte, chiuse = [], [], {}
    for i, r in enumerate(righe):
        livello = r["livello"]
        while aperte and aperte[-1][1] > livello:
            inizio, l = aperte.pop()
            chiuse[(inizio, i)] = tuple(a for a, _ in aperte)
        if r["ipotesi"]:
            if aperte and aperte[-1][1] == livello:
                inizio, l = aperte.pop()
                chiuse[(inizio, i)] = tuple(a for a, _ in aperte)
            if livello != len(aperte) + 1:
                errori.append(f"riga {i + 1}: rientro sbagliato")
            aperte.append((i + 1, livello))
        elif livello != len(aperte):
            errori.append(f"riga {i + 1}: rientro sbagliato")
        percorsi.append(tuple(a for a, _ in aperte))
    if errori:
        return errori

    def riga(i, j):
        """La riga j (da 1) è utilizzabile alla riga i?"""
        return 1 <= j < i and percorsi[i - 1][:len(percorsi[j - 1])] == percorsi[j - 1]

    def sotto(i, coppia):
        inizio, fine = coppia
        return (inizio, fine) in chiuse and fine < i and chiuse[(inizio, fine)] == percorsi[i - 1]

    def T(j):
        return testo[j - 1]

    def F(j):
        return formule[j - 1]

    def neg(t):
        return to_text(_neg(parse(t)))

    for i, r in enumerate(righe, start=1):
        f, regola, rif = formule[i - 1], r["regola"], r["riferimenti"]
        righe_singole = [x for x in rif if isinstance(x, int)]
        coppie = [tuple(x) for x in rif if not isinstance(x, int)]
        if any(not riga(i, x) for x in righe_singole) or any(not sotto(i, c) for c in coppie):
            errori.append(f"riga {i}: cita righe non utilizzabili")
            continue
        ok = False
        if regola == "Premessa":
            ok = r["livello"] == 0 and all(righe[k]["regola"] == "Premessa" for k in range(i - 1))
        elif regola == "Ipotesi":
            ok = r["ipotesi"]
        elif regola == "R":
            ok = len(righe_singole) == 1 and T(rif[0]) == testo[i - 1]
        elif regola == "⊤I":
            ok = f.op == "const" and f.valore
        elif regola == "∧I":
            ok = (f.op == AND and len(righe_singole) == 2
                  and {to_text(f.figli[0]), to_text(f.figli[1])} <= {T(x) for x in righe_singole}
                  and to_text(f.figli[0]) == T(rif[0]) and to_text(f.figli[1]) == T(rif[1]))
        elif regola == "∧E":
            ok = len(rif) == 1 and F(rif[0]).op == AND and testo[i - 1] in (to_text(F(rif[0]).figli[0]),
                                                                            to_text(F(rif[0]).figli[1]))
        elif regola == "∨I":
            ok = len(rif) == 1 and f.op == OR and T(rif[0]) in (to_text(f.figli[0]), to_text(f.figli[1]))
        elif regola == "∨E":
            if len(rif) == 3 and isinstance(rif[0], int) and len(coppie) == 2 and F(rif[0]).op == OR:
                (a1, b1), (a2, b2) = coppie
                x, y = F(rif[0]).figli
                ok = (T(a1) == to_text(x) and T(a2) == to_text(y)
                      and T(b1) == testo[i - 1] and T(b2) == testo[i - 1])
        elif regola == "→I":
            if len(coppie) == 1 and f.op == IMP:
                a, b = coppie[0]
                ok = T(a) == to_text(f.figli[0]) and T(b) == to_text(f.figli[1])
        elif regola == "→E":
            if len(righe_singole) == 2:
                a, b = (F(x) for x in righe_singole)
                ok = a.op == IMP and to_text(a.figli[0]) == T(rif[1]) and to_text(a.figli[1]) == testo[i - 1]
        elif regola == "¬I":
            if len(coppie) == 1 and f.op == NEG:
                a, b = coppie[0]
                ok = T(a) == to_text(f.figli[0]) and T(b) == "⊥"
        elif regola == "¬E":
            ok = len(righe_singole) == 2 and testo[i - 1] == "⊥" and T(rif[1]) == neg(T(rif[0]))
        elif regola == "⊥E":
            ok = len(righe_singole) == 1 and T(rif[0]) == "⊥"
        elif regola == "RAA":
            if len(coppie) == 1:
                a, b = coppie[0]
                ok = T(a) == neg(testo[i - 1]) and T(b) == "⊥"
        elif regola == "↔I":
            if len(coppie) == 2 and f.op == IFF:
                (a1, b1), (a2, b2) = coppie
                x, y = (to_text(c) for c in f.figli)
                ok = T(a1) == x and T(b1) == y and T(a2) == y and T(b2) == x
        elif regola == "↔E":
            if len(righe_singole) == 2 and F(rif[0]).op == IFF:
                x, y = (to_text(c) for c in F(rif[0]).figli)
                ok = (T(rif[1]), testo[i - 1]) in ((x, y), (y, x))
        elif regola == "Def":
            if len(righe_singole) == 1:
                a = F(rif[0])
                ok = ((f.op in (XOR, NAND, NOR) and to_text(_definizione(f)) == T(rif[0]))
                      or (a.op in (XOR, NAND, NOR) and to_text(_definizione(a)) == testo[i - 1]))
        if not ok:
            errori.append(f"riga {i}: la regola {regola} non si applica così")
    if righe and (righe[-1]["livello"] != 0 or testo[-1] != to_text(parse(conclusione))):
        errori.append("l'ultima riga non è la conclusione")
    premesse_scritte = [testo[k] for k, r in enumerate(righe) if r["regola"] == "Premessa"]
    if premesse_scritte != [to_text(parse(p)) for p in premesse]:
        errori.append("le premesse non corrispondono")
    return errori


# ---------- circuiti logici ----------
#
# Un circuito è un elenco di porte. Ogni porta ha un tipo (AND, OR, NOT, XOR, NAND, NOR, XNOR) e degli
# ingressi, che possono essere variabili, costanti (0 e 1) o uscite di altre porte. L'ultima porta
# (oppure quella chiamata «uscita») dà il risultato.
#
# Gli ingressi sono coppie: ("var", nome), ("cost", True/False) oppure ("porta", numero della porta).

PORTE = ("AND", "OR", "NOT", "XOR", "NAND", "NOR", "XNOR")
NOMI_PORTE = {
    "AND": "AND (e)", "OR": "OR (o)", "NOT": "NOT (non)", "XOR": "XOR (o esclusivo)",
    "NAND": "NAND (non e)", "NOR": "NOR (non o)", "XNOR": "XNOR (equivalenza)",
}
MAX_INGRESSI_PORTA = 4
MAX_PORTE = 300
_PORTA_DEL_CONNETTIVO = {AND: "AND", OR: "OR", XOR: "XOR", NAND: "NAND", NOR: "NOR", IFF: "XNOR"}
_ASSOCIATIVE = {"AND", "OR", "XOR"}


def _solo_nand(f, c):
    """Riscrive la formula usando solo ↑ (NAND): ogni connettivo si esprime con le NAND."""
    risultati = {}

    def nand(a, b):
        return c.nodo(NAND, (a, b))

    for n in _postordine(f):
        if not n.figli:
            risultati[id(n)] = c.nodo(n.op, nome=n.nome, valore=n.valore)
            continue
        x = risultati[id(n.figli[0])]
        y = risultati[id(n.figli[1])] if len(n.figli) > 1 else None
        nx = nand(x, x)
        if n.op == NEG:
            r = nx
        elif n.op == NAND:
            r = nand(x, y)
        elif n.op == AND:
            t = nand(x, y)
            r = nand(t, t)
        elif n.op == OR:
            r = nand(nx, nand(y, y))
        elif n.op == NOR:
            t = nand(nx, nand(y, y))
            r = nand(t, t)
        elif n.op == IMP:
            r = nand(x, nand(y, y))
        elif n.op == XOR:
            t = nand(x, y)
            r = nand(nand(x, t), nand(y, t))
        else:  # IFF
            t = nand(x, y)
            u = nand(nand(x, t), nand(y, t))
            r = nand(u, u)
        risultati[id(n)] = r
    return risultati[id(f)]


def _solo_nor(f, c):
    """Riscrive la formula usando solo ↓ (NOR)."""
    risultati = {}

    def nor(a, b):
        return c.nodo(NOR, (a, b))

    for n in _postordine(f):
        if not n.figli:
            risultati[id(n)] = c.nodo(n.op, nome=n.nome, valore=n.valore)
            continue
        x = risultati[id(n.figli[0])]
        y = risultati[id(n.figli[1])] if len(n.figli) > 1 else None
        nx = nor(x, x)
        if n.op == NEG:
            r = nx
        elif n.op == NOR:
            r = nor(x, y)
        elif n.op == OR:
            t = nor(x, y)
            r = nor(t, t)
        elif n.op == AND:
            r = nor(nx, nor(y, y))
        elif n.op == NAND:
            t = nor(nx, nor(y, y))
            r = nor(t, t)
        elif n.op == IMP:
            t = nor(nx, y)
            r = nor(t, t)
        elif n.op == IFF:
            t = nor(x, y)
            r = nor(nor(x, t), nor(y, t))
        else:  # XOR
            t = nor(x, y)
            u = nor(nor(x, t), nor(y, t))
            r = nor(u, u)
        risultati[id(n)] = r
    return risultati[id(f)]


def circuito(formula, solo=None):
    """Circuito a porte logiche che calcola la formula.

    `solo` può essere None (porte di tutti i tipi), "NAND" oppure "NOR" (circuito con un solo tipo di porta).
    Le sottoformule ripetute usano la stessa porta; le catene di ∧, ∨ e ⊕ diventano porte con più
    ingressi (fino a MAX_INGRESSI_PORTA). L'implicazione A → B diventa OR(NOT A, B), il ↔ una XNOR.

    Restituisce un dizionario con:
      formula      la formula di partenza riscritta
      variabili    gli ingressi, in ordine
      porte        elenco di porte: numero (da 1), tipo, ingressi, formula (la sottoformula calcolata), livello
      uscita       ("porta", n) oppure, se la formula è una variabile o una costante, quell'ingresso
      conteggio    tipo di porta -> quante
      profondita   il numero massimo di porte attraversate da un ingresso all'uscita
    """
    radice = parse(formula)
    nomi = variables(radice)
    c = _Costruttore()
    if solo is not None:
        solo = solo.upper()
        if solo not in ("NAND", "NOR"):
            raise ValueError("solo deve essere None, \"NAND\" oppure \"NOR\"")
        da_disegnare = (_solo_nand if solo == "NAND" else _solo_nor)(radice, c)
    else:
        da_disegnare = radice
    usi = {}
    for n in _postordine(da_disegnare):
        for figlio in n.figli:
            usi[id(figlio)] = usi.get(id(figlio), 0) + 1
    porte, uscite, per_testo = [], {}, {}
    testi = _testi(da_disegnare)

    def nuova(tipo, ingressi, testo):
        chiave = (tipo, tuple(ingressi))
        if chiave in per_testo:
            return ("porta", per_testo[chiave])
        if len(porte) >= MAX_PORTE:
            raise FormulaError(f"Il circuito avrebbe più di {MAX_PORTE} porte: è troppo grande da disegnare.")
        livello = 1 + max([porte[i[1] - 1]["livello"] for i in ingressi if i[0] == "porta"] + [0])
        porte.append({"numero": len(porte) + 1, "tipo": tipo, "ingressi": list(ingressi), "formula": testo,
                      "livello": livello})
        per_testo[chiave] = len(porte)
        return ("porta", len(porte))

    def operandi(n, op):
        """Gli argomenti di una catena dello stesso connettivo, se le sottocatene non sono usate altrove."""
        elementi, pila = [], [n]
        while pila:
            x = pila.pop()
            if x is not n and (x.op != op or usi.get(id(x), 0) > 1):
                elementi.append(x)
            elif x is n or x.op == op:
                pila.extend(reversed(x.figli))
        return elementi

    for n in _postordine(da_disegnare):
        testo = _senza_parentesi_esterne(n, testi[id(n)])
        if n.op == "var":
            uscite[id(n)] = ("var", n.nome)
        elif n.op == "const":
            uscite[id(n)] = ("cost", n.valore)
        elif n.op == NEG:
            uscite[id(n)] = nuova("NOT", [uscite[id(n.figli[0])]], testo)
        elif n.op == IMP:
            negato = nuova("NOT", [uscite[id(n.figli[0])]], to_text(Formula(NEG, (n.figli[0],))))
            uscite[id(n)] = nuova("OR", [negato, uscite[id(n.figli[1])]], testo)
        else:
            tipo = _PORTA_DEL_CONNETTIVO[n.op]
            if tipo in _ASSOCIATIVE:
                elementi = [uscite[id(x)] for x in operandi(n, n.op)]
                while len(elementi) > MAX_INGRESSI_PORTA:   # troppi ingressi: porte ad albero
                    gruppi = [elementi[k:k + MAX_INGRESSI_PORTA] for k in range(0, len(elementi), MAX_INGRESSI_PORTA)]
                    elementi = [nuova(tipo, g, "") if len(g) > 1 else g[0] for g in gruppi]
                uscite[id(n)] = nuova(tipo, elementi, testo)
            else:
                uscite[id(n)] = nuova(tipo, [uscite[id(x)] for x in n.figli], testo)
    # tolgo le porte che non servono all'uscita (le catene unite lasciano porte intermedie inutilizzate)
    uscita = uscite[id(da_disegnare)]
    return _sistema_circuito(porte, uscita, nomi, to_text(radice))


def _sistema_circuito(porte, uscita, nomi, testo_formula):
    """Tiene solo le porte collegate all'uscita, le rinumera e calcola livelli e conteggi."""
    servono, pila = set(), [uscita]
    while pila:
        tipo, valore = pila.pop()
        if tipo == "porta" and valore not in servono:
            servono.add(valore)
            pila.extend(porte[valore - 1]["ingressi"])
    nuovi_numeri = {}
    sistemate = []
    for porta in porte:
        if porta["numero"] in servono:
            nuovi_numeri[porta["numero"]] = len(sistemate) + 1
            sistemate.append(dict(porta, numero=len(sistemate) + 1))
    for porta in sistemate:
        porta["ingressi"] = [("porta", nuovi_numeri[v]) if t == "porta" else (t, v) for t, v in porta["ingressi"]]
        porta["livello"] = 1 + max([sistemate[v - 1]["livello"] for t, v in porta["ingressi"] if t == "porta"] + [0])
    if uscita[0] == "porta":
        uscita = ("porta", nuovi_numeri[uscita[1]])
    conteggio = {}
    for porta in sistemate:
        conteggio[porta["tipo"]] = conteggio.get(porta["tipo"], 0) + 1
    return {
        "formula": testo_formula,
        "variabili": list(nomi),
        "porte": sistemate,
        "uscita": uscita,
        "conteggio": conteggio,
        "profondita": max([p["livello"] for p in sistemate] + [0]),
    }


def valuta_circuito(circ, valori):
    """Valore di ogni porta per i valori degli ingressi: (lista dei valori delle porte, valore dell'uscita)."""
    risultati = []

    def leggi(ingresso):
        tipo, v = ingresso
        if tipo == "var":
            return bool(valori[v])
        if tipo == "cost":
            return v
        return risultati[v - 1]

    for porta in circ["porte"]:
        x = [leggi(i) for i in porta["ingressi"]]
        tipo = porta["tipo"]
        if tipo == "NOT":
            r = not x[0]
        elif tipo in ("AND", "NAND"):
            r = all(x)
        elif tipo in ("OR", "NOR"):
            r = any(x)
        else:  # XOR, XNOR
            r = sum(x) % 2 == 1
        if tipo in ("NAND", "NOR", "XNOR"):
            r = not r
        risultati.append(r)
    return risultati, leggi(circ["uscita"])


def testo_circuito(circ):
    """Il circuito scritto come testo, una porta per riga: g1 = AND(p, q) ... uscita = OR(g1, g2)."""
    def nome(i):
        tipo, v = i
        if tipo == "var":
            return v
        if tipo == "cost":
            return "1" if v else "0"
        return "uscita" if ("porta", v) == circ["uscita"] else f"g{v}"

    righe = [f"{nome(('porta', p['numero']))} = {p['tipo']}({', '.join(nome(i) for i in p['ingressi'])})"
             for p in circ["porte"]]
    if circ["uscita"][0] != "porta":
        righe.append(f"uscita = AND({nome(circ['uscita'])}, {nome(circ['uscita'])})")
    return "\n".join(righe)


def leggi_circuito(testo):
    """Legge un circuito scritto come testo e restituisce il circuito (come `circuito`) con la sua formula.

    Ogni riga è  nome = PORTA(ingresso, ingresso, ...).  Gli ingressi sono variabili, 0, 1 o nomi di porte
    definite in un'altra riga. L'uscita è la porta chiamata «uscita» (oppure out, y), altrimenti l'ultima.
    Le righe vuote e quelle che iniziano con # sono ignorate.
    """
    definizioni = {}
    ordine = []
    for numero, riga in enumerate(testo.splitlines(), start=1):
        pulita = riga.split("#", 1)[0].strip()
        if not pulita:
            continue
        m = re.fullmatch(r"([^\W\d]\w*)\s*[=:]\s*([A-Za-z]+)\s*\((.*)\)", pulita)
        if not m:
            raise FormulaError(f"Riga {numero}: scrivi la porta così:  nome = AND(a, b)")
        nome, tipo, argomenti = m.group(1), m.group(2).upper(), m.group(3)
        tipo = {"E": "AND", "O": "OR", "NON": "NOT", "INV": "NOT"}.get(tipo, tipo)
        if tipo not in PORTE:
            raise FormulaError(f"Riga {numero}: «{m.group(2)}» non è una porta. Si possono usare: {', '.join(PORTE)}.")
        ingressi = [a.strip() for a in argomenti.split(",") if a.strip()]
        if tipo == "NOT" and len(ingressi) != 1:
            raise FormulaError(f"Riga {numero}: la porta NOT ha un solo ingresso.")
        if tipo != "NOT" and len(ingressi) < 2:
            raise FormulaError(f"Riga {numero}: la porta {tipo} ha almeno due ingressi.")
        for a in ingressi:
            if not re.fullmatch(r"[^\W\d]\w*|[01]", a):
                raise FormulaError(f"Riga {numero}: «{a}» non è un ingresso valido.")
        if nome in definizioni:
            raise FormulaError(f"Riga {numero}: la porta «{nome}» è già definita alla riga {definizioni[nome][2]}.")
        definizioni[nome] = (tipo, ingressi, numero)
        ordine.append(nome)
    if not ordine:
        raise FormulaError("Il circuito è vuoto: scrivi almeno una porta, per esempio  uscita = AND(a, b)")
    finale = next((n for n in ("uscita", "out", "output", "y") if n in definizioni), ordine[-1])
    # ordine topologico (le porte possono essere scritte in qualsiasi ordine), con controllo dei cicli
    porte, numeri, stato = [], {}, {}

    def visita(nome, catena):
        if stato.get(nome) == "fatto":
            return
        if stato.get(nome) == "in corso":
            giro = " → ".join(catena[catena.index(nome):] + [nome])
            raise FormulaError(f"Il circuito ha un anello: {giro}. Un'uscita non può tornare indietro.")
        stato[nome] = "in corso"
        for a in definizioni[nome][1]:
            if a in definizioni:
                visita(a, catena + [nome])
        stato[nome] = "fatto"
        tipo, ingressi, _ = definizioni[nome]
        collegati = [("cost", a == "1") if a in ("0", "1") else
                     ("porta", numeri[a]) if a in definizioni else ("var", a) for a in ingressi]
        porte.append({"numero": len(porte) + 1, "tipo": tipo, "ingressi": collegati, "formula": "", "livello": 0,
                      "nome": nome})
        numeri[nome] = len(porte)

    visita(finale, [])
    for nome in ordine:
        if nome not in numeri:
            visita(nome, [])
    # la formula di ogni porta
    formule = []
    for porta in porte:
        argomenti = [Formula("var", nome=v) if t == "var" else Formula("const", valore=v) if t == "cost"
                     else formule[v - 1] for t, v in porta["ingressi"]]
        tipo = porta["tipo"]
        if tipo == "NOT":
            f = _neg(argomenti[0])
        elif tipo in ("NAND", "NOR") and len(argomenti) == 2:
            f = _bin(NAND if tipo == "NAND" else NOR, *argomenti)
        else:
            op = {"AND": AND, "NAND": AND, "OR": OR, "NOR": OR, "XOR": XOR, "XNOR": XOR}[tipo]
            if tipo == "XNOR" and len(argomenti) == 2:
                op = IFF
            f = argomenti[0]
            for a in argomenti[1:]:
                f = _bin(op, f, a)
            if tipo in ("NAND", "NOR") or (tipo == "XNOR" and len(argomenti) > 2):
                f = _neg(f)
        formule.append(f)
        porta["formula"] = to_text(f)
    uscita = ("porta", numeri[finale])
    nomi = ordina_variabili(v for p in porte for t, v in p["ingressi"] if t == "var")
    circ = _sistema_circuito(porte, uscita, nomi, porte[numeri[finale] - 1]["formula"])
    usate = {p["nome"] for p in circ["porte"]}
    circ["inutilizzate"] = [n for n in ordine if n not in usate]
    return circ


# ---------- esportazione in LaTeX e CSV ----------

_LATEX_SIMBOLI = {
    "¬": r"\lnot", "∧": r"\land", "∨": r"\lor", "→": r"\to", "↔": r"\leftrightarrow", "⊕": r"\oplus",
    "↑": r"\uparrow", "↓": r"\downarrow", "⊤": r"\top", "⊥": r"\bot", "∀": r"\forall", "∃": r"\exists",
    "≠": r"\neq", "≡": r"\equiv", "≢": r"\not\equiv", "⊢": r"\vdash", "⊨": r"\models", "⊭": r"\not\models",
    "⇒": r"\Rightarrow", "∴": r"\therefore", "∈": r"\in", "∉": r"\notin", "∅": r"\emptyset",
    "✓": r"\checkmark", "✗": r"\times", "○": r"\circ", "×": r"\times", "–": "-", "·": r"\cdot",
    "≟": r"\stackrel{?}{\equiv}",
}
_LATEX_SPECIALI = {"\\": r"\textbackslash{}", "{": r"\{", "}": r"\}", "#": r"\#", "%": r"\%", "&": r"\&",
                   "$": r"\$", "_": r"\_", "^": r"\^{}", "~": r"\~{}"}


def latex_formula(testo):
    """La formula in LaTeX, da usare in modo matematico (tra due $): ¬ diventa lnot, ∧ diventa land..."""
    pezzi = []
    for m in re.finditer(r"[^\W\d][\w']*|\d+|\s+|.", testo):
        t = m.group(0)
        if t.isspace():
            continue
        if t in _LATEX_SIMBOLI:
            pezzi.append(_LATEX_SIMBOLI[t] + " ")
        elif t[0].isalpha() or t[0] == "_":
            nome = t.replace("_", r"\_")
            pezzi.append((r"\mathit{" + nome + "}" if len(t.rstrip("'")) > 1 else nome) + " ")
        elif t in _LATEX_SPECIALI:
            pezzi.append(_LATEX_SPECIALI[t])
        elif t == ",":
            pezzi.append(",\\, ")
        elif ord(t) < 128:
            pezzi.append(t)
        else:
            pezzi.append(r"\text{?}")
    return "".join(pezzi).strip()


def latex_testo(testo):
    """Testo normale per LaTeX: caratteri speciali protetti, simboli logici in modo matematico."""
    pezzi = []
    for ch in testo:
        if ch in _LATEX_SIMBOLI:
            pezzi.append("$" + _LATEX_SIMBOLI[ch] + "$")
        elif ch in _LATEX_SPECIALI:
            pezzi.append(_LATEX_SPECIALI[ch])
        elif ch == "\n":
            pezzi.append("\\\\\n")
        elif ch in "«»":
            pezzi.append({"«": "<<", "»": ">>"}[ch])
        else:
            pezzi.append(ch)
    return "".join(pezzi)


def documento_latex(corpo, titolo="", pacchetti=()):
    """Documento LaTeX completo, pronto da compilare (pdfLaTeX)."""
    righe = [r"\documentclass[11pt]{article}", r"\usepackage[utf8]{inputenc}", r"\usepackage[T1]{fontenc}",
             r"\usepackage[italian]{babel}", r"\usepackage{amsmath,amssymb}", r"\usepackage[margin=2cm]{geometry}"]
    righe += [rf"\usepackage{{{p}}}" for p in pacchetti]
    righe += [r"\begin{document}", "% creato con LogicaDesk Pro"]
    if titolo:
        righe.append(r"\section*{" + latex_testo(titolo) + "}")
    righe += [corpo, r"\end{document}", ""]
    return "\n".join(righe)


def latex_tavola(intestazione, righe, variabili=None):
    """Tavola di verità come ambiente tabular; una riga verticale separa le variabili dal resto."""
    if variabili is None:
        variabili = sum(1 for h in intestazione if re.fullmatch(r"[^\W\d][\w']*", h))
    colonne = "c" * variabili + ("|" if 0 < variabili < len(intestazione) else "") + "c" * (len(intestazione) - variabili)
    righe_testo = [" & ".join("$" + latex_formula(h) + "$" for h in intestazione) + r" \\", r"\hline"]
    for riga in righe:
        righe_testo.append(" & ".join(latex_testo(str(v)) for v in riga) + r" \\")
    return "\\begin{tabular}{" + colonne + "}\n" + "\n".join(righe_testo) + "\n\\end{tabular}"


def csv_tavola(intestazione, righe, separatore=";"):
    """Tavola come testo CSV (con il punto e virgola, come lo apre Excel in italiano)."""
    uscita = io.StringIO()
    scrittore = csv.writer(uscita, delimiter=separatore, lineterminator="\r\n")
    scrittore.writerow(intestazione)
    for riga in righe:
        scrittore.writerow(riga)
    return uscita.getvalue()


def latex_passaggi(passi):
    """I passaggi di `forma_normale_passo_passo` come ambiente align*, con il nome della legge."""
    righe = [r"\begin{align*}", "  & " + latex_formula(passi["formula"]) + r" \\"]
    for passo in passi["passaggi"]:
        righe.append(r"  \equiv\ & " + latex_formula(passo["formula"]) + r" && \text{" +
                     latex_testo(passo["legge"]) + r"} \\")
    righe.append(r"\end{align*}")
    return "\n".join(righe)


def _latex_riferimenti(riferimenti):
    return ", ".join(str(r) if isinstance(r, int) else f"{r[0]}--{r[1]}" for r in riferimenti)


def latex_deduzione(righe):
    """Dimostrazione in deduzione naturale: numero, formula rientrata con le barre, regola e righe citate."""
    corpo = [r"\begin{tabular}{r l l}"]
    for r in righe:
        barre = r"\mid\; " * r["livello"]
        formula = latex_formula(r["testo"])
        if r["ipotesi"]:
            formula = r"\underline{" + formula + "}"
        regola = "$" + latex_formula(r["regola"]) + "$" if any(c in _LATEX_SIMBOLI for c in r["regola"]) \
            else latex_testo(r["regola"])
        corpo.append(f"{r['numero']} & ${barre}{formula}$ & {regola} {_latex_riferimenti(r['riferimenti'])}" + r" \\")
    corpo.append(r"\end{tabular}")
    return "\n".join(corpo)


def latex_karnaugh(dati):
    """Mappe di Karnaugh come tabelle, con l'elenco dei raggruppamenti."""
    parti = []
    angolo = "$" + latex_formula(" ".join(dati["variabili_righe"])) + r" \backslash " + \
             latex_formula(" ".join(dati["variabili_colonne"])) + "$"
    for mappa in dati["mappe"]:
        if mappa["titolo"]:
            parti.append(r"\noindent $" + latex_formula(mappa["titolo"]) + r"$\\[2pt]")
        colonne = "c|" + "c" * len(mappa["etichette_colonne"])
        righe = [angolo + " & " + " & ".join(mappa["etichette_colonne"]) + r" \\", r"\hline"]
        for etichetta, riga in zip(mappa["etichette_righe"], mappa["celle"]):
            righe.append((etichetta or "") + " & " + " & ".join(str(c["valore"]) for c in riga) + r" \\")
        parti.append("\\begin{tabular}{" + colonne + "}\n" + "\n".join(righe) + "\n\\end{tabular}\n")
    gruppi = ", ".join("$" + latex_formula(g["testo"]) + "$" for g in dati["gruppi"])
    parti.append(r"\noindent Raggruppamenti: " + (gruppi or "nessuno") + r".\\")
    parti.append(r"Forma minima: $" + latex_formula(dati["risultato"]) + "$")
    return "\n\n".join(parti)


def latex_tableau(albero):
    """Tableau come albero del pacchetto forest (va aggiunto \\usepackage{forest})."""
    def nodo(n):
        righe = [f"${f['numero']}.\\ " + latex_formula(f["testo"]) + "$" for f in n["formule"]] or ["$ $"]
        if n.get("stato") == "chiuso":
            righe.append(r"$\times$")
        elif n.get("stato") == "aperto":
            righe.append(r"$\circ$")
        figli = " ".join(nodo(f) for f in n["figli"])
        return "[{" + r" \\ ".join(righe) + "}" + (" " + figli if figli else "") + "]"
    return "\\begin{forest}\nfor tree={align=left, l sep=12pt, s sep=14pt}\n" + nodo(albero) + "\n\\end{forest}"


def latex_circuito(circ):
    """Circuito come tabella delle porte, con la formula che calcola."""
    def nome(i):
        tipo, v = i
        if tipo == "var":
            return "$" + latex_formula(v) + "$"
        if tipo == "cost":
            return "1" if v else "0"
        return "uscita" if ("porta", v) == circ["uscita"] else f"g{v}"

    righe = [r"\noindent Formula: $" + latex_formula(circ["formula"]) + r"$\\[6pt]", r"\begin{tabular}{l l l}",
             r"Porta & Tipo & Ingressi \\", r"\hline"]
    for porta in circ["porte"]:
        righe.append(f"{nome(('porta', porta['numero']))} & {porta['tipo']} & "
                     f"{', '.join(nome(i) for i in porta['ingressi'])}" + r" \\")
    righe.append(r"\end{tabular}")
    return "\n".join(righe)


# ---------- aiuti per l'interfaccia ----------

def converti_simboli(testo):
    """Trasforma le sequenze da tastiera (-> <-> & | ^ ! ~ ...) nei simboli logici, mentre si scrive."""
    for vecchio, nuovo in ALIAS_TASTIERA:
        testo = testo.replace(vecchio, nuovo)
    return testo


def leggi_valore(testo):
    """Legge una cella della tavola: True per V/vero/1/⊤, False per F/falso/0/⊥, None altrimenti."""
    valore = testo.strip().casefold()
    if valore in ("v", "vero", "t", "true", "1", "⊤"):
        return True
    if valore in ("f", "falso", "false", "0", "⊥"):
        return False
    return None


if __name__ == "__main__":
    intestazione, righe = truth_table("(p -> q) & !r")
    print(" | ".join(intestazione))
    for riga in righe:
        print(" | ".join(riga))
    print(classify(truth_table("p ∨ ¬p")[1]))
