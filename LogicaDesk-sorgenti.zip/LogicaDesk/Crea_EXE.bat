@echo off
cd /d "%~dp0"
if not exist "logica_desk.py" goto files_error
set "PY_CMD=py -3"
%PY_CMD% --version >nul 2>&1
if errorlevel 1 set "PY_CMD=python"
%PY_CMD% --version >nul 2>&1
if errorlevel 1 goto python_error

echo Installazione dei componenti necessari (serve Internet)...
%PY_CMD% -m pip install --user --disable-pip-version-check "reportlab>=4.2,<5" "python-docx>=1.1,<2" "pillow>=9.1" pyinstaller
if errorlevel 1 goto install_error

set "ICON_OPT="
if exist "icon.ico" set "ICON_OPT=--icon icon.ico"
echo.
echo Creazione di LogicaDesk.exe...
%PY_CMD% -m PyInstaller --noconfirm --clean --windowed --name LogicaDesk %ICON_OPT% --collect-all reportlab --collect-all docx logica_desk.py
if errorlevel 1 goto build_error

echo.
echo Creazione dell'archivio LogicaDesk-Windows.zip...
powershell -NoProfile -Command "Compress-Archive -Path 'dist\LogicaDesk' -DestinationPath 'LogicaDesk-Windows.zip' -Force"
if errorlevel 1 goto zip_error

echo.
echo Fatto! Il programma e' in dist\LogicaDesk\LogicaDesk.exe
echo L'archivio da pubblicare e' LogicaDesk-Windows.zip
pause
exit /b 0

:python_error
echo Python non trovato. Installa Python 3 e riprova.
pause
exit /b 1

:install_error
echo Installazione non riuscita. Controlla la connessione Internet e riprova.
pause
exit /b 1

:build_error
echo La creazione dell'eseguibile non e' riuscita. Leggi i messaggi qui sopra.
pause
exit /b 1

:zip_error
echo Non sono riuscito a creare lo zip. Comprimi a mano la cartella dist\LogicaDesk.
pause
exit /b 1

:files_error
echo Non trovo logica_desk.py in questa cartella.
echo Estrai tutto il contenuto dello zip (clic destro, "Estrai tutto") e riprova da li'.
pause
exit /b 1
