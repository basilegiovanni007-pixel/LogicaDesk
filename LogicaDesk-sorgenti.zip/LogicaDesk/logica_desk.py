"""LogicaDesk: a desktop editor for logic notes and exercises."""

from pathlib import Path
import ctypes
from ctypes import wintypes
import math
import sys
import tkinter as tk
from tkinter import font as tkfont
from tkinter import filedialog, messagebox, ttk
import base64
import io

try:
    from PIL import Image, ImageChops, ImageDraw, ImageFilter
except ImportError:  # gestito all'avvio
    Image = ImageChops = ImageDraw = ImageFilter = None


SYMBOLS = [
    ("¬", "Negazione"), ("∧", "Congiunzione"), ("∨", "Disgiunzione"),
    ("→", "Implicazione"), ("↔", "Equivalenza"), ("⊕", "Disgiunzione esclusiva"),
    ("∀", "Per ogni"), ("∃", "Esiste"), ("∴", "Conclusione"),
    ("⊤", "Vero"), ("⊥", "Falso"), ("⊢", "Dimostra"),
    ("⊨", "Conseguenza semantica"), ("≡", "Equivalenza logica"),
    ("∈", "Appartiene"), ("∉", "Non appartiene"), ("∅", "Insieme vuoto"),
    ("ℕ", "Numeri naturali"), ("ℤ", "Numeri interi"),
]

GREEK_SYMBOLS = [
    ("α", "Alfa"), ("β", "Beta"), ("γ", "Gamma"), ("δ", "Delta"),
    ("ε", "Epsilon"), ("θ", "Theta"), ("λ", "Lambda"), ("μ", "Mu"),
    ("ν", "Nu"), ("ξ", "Xi"), ("π", "Pi"), ("ρ", "Rho"),
    ("σ", "Sigma"), ("τ", "Tau"), ("φ", "Phi"), ("χ", "Chi"),
    ("ψ", "Psi"), ("ω", "Omega"), ("Γ", "Gamma maiuscola"),
    ("Δ", "Delta maiuscola"), ("Θ", "Theta maiuscola"),
    ("Λ", "Lambda maiuscola"), ("Ξ", "Xi maiuscola"),
    ("Π", "Pi maiuscola"), ("Σ", "Sigma maiuscola"),
    ("Φ", "Phi maiuscola"), ("Ψ", "Psi maiuscola"),
    ("Ω", "Omega maiuscola"),
]

CLASSICAL_LAWS = [
    ("Identità", "p ∧ ⊤ ≡ p     ·     p ∨ ⊥ ≡ p", "Il vero non cambia una congiunzione; il falso non cambia una disgiunzione."),
    ("Dominazione", "p ∨ ⊤ ≡ ⊤     ·     p ∧ ⊥ ≡ ⊥", "Il vero domina la disgiunzione e il falso domina la congiunzione."),
    ("Idempotenza", "p ∧ p ≡ p     ·     p ∨ p ≡ p", "Ripetere la stessa proposizione non ne cambia il valore."),
    ("Doppia negazione", "¬¬p ≡ p", "Negare due volte una proposizione restituisce la proposizione iniziale."),
    ("Terzo escluso", "p ∨ ¬p ≡ ⊤", "Una proposizione o la sua negazione: una delle due è vera."),
    ("Non contraddizione", "p ∧ ¬p ≡ ⊥", "Una proposizione e la sua negazione non possono essere vere insieme."),
    ("Commutatività", "p ∧ q ≡ q ∧ p     ·     p ∨ q ≡ q ∨ p", "L'ordine degli argomenti non cambia congiunzione o disgiunzione."),
    ("Associatività", "(p ∧ q) ∧ r ≡ p ∧ (q ∧ r)     ·     (p ∨ q) ∨ r ≡ p ∨ (q ∨ r)", "Le parentesi si possono spostare quando si ripete lo stesso connettivo."),
    ("Distributività", "p ∧ (q ∨ r) ≡ (p ∧ q) ∨ (p ∧ r)\np ∨ (q ∧ r) ≡ (p ∨ q) ∧ (p ∨ r)", "La congiunzione e la disgiunzione si distribuiscono l'una sull'altra."),
    ("Leggi di De Morgan", "¬(p ∧ q) ≡ ¬p ∨ ¬q\n¬(p ∨ q) ≡ ¬p ∧ ¬q", "Negando una congiunzione o una disgiunzione, si scambia il connettivo."),
    ("Assorbimento", "p ∨ (p ∧ q) ≡ p     ·     p ∧ (p ∨ q) ≡ p", "Una formula assorbe la parte più complessa che la contiene."),
    ("Implicazione materiale", "p → q ≡ ¬p ∨ q", "L'implicazione è falsa solo quando p è vera e q è falsa."),
    ("Contrapposizione", "p → q ≡ ¬q → ¬p", "Un'implicazione è equivalente alla sua contrapposta."),
    ("Bicondizionale", "p ↔ q ≡ (p → q) ∧ (q → p)", "Il bicondizionale richiede che valgano entrambe le implicazioni."),
    ("Forma disgiuntiva del bicondizionale", "p ↔ q ≡ (p ∧ q) ∨ (¬p ∧ ¬q)", "Le due proposizioni hanno lo stesso valore di verità."),
    ("Esportazione", "(p ∧ q) → r ≡ p → (q → r)", "Una congiunzione nell'antecedente si può riscrivere come implicazioni successive."),
]

# ---- Tema: chiaro, neutro, con un solo accento indaco ----
BG = "#edf1fb"           # sfondo finestra
INK = "#0f172a"          # titoli
TEXT = "#334155"         # testo dell'editor
MUTED = "#64748b"        # testo secondario
LINE = "#e5e8f0"         # bordi sottili
LINE_STRONG = "#d6dae6"  # bordi dei pulsanti
BLUE = "#0a84ff"         # accento (blu Apple)
BLUE_HOVER = "#0071e3"
NAVY = "#1e1b4b"
SKY = "#e8f2ff"          # accento tenue
SOFT = "#f1f3f9"
UI = "Segoe UI"
MATH = "Cambria"
PLACEHOLDER = "Inizia a scrivere qui…\n\nPuoi inserire simboli con la barra qui sopra, ad esempio:  (p ∧ q) → r"


# ---------------------------------------------------------------------------
#  Rendering "vetro": immagini RGBA antialiasate generate con Pillow
# ---------------------------------------------------------------------------
SS = 3  # supersampling per bordi lisci
_RESAMPLE = getattr(Image, "Resampling", Image)
_TRANSPOSE = getattr(Image, "Transpose", Image)

TONES = {
    # tono: (alto, basso, colore testo) — solo azzurro, blu e viola
    "sky": ("#eaf5ff", "#bde0ff", "#1f5fae"),
    "periwinkle": ("#eceeff", "#c3ccff", "#3447b5"),
    "lilac": ("#f2ecff", "#d6c8fb", "#5a3db0"),
    "clear": ("#ffffff", "#edf0f8", "#3b4763"),
    "blue": ("#86c8ff", "#1b7dff", "#ffffff"),
}
KEY_TONES = ("sky", "periwinkle", "lilac")


def hex_rgb(value):
    value = value.lstrip("#")
    return tuple(int(value[i:i + 2], 16) for i in (0, 2, 4))


def mix(a, b, t):
    return tuple(round(a[i] + (b[i] - a[i]) * t) for i in range(3))


def _vgrad(w, h, top, bottom):
    mask = Image.linear_gradient("L").resize((max(1, w), max(1, h)), _RESAMPLE.BILINEAR)
    return Image.composite(Image.new("RGB", mask.size, bottom), Image.new("RGB", mask.size, top), mask)


def glass_surface(w, h, r, top, bottom, edge, *, alpha=240, gloss=0.5, gloss_alpha=170,
                  edge_alpha=140, highlight_alpha=150, edge_width=1, shadow=0, shadow_dy=0,
                  shadow_alpha=60, shadow_color=(70, 80, 150), overlay=None):
    """Superficie di vetro arrotondata: gradiente, riflesso superiore, bordo luminoso e ombra morbida."""
    s = SS
    m = shadow
    W, H = w + 2 * m, h + 2 * m
    big = (W * s, H * s)
    x0, y0, x1, y1 = m * s, m * s, (m + w) * s - 1, (m + h) * s - 1
    rr = r * s
    bw, bh = x1 - x0 + 1, y1 - y0 + 1
    out = Image.new("RGBA", big, (0, 0, 0, 0))
    if m:
        sh = Image.new("L", big, 0)
        ImageDraw.Draw(sh).rounded_rectangle((x0, y0 + shadow_dy * s, x1, y1 + shadow_dy * s), rr, fill=shadow_alpha)
        sh = sh.filter(ImageFilter.GaussianBlur(m * s / 2.4))
        tint = Image.new("RGBA", big, tuple(shadow_color) + (0,))
        tint.putalpha(sh)
        out = Image.alpha_composite(out, tint)
    body_mask = Image.new("L", big, 0)
    ImageDraw.Draw(body_mask).rounded_rectangle((x0, y0, x1, y1), rr, fill=alpha)
    body = Image.new("RGBA", big, (0, 0, 0, 0))
    body.paste(_vgrad(bw, bh, top, bottom), (x0, y0))
    body.putalpha(body_mask)
    out = Image.alpha_composite(out, body)
    if gloss:
        gh = max(2, int(bh * gloss))
        inset = max(2 * s, int(rr * 0.22))
        gm = Image.new("L", big, 0)
        ImageDraw.Draw(gm).rounded_rectangle(
            (x0 + inset, y0 + int(inset * 0.7), x1 - inset, y0 + gh), max(2, rr - inset), fill=255)
        fade = Image.linear_gradient("L").transpose(_TRANSPOSE.FLIP_TOP_BOTTOM).resize((bw, gh))
        fade = fade.point(lambda v: int(gloss_alpha * (0.35 + 0.65 * v / 255)))
        fl = Image.new("L", big, 0)
        fl.paste(fade, (x0, y0))
        white = Image.new("RGBA", big, (255, 255, 255, 0))
        white.putalpha(ImageChops.multiply(gm, fl))
        out = Image.alpha_composite(out, white)
    # bordo luminoso interno + filo esterno
    hl = Image.new("L", big, 0)
    ImageDraw.Draw(hl).rounded_rectangle((x0 + s, y0 + s, x1 - s, y1 - s), max(1, rr - s), outline=highlight_alpha, width=s)
    hl_img = Image.new("RGBA", big, (255, 255, 255, 0))
    hl_img.putalpha(hl)
    out = Image.alpha_composite(out, hl_img)
    ring = Image.new("L", big, 0)
    ImageDraw.Draw(ring).rounded_rectangle((x0, y0, x1, y1), rr, outline=edge_alpha, width=s * edge_width)
    ring_img = Image.new("RGBA", big, tuple(edge) + (0,))
    ring_img.putalpha(ring)
    out = Image.alpha_composite(out, ring_img)
    if overlay:
        overlay(ImageDraw.Draw(out), (x0, y0, bw, bh), s)
    return out.resize((W, H), _RESAMPLE.LANCZOS)


def nine_slice(tpl, c, W, H):
    """Allarga un modello di scheda a qualsiasi dimensione mantenendo angoli e ombre."""
    T = tpl.width
    mid = T // 2
    out = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    out.paste(tpl.crop((0, 0, c, c)), (0, 0))
    out.paste(tpl.crop((T - c, 0, T, c)), (W - c, 0))
    out.paste(tpl.crop((0, T - c, c, T)), (0, H - c))
    out.paste(tpl.crop((T - c, T - c, T, T)), (W - c, H - c))
    iw, ih = W - 2 * c, H - 2 * c
    if iw > 0:
        out.paste(tpl.crop((mid, 0, mid + 1, c)).resize((iw, c)), (c, 0))
        out.paste(tpl.crop((mid, T - c, mid + 1, T)).resize((iw, c)), (c, H - c))
    if ih > 0:
        out.paste(tpl.crop((0, mid, c, mid + 1)).resize((c, ih)), (0, c))
        out.paste(tpl.crop((T - c, mid, T, mid + 1)).resize((c, ih)), (W - c, c))
    if iw > 0 and ih > 0:
        out.paste(tpl.crop((mid, mid, mid + 1, mid + 1)).resize((iw, ih)), (c, c))
    return out


def make_backdrop(w, h):
    """Sfondo pastello morbido: azzurro, lilla, menta e pesca che sfumano tra loro."""
    sw, sh = max(8, w // 10), max(8, h // 10)
    img = _vgrad(sw, sh, (236, 244, 255), (244, 240, 255))
    blobs = (((0.05, 0.02), 0.55, (186, 220, 255)), ((0.98, 0.04), 0.50, (214, 204, 255)),
             ((0.02, 1.00), 0.50, (196, 214, 255)), ((0.95, 0.98), 0.55, (222, 206, 255)),
             ((0.55, 0.55), 0.35, (232, 236, 255)))
    for (cx, cy), rad, col in blobs:
        mask = Image.new("L", (sw, sh), 0)
        r = rad * max(sw, sh) * 0.6
        ImageDraw.Draw(mask).ellipse((cx * sw - r, cy * sh - r, cx * sw + r, cy * sh + r), fill=190)
        mask = mask.filter(ImageFilter.GaussianBlur(max(sw, sh) * 0.14))
        img = Image.composite(Image.new("RGB", (sw, sh), col), img, mask)
    return img.resize((w, h), _RESAMPLE.BICUBIC)


def to_photo(img):
    buf = io.BytesIO()
    img.save(buf, "PNG", compress_level=1)
    return tk.PhotoImage(data=base64.b64encode(buf.getvalue()))


def enable_windows_high_dpi():
    """Ask Windows to render the app at the monitor's native DPI."""
    if sys.platform != "win32":
        return
    try:
        # Per-monitor v2 keeps the UI sharp when moved between displays.
        ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
    except (AttributeError, OSError):
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except (AttributeError, OSError):
            try:
                ctypes.windll.user32.SetProcessDPIAware()
            except (AttributeError, OSError):
                pass


enable_windows_high_dpi()


class LogicaDesk(tk.Tk):
    def __init__(self):
        super().__init__()
        self.ui_scale = max(1.0, self.winfo_fpixels("1i") / 96.0)
        self.title("LogicaDesk — appunti di logica")
        self.geometry("1180x800")
        self.minsize(820, 600)
        self.configure(bg=BG)
        self.current_file: Path | None = None
        self.dirty = False
        self.placeholder_visible = False
        self.mode = "appunti"
        self.greek_palette_open = False
        self.truth_table = None
        self.table_rows = 4
        self.table_cols = 4
        self._pan_origin = None
        self.active_table_entry = None
        self._scroll_pending_x = 0.0
        self._scroll_pending_y = 0.0
        self._smooth_scroll_states = {}
        self._wheel_hook = None
        self._wheel_hook_proc = None
        self._make_style()
        self._make_menu()
        self._bind_native_touchpad_scroll()
        self._make_ui()
        self._install_horizontal_wheel_hook()
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self._update_title()

    def _make_style(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TFrame", background=BG)
        style.configure("TLabel", background=BG, foreground=INK, font=(UI, 10))
        style.configure("Brand.TLabel", font=(UI, 22, "bold"), foreground=INK)
        style.configure("Sub.TLabel", font=(UI, 10), foreground=MUTED)
        style.configure("Section.TLabel", font=(UI, 9, "bold"), foreground=MUTED)
        style.configure("TButton", padding=(11, 8), font=(UI, 10), background="#ffffff", foreground=NAVY)
        style.map("TButton", background=[("active", SKY)], foreground=[("active", BLUE)])
        style.configure("Primary.TButton", padding=(14, 8), font=(UI, 10, "bold"),
                        background=BLUE, foreground="white")
        style.map("Primary.TButton", background=[("active", BLUE_HOVER)], foreground=[("active", "white")])
        # Barre di scorrimento sottili e senza frecce.
        try:
            for orient, name in (("Vertical", "ns"), ("Horizontal", "ew")):
                layout = f"{orient}.TScrollbar"
                style.layout(layout, [(f"{orient}.Scrollbar.trough", {
                    "sticky": name,
                    "children": [(f"{orient}.Scrollbar.thumb", {"expand": "1", "sticky": "nswe"})]})])
                style.configure(layout, gripcount=0, background="#cbd2e1", troughcolor="#ffffff",
                                bordercolor="#ffffff", lightcolor="#cbd2e1", darkcolor="#cbd2e1",
                                relief="flat", width=10 if orient == "Vertical" else 10)
                style.map(layout, background=[("active", "#a8b1c7"), ("pressed", "#94a0bb")],
                          lightcolor=[("active", "#a8b1c7"), ("pressed", "#94a0bb")],
                          darkcolor=[("active", "#a8b1c7"), ("pressed", "#94a0bb")])
        except tk.TclError:
            pass

    def _make_menu(self):
        menu = tk.Menu(self)
        file_menu = tk.Menu(menu, tearoff=False)
        file_menu.add_command(label="Nuovo", accelerator="Ctrl+N", command=self.new_file)
        file_menu.add_command(label="Apri…", accelerator="Ctrl+O", command=self.open_file)
        file_menu.add_command(label="Salva", accelerator="Ctrl+S", command=self.save_file)
        file_menu.add_command(label="Salva con nome…", command=self.save_as)
        file_menu.add_separator()
        file_menu.add_command(label="Esporta in PDF…", command=self.export_pdf)
        file_menu.add_command(label="Esporta in Word…", command=self.export_word)
        file_menu.add_separator()
        file_menu.add_command(label="Esci", command=self._on_close)
        menu.add_cascade(label="File", menu=file_menu)
        self.config(menu=menu)
        self.bind_all("<Control-n>", lambda _e: self.new_file())
        self.bind_all("<Control-o>", lambda _e: self.open_file())
        self.bind_all("<Control-s>", lambda _e: self.save_file())

    def _make_ui(self):
        s = self.ui_scale
        self.status_var = tk.StringVar(value="Pronto")
        self._img_cache = {}
        self._layout_job = None
        self._render_job = None
        self._stage_sizes = None
        self._card_tpl = None
        self.stage = tk.Canvas(self, highlightthickness=0, bd=0, bg="#eef2fb")
        self.stage.pack(fill="both", expand=True)

        # Livelli: sfondo sfumato, schede di vetro, intestazione, piè di pagina.
        self.bg_item = self.stage.create_image(0, 0, anchor="nw")
        self.tool_card_item = self.stage.create_image(0, 0, anchor="nw")
        self.edit_card_item = self.stage.create_image(0, 0, anchor="nw")
        self._logo_photo = to_photo(self._make_logo_image())
        self.logo_item = self.stage.create_image(0, 0, anchor="nw", image=self._logo_photo)
        self.title_item = self.stage.create_text(0, 0, anchor="w", text="LogicaDesk",
                                                 font=(UI, 22, "bold"), fill=INK)
        self.subtitle_item = self.stage.create_text(0, 0, anchor="w", text="Il tuo spazio per appunti e ragionamenti",
                                                    font=(UI, 10), fill=MUTED)
        self.status_dot = self.stage.create_oval(0, 0, round(8 * s), round(8 * s), fill="#0a84ff", outline="")
        self.status_item = self.stage.create_text(0, 0, anchor="w", text="Pronto", font=(UI, 10), fill=MUTED)
        self.hint_item = self.stage.create_text(0, 0, anchor="e", text="Ctrl+S  ·  Salva", font=(UI, 10), fill=MUTED)
        self.status_var.trace_add("write", lambda *_: self.stage.itemconfigure(
            self.status_item, text=self.status_var.get()))

        # ---- Barra degli strumenti (dentro una scheda di vetro) ----
        toolbar = tk.Frame(self.stage, bg="white")
        self.toolbar_body = toolbar
        self.tool_win = self.stage.create_window(0, 0, anchor="nw", window=toolbar)
        controls = tk.Frame(toolbar, bg="white")
        controls.pack(fill="x", padx=4, pady=(4, 10))
        self._rounded_button(controls, "Apri", self.open_file, tone="sky")
        self._rounded_button(controls, "Salva", self.save_file, primary=True)
        self._rounded_button(controls, "PDF", self.export_pdf, width=66, tone="periwinkle")
        self._rounded_button(controls, "Word", self.export_word, width=72, tone="lilac")
        tk.Frame(controls, bg=LINE, width=1, height=28).pack(side="left", padx=(2, 14))
        self.notes_mode_button = self._rounded_button(controls, "Appunti", self.show_notes, variant="mode")
        self.truth_mode_button = self._rounded_button(controls, "Tavola di verità", self.show_truth_table,
                                                      width=145, variant="mode")
        self._style_mode_buttons()
        self._rounded_button(controls, "Formulario", self.open_law_formulary, width=112, tone="sky")
        tk.Frame(controls, bg=LINE, width=1, height=28).pack(side="left", padx=(2, 14))
        self.greek_toggle_button = self._rounded_button(
            controls, "α  Greche", self.toggle_greek_palette, width=92, tone="lilac")

        tk.Frame(toolbar, bg=LINE, height=1).pack(fill="x", padx=4, pady=(0, 12))
        symbols = tk.Frame(toolbar, bg="white")
        symbols.pack(fill="x", padx=4, pady=(0, 6))
        px = round(40 * s)
        for i, (symbol, description) in enumerate(SYMBOLS):
            tone = KEY_TONES[i % len(KEY_TONES)]
            button = tk.Canvas(symbols, width=px, height=px, bg="white", highlightthickness=0, cursor="hand2")
            button.tone = tone
            button.create_image(0, 0, anchor="nw", image=self._glass_image(40, 40, 13, tone), tags="sym_face")
            button.create_text(px // 2, px // 2 - 1, text=symbol, fill=TONES[tone][2],
                               font=(MATH, 15, "bold"), tags="sym_label")
            button.grid(row=i // 10, column=i % 10, padx=(0, 6), pady=(0, 6), sticky="w")
            button.bind("<Button-1>", lambda _e, value=symbol: self.insert_symbol(value))
            button.bind("<Enter>", lambda _e, b=button, text=description: self._symbol_hover(b, True, text))
            button.bind("<Leave>", lambda _e, b=button: self._symbol_hover(b, False))
            button.bind("<ButtonPress-1>", lambda _e, b=button: b.itemconfigure(
                "sym_face", image=self._glass_image(40, 40, 13, b.tone, "press")), add="+")
            button.bind("<ButtonRelease-1>", lambda _e, b=button: b.itemconfigure(
                "sym_face", image=self._glass_image(40, 40, 13, b.tone, "hover")), add="+")

        self.greek_panel = tk.Frame(toolbar, bg="white")
        tk.Label(self.greek_panel, text="LETTERE GRECHE  ·  premi un simbolo per inserirlo",
                 font=(UI, 8, "bold"), bg="white", fg=MUTED).pack(anchor="w", padx=5, pady=(0, 4))
        self.greek_fan = tk.Canvas(self.greek_panel, bg="white", highlightthickness=0, height=64)
        self.greek_fan.pack(fill="x", padx=0, pady=(0, 2))
        self.greek_fan.bind("<Configure>", self._draw_greek_fan)
        self.greek_panel.pack_forget()

        # ---- Documento (scheda di vetro) ----
        editor_card = tk.Frame(self.stage, bg="white")
        self.edit_win = self.stage.create_window(0, 0, anchor="nw", window=editor_card)
        editor_head = tk.Frame(editor_card, bg="white")
        editor_head.pack(fill="x", padx=14, pady=(8, 10))
        tk.Label(editor_head, text="DOCUMENTO", font=(UI, 9, "bold"), bg="white", fg=MUTED).pack(side="left")
        tk.Label(editor_head, text="Testo semplice · salvataggio UTF-8", font=(UI, 9),
                 bg="white", fg=MUTED).pack(side="right")
        tk.Frame(editor_card, bg=LINE, height=1).pack(fill="x")

        text_area = tk.Frame(editor_card, bg="white")
        text_area.pack(fill="both", expand=True, padx=4, pady=4)
        self.editor = tk.Text(text_area, wrap="word", undo=True, padx=26, pady=22,
                              font=(MATH, 15), bg="white", fg=TEXT,
                              insertbackground=BLUE, selectbackground="#cfe4ff",
                              relief="flat", borderwidth=0, spacing1=2, spacing3=5)
        self.editor.tag_configure("placeholder", foreground="#94a3b8")
        self.truth_table_tag = "truth_table_block"
        self.editor.tag_configure(self.truth_table_tag, foreground="#1f4e8c")
        scroll = ttk.Scrollbar(text_area, orient="vertical", command=self.editor.yview)
        self.editor.configure(yscrollcommand=scroll.set)
        self.editor.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.notes_card = editor_card
        self.text_area = text_area
        self._show_placeholder()
        self.editor.bind("<FocusIn>", self._on_editor_focus)
        self.editor.bind("<FocusOut>", self._on_editor_blur)
        self.editor.bind("<<Modified>>", self._on_modified)
        self.truth_frame = tk.Frame(editor_card, bg="white")
        self._build_truth_table()

        self.stage.bind("<Configure>", self._queue_layout)
        self.after(30, self._layout)

    # ---------- layout e rendering dello sfondo ----------
    def _queue_layout(self, *_):
        if self._layout_job is None:
            self._layout_job = self.after(12, self._layout)

    def _layout(self):
        self._layout_job = None
        stage = self.stage
        W, H = stage.winfo_width(), stage.winfo_height()
        if W < 100 or H < 100:
            return
        s = self.ui_scale
        margin, top = round(32 * s), round(10 * s)
        header_h, inset, gap = round(82 * s), round(14 * s), round(14 * s)
        foot_h, shadow = round(40 * s), round(28 * s)
        self.toolbar_body.update_idletasks()
        body_h = self.toolbar_body.winfo_reqheight()
        card_w = W - 2 * margin
        tool_y = top + header_h
        tool_h = body_h + 2 * inset
        edit_y = tool_y + tool_h + gap
        edit_h = max(round(180 * s), H - foot_h - edit_y)
        # intestazione
        cy = top + header_h / 2
        logo = self._logo_photo.width()
        stage.coords(self.logo_item, margin, cy - logo / 2)
        tx = margin + logo + round(6 * s)
        stage.coords(self.title_item, tx, cy - round(11 * s))
        stage.coords(self.subtitle_item, tx, cy + round(14 * s))
        # schede e contenuti
        stage.coords(self.tool_card_item, margin - shadow, tool_y - shadow)
        stage.coords(self.edit_card_item, margin - shadow, edit_y - shadow)
        stage.coords(self.tool_win, margin + inset, tool_y + inset)
        stage.itemconfigure(self.tool_win, width=card_w - 2 * inset, height=body_h)
        stage.coords(self.edit_win, margin + inset, edit_y + inset)
        stage.itemconfigure(self.edit_win, width=card_w - 2 * inset, height=edit_h - 2 * inset)
        # piè di pagina
        fy = H - round(24 * s)
        stage.coords(self.status_dot, margin + round(8 * s), fy - round(4 * s),
                     margin + round(16 * s), fy + round(4 * s))
        stage.coords(self.status_item, margin + round(26 * s), fy)
        stage.coords(self.hint_item, W - margin - round(6 * s), fy)
        sizes = (W, H, card_w, tool_h, edit_h)
        if sizes != self._stage_sizes:
            self._stage_sizes = sizes
            if self._render_job is not None:
                self.after_cancel(self._render_job)
            self._render_job = self.after(40, self._render_stage)

    def _render_stage(self):
        self._render_job = None
        if not self._stage_sizes:
            return
        W, H, card_w, tool_h, edit_h = self._stage_sizes
        s = self.ui_scale
        shadow, radius = round(28 * s), round(26 * s)
        if self._card_tpl is None:
            size = 2 * radius + 6
            self._card_tpl = glass_surface(
                size, size, radius, (255, 255, 255), (249, 251, 255), (120, 130, 190),
                alpha=150, gloss=0.3, gloss_alpha=110, edge_alpha=60, highlight_alpha=230,
                shadow=shadow, shadow_dy=round(8 * s), shadow_alpha=70)
        corner = shadow + radius
        self._bg_photo = to_photo(make_backdrop(W, H))
        self._tool_photo = to_photo(nine_slice(self._card_tpl, corner, card_w + 2 * shadow, tool_h + 2 * shadow))
        self._edit_photo = to_photo(nine_slice(self._card_tpl, corner, card_w + 2 * shadow, edit_h + 2 * shadow))
        self.stage.itemconfigure(self.bg_item, image=self._bg_photo)
        self.stage.itemconfigure(self.tool_card_item, image=self._tool_photo)
        self.stage.itemconfigure(self.edit_card_item, image=self._edit_photo)

    def _make_logo_image(self):
        s = self.ui_scale
        size = round(52 * s)

        def overlay(draw, box, ss):
            x0, y0, bw, bh = box
            pts = [(x0 + bw * .5, y0 + bh * .30), (x0 + bw * .27, y0 + bh * .68), (x0 + bw * .73, y0 + bh * .68)]
            for a, b in ((0, 1), (0, 2), (1, 2)):
                draw.line([pts[a], pts[b]], fill=(235, 243, 255, 255), width=max(2, int(bw * .05)))
            for (px_, py_), color in zip(pts, ((255, 255, 255), (255, 255, 255), (103, 232, 249))):
                r = bw * .10
                draw.ellipse((px_ - r, py_ - r, px_ + r, py_ + r), fill=color + (255,))

        return glass_surface(size, size, round(16 * s), hex_rgb("#86c8ff"), hex_rgb("#1b6bff"), (30, 60, 160),
                             alpha=255, gloss_alpha=190, edge_alpha=150, overlay=overlay,
                             shadow=round(6 * s), shadow_dy=round(3 * s), shadow_alpha=90,
                             shadow_color=(30, 60, 170))

    # ---------- pulsanti di vetro ----------
    def _glass_image(self, w, h, r, tone, state="normal"):
        """Immagine di vetro in cache (w, h, r in pixel logici; viene scalata col DPI)."""
        key = (w, h, r, tone, state, self.ui_scale)
        photo = self._img_cache.get(key)
        if photo is None:
            top, bottom, _fg = TONES[tone]
            top, bottom = hex_rgb(top), hex_rgb(bottom)
            gloss_alpha = 170
            if state == "hover":
                top, bottom, gloss_alpha = mix(top, (255, 255, 255), .35), mix(bottom, (255, 255, 255), .18), 205
            elif state == "press":
                top, bottom, gloss_alpha = mix(top, (0, 0, 0), .06), mix(bottom, (0, 0, 0), .10), 100
            s = self.ui_scale
            edge = mix(bottom, (40, 50, 110), .35)
            img = glass_surface(round(w * s), round(h * s), round(r * s), top, bottom, edge,
                                alpha=245, gloss_alpha=gloss_alpha)
            photo = self._img_cache[key] = to_photo(img)
        return photo

    def _cell_image(self, header, focused):
        key = ("cell", header, focused, self.ui_scale)
        photo = self._img_cache.get(key)
        if photo is None:
            s = self.ui_scale
            top, bottom = ((237, 245, 255), (222, 236, 255)) if header else ((255, 255, 255), (247, 249, 255))
            edge = (10, 132, 255) if focused else (168, 178, 210)
            img = glass_surface(round(132 * s), round(52 * s), round(13 * s), top, bottom, edge,
                                alpha=255, gloss=0.35, gloss_alpha=70,
                                edge_alpha=255 if focused else 150, edge_width=2 if focused else 1)
            photo = self._img_cache[key] = to_photo(img)
        return photo

    def _rounded_button(self, parent, text, command, *, primary=False, width=None, side="left",
                        variant="default", gap=(0, 8), pady=0, tone=None):
        """Pulsante in vetro colorato: pastello (tone) oppure blu pieno (primary)."""
        width = width or max(76, len(text) * 8 + 30)
        height = 38
        s = self.ui_scale
        tone = "blue" if primary else (tone or "clear")
        try:
            parent_bg = parent.cget("bg")
        except tk.TclError:
            parent_bg = "white"
        c = tk.Canvas(parent, width=round(width * s), height=round(height * s),
                      bg=parent_bg, highlightthickness=0, cursor="hand2")
        c.pack(side=side, padx=gap, pady=pady)
        c.glass_imgs = {st: self._glass_image(width, height, 14, tone, st) for st in ("normal", "hover", "press")}
        c.glass_size = (width, height)
        c.create_image(0, 0, anchor="nw", image=c.glass_imgs["normal"], tags="face")
        c.create_text(round(width * s / 2), round(height * s / 2), text=text, fill=TONES[tone][2],
                      font=(UI, 10, "bold" if primary else "normal"), tags="label")
        c.bind("<Button-1>", lambda _e: command())
        c.bind("<Enter>", lambda _e, canvas=c: self._button_hover(canvas, True))
        c.bind("<Leave>", lambda _e, canvas=c: self._button_hover(canvas, False))
        c.bind("<ButtonPress-1>", lambda _e: (c.itemconfigure("face", image=c.glass_imgs["press"]),
                                              c.move("label", 0, 1)), add="+")
        c.bind("<ButtonRelease-1>", lambda _e: (c.itemconfigure("face", image=c.glass_imgs["hover"]),
                                                c.move("label", 0, -1)), add="+")
        c.button_variant = variant
        c.tone = tone
        return c

    def _button_hover(self, canvas, hovering):
        canvas.configure(cursor="hand2")
        if getattr(canvas, "_is_hovered", False) == hovering:
            return
        canvas._is_hovered = hovering
        if canvas.button_variant == "mode":
            self._style_mode_buttons()
            return
        canvas.itemconfigure("face", image=canvas.glass_imgs["hover" if hovering else "normal"])

    def _symbol_hover(self, button, hovering, description=None):
        button.itemconfigure("sym_face", image=self._glass_image(40, 40, 13, button.tone,
                                                                  "hover" if hovering else "normal"))
        self.status_var.set(description if hovering and description else "Pronto")

    def _style_mode_buttons(self):
        """La modalità attiva è in vetro blu; l'altra è in vetro chiaro."""
        if not hasattr(self, "notes_mode_button") or not hasattr(self, "truth_mode_button"):
            return
        for button, selected in ((self.notes_mode_button, self.mode == "appunti"),
                                 (self.truth_mode_button, self.mode == "truth")):
            tone = "blue" if selected else "clear"
            state = "hover" if getattr(button, "_is_hovered", False) and not selected else "normal"
            w, h = button.glass_size
            button.itemconfigure("face", image=self._glass_image(w, h, 14, tone, state))
            button.itemconfigure("label", fill=TONES[tone][2], font=(UI, 10, "bold" if selected else "normal"))

    def toggle_greek_palette(self):
        """Show or hide the inline fan of Greek letter buttons."""
        self.greek_palette_open = not self.greek_palette_open
        if self.greek_palette_open:
            self.greek_panel.pack(fill="x", padx=4, pady=(0, 6))
            self.greek_toggle_button.itemconfigure("label", text="α  Chiudi")
            self.status_var.set("Scegli una lettera greca da inserire")
            self.after_idle(lambda: self._draw_greek_fan())
        else:
            self.greek_panel.pack_forget()
            self.greek_toggle_button.itemconfigure("label", text="α  Greche")
            self.status_var.set("Pronto")
        self._queue_layout()

    def _draw_greek_fan(self, _event=None):
        """Lettere greche su un ventaglio leggermente curvo, con tasti di vetro pastello."""
        if not hasattr(self, "greek_fan") or not self.greek_fan.winfo_exists():
            return
        canvas = self.greek_fan
        k = self.ui_scale
        key = round(32 * k)
        step = round(38 * k)
        row_height = round(46 * k)
        width = max(160, canvas.winfo_width())
        per_row = max(12, min(len(GREEK_SYMBOLS), (width - round(40 * k)) // step))
        row_count = math.ceil(len(GREEK_SYMBOLS) / per_row)
        canvas.configure(height=row_count * row_height + round(16 * k))
        canvas.delete("all")
        for row in range(row_count):
            start = row * per_row
            batch = GREEK_SYMBOLS[start:start + per_row]
            spacing = min(step, (width - round(44 * k)) / max(1, len(batch) - 1))
            span = spacing * (len(batch) - 1)
            base_y = round(4 * k) + row * row_height
            for offset, (symbol, name) in enumerate(batch):
                t = 0 if len(batch) == 1 else (offset / (len(batch) - 1)) * 2 - 1
                x = width / 2 - span / 2 + offset * spacing
                y = base_y + round(15 * k) * abs(t) ** 1.45
                tone = KEY_TONES[(start + offset) % len(KEY_TONES)]
                tag = f"greek_symbol_{start + offset}"
                canvas.create_image(x - key / 2, y, anchor="nw", image=self._glass_image(32, 32, 11, tone),
                                    tags=(tag, f"{tag}_f"))
                canvas.create_text(x, y + key / 2 - 1, text=symbol, fill=TONES[tone][2],
                                   font=(MATH, 14, "bold"), tags=(tag, "greek_label"))
                canvas.tag_bind(tag, "<Button-1>", lambda _event, value=symbol: self.insert_symbol(value))
                canvas.tag_bind(tag, "<Enter>", lambda _event, title=name, t_=tag, tn=tone: (
                    self.status_var.set(title),
                    canvas.itemconfigure(f"{t_}_f", image=self._glass_image(32, 32, 11, tn, "hover"))))
                canvas.tag_bind(tag, "<Leave>", lambda _event, t_=tag, tn=tone: (
                    self.status_var.set("Scegli una lettera greca"),
                    canvas.itemconfigure(f"{t_}_f", image=self._glass_image(32, 32, 11, tn))))
        self._queue_layout()

    def open_law_formulary(self):
        """Open a searchable reference of well-known classical equivalences."""
        window = tk.Toplevel(self)
        window.title("Formulario di logica classica")
        window.geometry("760x680")
        window.minsize(620, 500)
        window.configure(bg=BG)
        window.transient(self)
        window.bind("<Escape>", lambda _event: window.destroy())

        outer = tk.Frame(window, bg=BG)
        outer.pack(fill="both", expand=True, padx=22, pady=20)
        heading = tk.Frame(outer, bg=BG)
        heading.pack(fill="x", pady=(0, 14))
        tk.Label(heading, text="Formulario di logica classica",
                 font=("Segoe UI", 19, "bold"), bg=BG, fg=INK).pack(anchor="w")
        tk.Label(heading, text="Equivalenze proposizionali fondamentali",
                 font=("Segoe UI", 10), bg=BG, fg=MUTED).pack(anchor="w", pady=(3, 0))

        search_card = tk.Frame(outer, bg="white", highlightbackground=LINE_STRONG, highlightthickness=1)
        search_card.pack(fill="x", pady=(0, 12))
        tk.Label(search_card, text="⌕", font=("Segoe UI", 17), bg="white", fg=BLUE).pack(side="left", padx=(14, 6))
        search_var = tk.StringVar()
        placeholder = "Cerca per nome o simbolo…"
        search_entry = tk.Entry(search_card, textvariable=search_var, relief="flat", bd=0,
                                font=("Segoe UI", 11), bg="white", fg=MUTED,
                                insertbackground=BLUE)
        search_entry.pack(side="left", fill="x", expand=True, padx=(0, 14), ipady=12)
        search_var.set(placeholder)

        count_var = tk.StringVar()
        tk.Label(outer, textvariable=count_var, font=("Segoe UI", 9), bg=BG, fg=MUTED).pack(anchor="w", pady=(0, 6))
        results_shell = tk.Frame(outer, bg=BG)
        results_shell.pack(fill="both", expand=True)
        result_canvas = tk.Canvas(results_shell, bg=BG, highlightthickness=0)
        result_scroll = ttk.Scrollbar(results_shell, orient="vertical", command=result_canvas.yview)
        result_canvas.configure(yscrollcommand=result_scroll.set)
        result_scroll.pack(side="right", fill="y")
        result_canvas.pack(side="left", fill="both", expand=True)
        window.bind("<MouseWheel>", lambda event: self._route_formulary_wheel(event, result_canvas))
        if self._touchpad_scroll_supported:
            window.bind("<TouchpadScroll>", lambda event: self._route_formulary_touchpad(event, result_canvas))
        result_list = tk.Frame(result_canvas, bg=BG)
        result_window = result_canvas.create_window((0, 0), window=result_list, anchor="nw")
        result_list.bind("<Configure>", lambda _event: result_canvas.configure(scrollregion=result_canvas.bbox("all")))
        result_canvas.bind("<Configure>", lambda event: result_canvas.itemconfigure(result_window, width=event.width))
        self._bind_formulary_scroll_tree(result_canvas, result_canvas)

        def insert_and_focus(formula):
            self.insert_symbol(formula)
            self.status_var.set("Formula inserita")

        def render_results(*_args):
            query = search_var.get().strip().casefold()
            if query == placeholder.casefold():
                query = ""
            for child in result_list.winfo_children():
                child.destroy()
            matches = [law for law in CLASSICAL_LAWS
                       if not query or query in " ".join(law).casefold()]
            count_var.set(f"{len(matches)} leggi" if matches else "Nessuna legge trovata")
            for index, (name, formula, explanation) in enumerate(matches, start=1):
                card = tk.Frame(result_list, bg="white", highlightbackground=LINE, highlightthickness=1)
                card.pack(fill="x", pady=(0, 9))
                title_row = tk.Frame(card, bg="white")
                title_row.pack(fill="x", padx=14, pady=(11, 3))
                badge = tk.Label(title_row, text=f"{index:02d}", font=("Segoe UI", 8, "bold"),
                                 bg=SKY, fg=BLUE, padx=8, pady=3)
                badge.pack(side="left", padx=(0, 9))
                tk.Label(title_row, text=name, font=("Segoe UI", 11, "bold"),
                         bg="white", fg=INK).pack(side="left", anchor="w")
                self._rounded_button(title_row, "Inserisci", lambda value=formula: insert_and_focus(value),
                                     width=88, tone="sky", side="right")
                tk.Label(card, text=formula, font=("Cambria", 13, "bold"), bg="white",
                         fg="#3730a3", justify="left", anchor="w", wraplength=650).pack(
                             fill="x", padx=16, pady=(3, 2))
                tk.Label(card, text=explanation, font=("Segoe UI", 9), bg="white",
                         fg=MUTED, justify="left", anchor="w", wraplength=650).pack(
                             fill="x", padx=16, pady=(2, 12))
                self._bind_formulary_scroll_tree(card, result_canvas)
            result_canvas.configure(scrollregion=result_canvas.bbox("all"))
            result_canvas.yview_moveto(0)
            self._smooth_scroll_states[str(result_canvas)] = (0.0, 0.0)

        def focus_search(_event=None):
            if search_var.get() == placeholder:
                search_var.set("")
                search_entry.configure(fg=INK)

        def blur_search(_event=None):
            if not search_var.get().strip():
                search_var.set(placeholder)
                search_entry.configure(fg=MUTED)

        search_entry.bind("<FocusIn>", focus_search)
        search_entry.bind("<FocusOut>", blur_search)
        search_var.trace_add("write", render_results)
        render_results()
        search_entry.focus_set()
        window.grab_set()

    def _draw_capsule(self, canvas, x1, y1, x2, y2, color, tag):
        radius = (y2 - y1) / 2
        canvas.create_rectangle(x1 + radius, y1, x2 - radius, y2, fill=color, outline="", tags=tag)
        canvas.create_oval(x1, y1, x1 + 2 * radius, y2, fill=color, outline="", tags=tag)
        canvas.create_oval(x2 - 2 * radius, y1, x2, y2, fill=color, outline="", tags=tag)

    @staticmethod
    def _rounded_surface(canvas, x1, y1, x2, y2, radius, color, tag):
        radius = max(0, min(radius, (x2 - x1) / 2, (y2 - y1) / 2))
        if radius == 0:
            canvas.create_rectangle(x1, y1, x2, y2, fill=color, outline="", tags=tag)
            return
        points = []
        for cx, cy, start in (
            (x2 - radius, y1 + radius, -90),
            (x2 - radius, y2 - radius, 0),
            (x1 + radius, y2 - radius, 90),
            (x1 + radius, y1 + radius, 180),
        ):
            for step in range(7):
                angle = math.radians(start + step * 15)
                points.extend((cx + radius * math.cos(angle), cy + radius * math.sin(angle)))
        canvas.create_polygon(*points, fill=color, outline="", smooth=True,
                              splinesteps=18, tags=tag)

    def _build_truth_table(self):
        top = tk.Frame(self.truth_frame, bg="white")
        top.pack(fill="x", padx=20, pady=(16, 12))
        tk.Label(top, text="Tavola di verità", font=(UI, 16, "bold"), bg="white", fg=INK).pack(side="left")
        dimensions = tk.Frame(top, bg="white")
        dimensions.pack(side="left", padx=14)
        tk.Label(dimensions, text="Griglia", font=("Segoe UI", 9), bg="white", fg=MUTED).pack(side="left", padx=(0, 6))
        self.rows_var = tk.StringVar(value=str(self.table_rows))
        self.cols_var = tk.StringVar(value=str(self.table_cols))
        self.rows_spinbox = tk.Spinbox(dimensions, from_=1, to=30, width=3, textvariable=self.rows_var,
                                       justify="center", font=("Segoe UI", 10), relief="flat", bd=0,
                                       bg=SOFT, fg=NAVY, buttonbackground="#e0e7ff",
                                       highlightthickness=1, highlightbackground=LINE_STRONG,
                                       highlightcolor=BLUE, command=self.configure_table)
        self.rows_spinbox.pack(side="left", ipady=4)
        tk.Label(dimensions, text="×", font=("Segoe UI", 11, "bold"), bg="white", fg=BLUE).pack(side="left", padx=6)
        self.cols_spinbox = tk.Spinbox(dimensions, from_=1, to=16, width=3, textvariable=self.cols_var,
                                       justify="center", font=("Segoe UI", 10), relief="flat", bd=0,
                                       bg=SOFT, fg=NAVY, buttonbackground="#e0e7ff",
                                       highlightthickness=1, highlightbackground=LINE_STRONG,
                                       highlightcolor=BLUE, command=self.configure_table)
        self.cols_spinbox.pack(side="left", ipady=4)
        self.rows_spinbox.bind("<Return>", self.configure_table)
        self.cols_spinbox.bind("<Return>", self.configure_table)
        self._rounded_button(top, "Inserisci negli appunti", self.insert_table_into_notes,
                             primary=True, width=170, side="right")
        self._rounded_button(top, "Ripulisci tavola", self.clear_truth_table,
                             width=142, tone="periwinkle", side="right")

        self.table_canvas = tk.Canvas(self.truth_frame, bg="white", highlightthickness=0)
        vbar = ttk.Scrollbar(self.truth_frame, orient="vertical", command=self.table_canvas.yview)
        hbar = ttk.Scrollbar(self.truth_frame, orient="horizontal", command=self.table_canvas.xview)
        self.table_canvas.configure(yscrollcommand=vbar.set, xscrollcommand=hbar.set)
        self._bind_table_wheel(self.table_canvas)
        self._bind_touchpad_scroll(self.table_canvas)
        self._bind_table_pan(self.table_canvas)
        self.table_canvas.pack(side="top", fill="both", expand=True, padx=(16, 0), pady=(0, 4))
        vbar.pack(side="right", fill="y", pady=(0, 4))
        hbar.pack(side="bottom", fill="x", padx=(16, 0))
        self.table_grid = tk.Frame(self.table_canvas, bg="white")
        self.table_canvas_window = self.table_canvas.create_window((round(6 * self.ui_scale), round(6 * self.ui_scale)), window=self.table_grid, anchor="nw")
        self.table_grid.bind("<Configure>", lambda _e: self.table_canvas.configure(scrollregion=self.table_canvas.bbox("all")))
        self._bind_table_pan(self.table_grid)
        self._bind_table_wheel(self.table_grid)
        self._bind_touchpad_scroll(self.table_grid)
        self.table_entries = []
        self._render_truth_table()

    def _render_truth_table(self):
        # Clear focus before destroying old entries, then reset row/column sizing
        # so removed cells cannot leave blue focus marks or stale blank space.
        focused = self.focus_get()
        if focused is not None:
            widget = focused
            while widget is not None and widget is not self.table_grid:
                widget = getattr(widget, "master", None)
            if widget is self.table_grid:
                self.focus_set()
        self.active_table_entry = None
        for child in self.table_grid.winfo_children():
            child.destroy()
        for index in range(30):
            self.table_grid.grid_rowconfigure(index, weight=0, minsize=0, pad=0)
        for index in range(16):
            self.table_grid.grid_columnconfigure(index, weight=0, minsize=0, pad=0)
        self.table_grid.configure(width=1, height=1)
        self.table_cells = []
        self.table_entries = []
        for row in range(self.table_rows):
            row_vars = []
            row_entries = []
            for col in range(self.table_cols):
                value = self.table_data[row][col] if hasattr(self, "table_data") and row < len(self.table_data) and col < len(self.table_data[row]) else ""
                var = tk.StringVar(value=value)
                scale = self.ui_scale
                cell_bg = "#e6f0ff" if row == 0 else "#fbfcff"
                cell = tk.Canvas(self.table_grid, width=round(132 * scale), height=round(52 * scale),
                                 bg="white", highlightthickness=0)
                cell.grid_pos = (row, col)
                cell.focused = False
                entry = tk.Entry(cell, textvariable=var, width=12, justify="center",
                                 font=(MATH, 13), relief="flat", bd=0, bg="white",
                                 fg=INK, insertbackground=BLUE, highlightthickness=0)
                cell.entry_win = cell.create_window(round(66 * scale), round(26 * scale), window=entry,
                                                    width=round(112 * scale), height=round(34 * scale))
                cell.grid(row=row, column=col, padx=0, pady=0, sticky="nsew")
                cell.bind("<Configure>", lambda _e, surface=cell: self._paint_cell(surface))
                var.trace_add("write", lambda *_a, c=cell, e=entry, v=var: self._style_cell(c, e, v.get()))
                self._style_cell(cell, entry, value)
                entry.bind("<FocusIn>", lambda event, surface=cell: self._focus_table_cell(event.widget, surface, True))
                entry.bind("<FocusOut>", lambda event, surface=cell: self._focus_table_cell(event.widget, surface, False))
                entry.bind("<KeyRelease>", self._on_table_edit)
                entry.bind("<Up>", lambda _event, r=row, c=col: self._move_table_focus(r - 1, c))
                entry.bind("<Down>", lambda _event, r=row, c=col: self._move_table_focus(r + 1, c))
                entry.bind("<Left>", lambda _event, r=row, c=col: self._move_table_focus(r, c - 1))
                entry.bind("<Right>", lambda _event, r=row, c=col: self._move_table_focus(r, c + 1))
                entry.bind("<Return>", lambda _event, r=row, c=col: self._move_table_focus(r + 1, c))
                entry.bind("<KP_Enter>", lambda _event, r=row, c=col: self._move_table_focus(r + 1, c))
                self._bind_table_pan(entry)
                self._bind_table_pan(cell)
                self._bind_table_wheel(entry)
                self._bind_table_wheel(cell)
                self._bind_touchpad_scroll(entry)
                self._bind_touchpad_scroll(cell)
                row_vars.append(var)
                row_entries.append(entry)
            self.table_cells.append(row_vars)
            self.table_entries.append(row_entries)
        for col in range(self.table_cols):
            self.table_grid.grid_columnconfigure(col, weight=1, minsize=round(132 * self.ui_scale))
        self.rows_var.set(str(self.table_rows))
        self.cols_var.set(str(self.table_cols))
        self.table_canvas.configure(scrollregion=(0, 0, 0, 0))
        self.table_canvas.xview_moveto(0)
        self.table_canvas.yview_moveto(0)
        self.after_idle(self._refresh_table_scrollregion)

    def _refresh_table_scrollregion(self):
        bounds = self.table_canvas.bbox("all")
        if bounds:
            self.table_canvas.configure(scrollregion=bounds)

    def _on_table_edit(self, _event=None):
        self.dirty = True
        self._update_title()

    def _move_table_focus(self, row, col):
        """Move keyboard focus to an adjacent truth-table cell, clamped to the grid."""
        row = min(max(row, 0), self.table_rows - 1)
        col = min(max(col, 0), self.table_cols - 1)
        entry = self.table_entries[row][col]
        entry.focus_set()
        entry.icursor("end")
        self.active_table_entry = entry
        self.after_idle(self._ensure_table_entry_visible, entry)
        return "break"

    def _ensure_table_entry_visible(self, entry):
        """Scroll the table canvas when keyboard navigation reaches an off-screen cell."""
        if not entry.winfo_exists() or self.mode != "truth":
            return
        self.update_idletasks()
        bounds = self.table_canvas.bbox("all")
        if not bounds:
            return
        canvas = self.table_canvas
        view_left = canvas.canvasx(0)
        view_top = canvas.canvasy(0)
        x = canvas.canvasx(entry.winfo_rootx() - canvas.winfo_rootx())
        y = canvas.canvasy(entry.winfo_rooty() - canvas.winfo_rooty())
        width = max(1, canvas.winfo_width())
        height = max(1, canvas.winfo_height())
        target_left = view_left
        target_top = view_top
        if x < view_left:
            target_left = x
        elif x + entry.winfo_width() > view_left + width:
            target_left = x + entry.winfo_width() - width
        if y < view_top:
            target_top = y
        elif y + entry.winfo_height() > view_top + height:
            target_top = y + entry.winfo_height() - height
        region_width = max(1, bounds[2] - bounds[0])
        region_height = max(1, bounds[3] - bounds[1])
        canvas.xview_moveto(max(0, min(1, (target_left - bounds[0]) / region_width)))
        canvas.yview_moveto(max(0, min(1, (target_top - bounds[1]) / region_height)))

    def _format_truth_table_for_page(self):
        rows = [[var.get() for var in row] for row in self.table_cells]
        col_count = self.table_cols
        available_px = max(360, self.editor.winfo_width() - 48)
        font_size = 10
        mono = tkfont.Font(self, family="Consolas", size=font_size)
        while font_size > 8 and mono.measure("M") * (3 * col_count + 1 + col_count * 2) > available_px:
            font_size -= 1
            mono.configure(size=font_size)
        char_budget = max(col_count + 5, int(available_px / max(1, mono.measure("M"))))
        cell_budget = max(1, (char_budget - 3 * (col_count - 1) - 4) // col_count)
        widths = [max(1, min(cell_budget, max([len(r[c]) for r in rows] or [1]))) for c in range(col_count)]
        remaining = max(0, char_budget - (3 * (col_count - 1) + 4) - sum(widths))
        for c in range(col_count):
            room = max(0, max([len(r[c]) for r in rows] or [1]) - widths[c])
            extra = min(room, remaining)
            widths[c] += extra
            remaining -= extra

        def fit(value, width):
            if len(value) <= width:
                return value.ljust(width)
            if width == 1:
                return "…"
            return value[:width - 1] + "…"

        top = "┌" + "┬".join("─" * (width + 2) for width in widths) + "┐"
        divider = "├" + "┼".join("─" * (width + 2) for width in widths) + "┤"
        heavy = "╞" + "╪".join("═" * (width + 2) for width in widths) + "╡"
        bottom = "└" + "┴".join("─" * (width + 2) for width in widths) + "┘"
        lines = [top]
        for index, row in enumerate(rows):
            lines.append("│ " + " │ ".join(fit(row[c], widths[c]) for c in range(col_count)) + " │")
            if index == 0 and len(rows) > 1:
                lines.append(heavy)
            elif index < len(rows) - 1:
                lines.append(divider)
        lines.append(bottom)
        self.editor.tag_configure(self.truth_table_tag, font=mono, foreground="#312e81")
        return "\n".join(lines)

    def insert_table_into_notes(self):
        table_text = self._format_truth_table_for_page()
        has_notes = bool(self._content().strip()) if self.mode == "appunti" else bool(self.editor.get("1.0", "end-1c").strip() and not self.placeholder_visible)
        self.show_notes()
        self._clear_placeholder()
        prefix = "\n\n" if has_notes else ""
        self.editor.insert("insert", prefix)
        self.editor.insert("insert", table_text, self.truth_table_tag)
        self.editor.insert("insert", "\n\n")
        self.editor.focus_set()
        self.dirty = True
        self._update_title()
        self.status_var.set("Tavola inserita negli appunti")

    @staticmethod
    def _truth_kind(text):
        value = text.strip().casefold()
        if value in ("v", "vero", "t", "true", "1"):
            return "true"
        if value in ("f", "falso", "false", "0"):
            return "false"
        return ""

    def _style_cell(self, cell, entry, text):
        """Prima riga = intestazione con le formule; V in azzurro, F in viola."""
        if not cell.winfo_exists():
            return
        if cell.grid_pos[0] == 0:
            kind = "header"
        else:
            kind = self._truth_kind(text) or "plain"
        fill, ink, font = {
            "header": ("#dfeaff", "#1e2f86", (MATH, 14, "bold")),
            "true": ("#e3efff", "#1d62d6", (MATH, 13, "bold")),
            "false": ("#eee8ff", "#6a43c2", (MATH, 13, "bold")),
            "plain": ("#ffffff", INK, (MATH, 13)),
        }[kind]
        cell.fill = fill
        entry.configure(bg=fill, fg=ink, font=font)
        self._paint_cell(cell)

    def _paint_cell(self, cell):
        """Disegna fondo, linee sottili, bordi spessi (intestazione e contorno) e anello di selezione."""
        if not cell.winfo_exists():
            return
        w, h = cell.winfo_width(), cell.winfo_height()
        if w < 8 or h < 8:
            w, h = int(float(cell.cget("width"))), int(float(cell.cget("height")))
        s = self.ui_scale
        thick = max(2, round(2 * s))
        row, col = cell.grid_pos
        grid_color, strong = "#b8c4e6", "#2c3e9e"
        cell.delete("paint")
        cell.create_rectangle(0, 0, w, h, fill=getattr(cell, "fill", "white"), outline="", tags="paint")
        cell.create_rectangle(w - 1, 0, w, h, fill=grid_color, outline="", tags="paint")
        cell.create_rectangle(0, h - 1, w, h, fill=grid_color, outline="", tags="paint")
        if col == 0:
            cell.create_rectangle(0, 0, thick, h, fill=strong, outline="", tags="paint")
        if col == self.table_cols - 1:
            cell.create_rectangle(w - thick, 0, w, h, fill=strong, outline="", tags="paint")
        if row == 0:
            cell.create_rectangle(0, 0, w, thick, fill=strong, outline="", tags="paint")
        if row == 0 or row == self.table_rows - 1:
            cell.create_rectangle(0, h - thick, w, h, fill=strong, outline="", tags="paint")
        if getattr(cell, "focused", False):
            cell.create_rectangle(thick + 1, thick + 1, w - thick - 2, h - thick - 2,
                                  outline=BLUE, width=2, tags="paint")
        cell.tag_lower("paint")
        cell.coords(cell.entry_win, w / 2, h / 2)
        cell.itemconfigure(cell.entry_win, width=max(20, w - round(18 * s)), height=max(20, h - round(20 * s)))

    def _focus_table_cell(self, entry, surface, focused):
        self.active_table_entry = entry
        surface.focused = focused
        self._paint_cell(surface)

    def _on_table_wheel(self, event):
        """Convert wheel input into low-sensitivity pixel movement."""
        delta = getattr(event, "delta", 0)
        if not delta:
            return "break"
        pixels = -float(delta) * 0.25
        if getattr(event, "state", 0) & 0x0001:
            self._scroll_table_by_pixels(pixels, 0)
        else:
            self._scroll_table_by_pixels(0, pixels)
        return "break"

    def _bind_table_pan(self, widget):
        """Allow drag panning, including touchscreens that send mouse gestures."""
        widget.bind("<ButtonPress-1>", self._start_table_pan, add="+")
        widget.bind("<B1-Motion>", self._move_table_pan, add="+")
        widget.bind("<ButtonRelease-1>", self._stop_table_pan, add="+")

    def _bind_table_wheel(self, widget):
        widget.bind("<MouseWheel>", self._on_table_wheel, add="+")
        widget.bind("<Shift-MouseWheel>", self._on_table_wheel, add="+")
        widget.bind("<Button-4>", lambda _e: self._scroll_table_by_pixels(0, -30), add="+")
        widget.bind("<Button-5>", lambda _e: self._scroll_table_by_pixels(0, 30), add="+")

    def _scroll_table_by_pixels(self, dx, dy):
        """Move the canvas by accumulated pixels for smooth high-resolution input."""
        self._scroll_canvas_by_pixels(self.table_canvas, dx, dy)

    def _scroll_canvas_by_pixels(self, canvas, dx, dy):
        """Accumulate fractional wheel deltas and move a canvas in small steps."""
        bounds = canvas.bbox("all")
        if not bounds:
            return
        if canvas is self.table_canvas:
            pending_x, pending_y = self._scroll_pending_x, self._scroll_pending_y
        else:
            pending_x, pending_y = self._smooth_scroll_states.get(str(canvas), (0.0, 0.0))
        pending_x += dx
        pending_y += dy
        move_x = math.trunc(pending_x)
        move_y = math.trunc(pending_y)
        if not move_x and not move_y:
            if canvas is self.table_canvas:
                self._scroll_pending_x, self._scroll_pending_y = pending_x, pending_y
            else:
                self._smooth_scroll_states[str(canvas)] = (pending_x, pending_y)
            return

        left, top, right, bottom = bounds
        region_width = max(1, right - left)
        region_height = max(1, bottom - top)
        view_width = max(1, canvas.winfo_width())
        view_height = max(1, canvas.winfo_height())
        current_x = canvas.canvasx(0)
        current_y = canvas.canvasy(0)
        max_x = max(left, right - view_width)
        max_y = max(top, bottom - view_height)
        next_x = min(max_x, max(left, current_x + move_x))
        next_y = min(max_y, max(top, current_y + move_y))
        canvas.xview_moveto((next_x - left) / region_width)
        canvas.yview_moveto((next_y - top) / region_height)
        pending_x = 0.0 if next_x in (left, max_x) else pending_x - move_x
        pending_y = 0.0 if next_y in (top, max_y) else pending_y - move_y
        if canvas is self.table_canvas:
            self._scroll_pending_x, self._scroll_pending_y = pending_x, pending_y
        else:
            self._smooth_scroll_states[str(canvas)] = (pending_x, pending_y)

    def _on_formulary_wheel(self, event, canvas):
        """Map a two-finger vertical wheel gesture to gentle pixel movement."""
        delta = getattr(event, "delta", 0)
        if delta:
            self._scroll_canvas_by_pixels(canvas, 0, -float(delta) * 0.18)
        return "break"

    def _route_formulary_wheel(self, event, canvas):
        """Handle wheel events routed to the focused window when the pointer is over results."""
        if self._pointer_over_canvas(event, canvas):
            return self._on_formulary_wheel(event, canvas)

    def _route_formulary_touchpad(self, event, canvas):
        if self._pointer_over_canvas(event, canvas):
            return self._on_touchpad_scroll(event, canvas)

    @staticmethod
    def _pointer_over_canvas(event, canvas):
        x, y = event.x_root, event.y_root
        left, top = canvas.winfo_rootx(), canvas.winfo_rooty()
        return left <= x <= left + canvas.winfo_width() and top <= y <= top + canvas.winfo_height()

    def _bind_formulary_scroll_tree(self, widget, canvas):
        """Route gestures from formula cards and their controls to the list."""
        widget.bind("<MouseWheel>", lambda event, target=canvas: self._on_formulary_wheel(event, target), add="+")
        widget.bind("<Button-4>", lambda _event, target=canvas: self._scroll_canvas_by_pixels(target, 0, -22), add="+")
        widget.bind("<Button-5>", lambda _event, target=canvas: self._scroll_canvas_by_pixels(target, 0, 22), add="+")
        if self._touchpad_scroll_supported:
            widget.bind("<TouchpadScroll>", lambda event, target=canvas: self._on_touchpad_scroll(event, target), add="+")
        for child in widget.winfo_children():
            self._bind_formulary_scroll_tree(child, canvas)

    def _bind_touchpad_scroll(self, widget, canvas=None):
        if self._touchpad_scroll_supported:
            widget.bind("<TouchpadScroll>", lambda event, target=canvas or self.table_canvas:
                        self._on_touchpad_scroll(event, target), add="+")

    def _bind_native_touchpad_scroll(self):
        """Detect Tk's native two-axis touchpad event when available (Tk 9+)."""
        try:
            version = tuple(int(part) for part in self.tk.call("info", "patchlevel").split(".")[:2])
        except (ValueError, tk.TclError):
            version = (0, 0)
        self._touchpad_scroll_supported = version >= (9, 0)

    def _on_touchpad_scroll(self, event, canvas=None):
        """Handle native two-axis, two-finger touchpad events in Tk 9."""
        try:
            dx, dy = self.tk.call("tk::PreciseScrollDeltas", event.delta)
            self._scroll_canvas_by_pixels(canvas or self.table_canvas,
                                          -float(dx) * 3, -float(dy) * 3)
        except (tk.TclError, TypeError, ValueError):
            pass
        return "break"

    def _install_horizontal_wheel_hook(self):
        """Tk 8.6 omits native WM_MOUSEHWHEEL; route that axis to the table."""
        if sys.platform != "win32" or self._touchpad_scroll_supported:
            return
        try:
            user32 = ctypes.windll.user32
            kernel32 = ctypes.windll.kernel32
            hook_type = ctypes.WINFUNCTYPE(ctypes.c_ssize_t, ctypes.c_int,
                                           ctypes.c_size_t, ctypes.c_ssize_t)

            def get_message(code, message_kind, message_pointer):
                try:
                    if code >= 0 and message_kind == 1:
                        msg = ctypes.cast(message_pointer, ctypes.POINTER(wintypes.MSG)).contents
                        if msg.message == 0x020E and self.mode == "truth":
                            delta = ctypes.c_short((int(msg.wParam) >> 16) & 0xFFFF).value
                            self.after(0, self._scroll_native_horizontal, delta)
                            return 1
                except Exception:
                    pass
                return user32.CallNextHookEx(self._wheel_hook, code, message_kind, message_pointer)

            self._wheel_hook_proc = hook_type(get_message)
            user32.SetWindowsHookExW.restype = ctypes.c_void_p
            user32.SetWindowsHookExW.argtypes = [ctypes.c_int, hook_type, ctypes.c_void_p, ctypes.c_uint]
            user32.CallNextHookEx.restype = ctypes.c_ssize_t
            user32.CallNextHookEx.argtypes = [ctypes.c_void_p, ctypes.c_int,
                                               ctypes.c_size_t, ctypes.c_ssize_t]
            user32.UnhookWindowsHookEx.argtypes = [ctypes.c_void_p]
            self._wheel_hook = user32.SetWindowsHookExW(
                3, self._wheel_hook_proc, None, kernel32.GetCurrentThreadId())
        except Exception:
            self._wheel_hook = None

    def _scroll_native_horizontal(self, delta):
        if self.mode == "truth" and delta:
            self._scroll_table_by_pixels(float(delta) * 0.25, 0)

    def _remove_horizontal_wheel_hook(self):
        if self._wheel_hook:
            try:
                ctypes.windll.user32.UnhookWindowsHookEx(self._wheel_hook)
            except (AttributeError, OSError):
                pass
            self._wheel_hook = None

    def _start_table_pan(self, event):
        x = self.table_canvas.canvasx(event.x_root - self.table_canvas.winfo_rootx())
        y = self.table_canvas.canvasy(event.y_root - self.table_canvas.winfo_rooty())
        self._pan_origin = (event.x_root, event.y_root)
        self.table_canvas.scan_mark(x, y)

    def _move_table_pan(self, event):
        if self._pan_origin is None:
            return
        start_x, start_y = self._pan_origin
        if abs(event.x_root - start_x) > 3 or abs(event.y_root - start_y) > 3:
            x = self.table_canvas.canvasx(event.x_root - self.table_canvas.winfo_rootx())
            y = self.table_canvas.canvasy(event.y_root - self.table_canvas.winfo_rooty())
            self.table_canvas.scan_dragto(x, y, gain=1)

    def _stop_table_pan(self, _event=None):
        self._pan_origin = None

    def configure_table(self):
        try:
            rows = int(self.rows_var.get())
            cols = int(self.cols_var.get())
            if not (1 <= rows <= 30 and 1 <= cols <= 16):
                raise ValueError
        except ValueError:
            self.rows_var.set(str(self.table_rows))
            self.cols_var.set(str(self.table_cols))
            self.status_var.set("Scegli da 1 a 30 righe e da 1 a 16 colonne")
            return "break"
        if rows == self.table_rows and cols == self.table_cols:
            return "break"
        self.table_data = [[var.get() for var in row] for row in self.table_cells]
        self.table_rows, self.table_cols = rows, cols
        self._render_truth_table()
        self.dirty = True
        self._update_title()
        self.status_var.set("Dimensioni tavola aggiornate")
        return "break"

    def clear_truth_table(self):
        """Clear entered cell values while preserving the current grid dimensions."""
        changed = any(variable.get() for row in self.table_cells for variable in row)
        for row in self.table_cells:
            for variable in row:
                variable.set("")
        self.table_data = [[""] * self.table_cols for _ in range(self.table_rows)]
        self._scroll_pending_x = self._scroll_pending_y = 0.0
        self.table_canvas.xview_moveto(0)
        self.table_canvas.yview_moveto(0)
        if self.table_entries:
            self.table_entries[0][0].focus_set()
            self.table_entries[0][0].icursor(0)
        if changed:
            self.dirty = True
            self._update_title()
        self.status_var.set("Tavola ripulita; dimensioni conservate")

    def show_truth_table(self):
        if self.mode == "truth":
            return
        self.text_area.pack_forget()
        self.truth_frame.pack(fill="both", expand=True)
        self.mode = "truth"
        self._style_mode_buttons()
        self.status_var.set("Modalità tavola di verità")

    def show_notes(self):
        if self.mode != "truth":
            return
        self.truth_frame.pack_forget()
        self.text_area.pack(fill="both", expand=True, padx=4, pady=4)
        self.mode = "appunti"
        self._style_mode_buttons()
        self.status_var.set("Modalità appunti")

    def _show_placeholder(self):
        self.placeholder_visible = True
        self.editor.insert("1.0", PLACEHOLDER, "placeholder")
        self.editor.edit_modified(False)

    def _clear_placeholder(self):
        if self.placeholder_visible:
            self.editor.delete("1.0", "end")
            self.placeholder_visible = False
            self.editor.edit_modified(False)

    def _on_editor_focus(self, _event=None):
        self._clear_placeholder()

    def _on_editor_blur(self, _event=None):
        if not self.editor.get("1.0", "end-1c").strip():
            self._show_placeholder()

    def insert_symbol(self, symbol):
        if self.mode == "truth":
            entry = self.active_table_entry
            if entry is None or not entry.winfo_exists():
                entry = self.table_entries[0][0]
                self.active_table_entry = entry
            entry.focus_set()
            entry.insert(tk.INSERT, symbol)
            self.dirty = True
            self._update_title()
            return
        self._clear_placeholder()
        self.editor.insert("insert", symbol)
        self.editor.focus_set()
        self.editor.edit_modified(True)

    def _on_modified(self, _event=None):
        if self.editor.edit_modified():
            if not self.placeholder_visible:
                self.dirty = True
                self._update_title()
            self.editor.edit_modified(False)

    def _update_title(self):
        name = self.current_file.name if self.current_file else "Senza titolo"
        dirty = " •" if self.dirty else ""
        self.title(f"{name}{dirty} — LogicaDesk")

    def _content(self):
        if self.mode == "truth":
            self.table_data = [[var.get() for var in row] for row in self.table_cells]
            return f"# LogicaDesk tavola {self.table_rows}x{self.table_cols}\n" + "\n".join("\t".join(row) for row in self.table_data)
        return "" if self.placeholder_visible else self.editor.get("1.0", "end-1c")

    def _confirm_discard(self):
        if not self.dirty:
            return True
        answer = messagebox.askyesnocancel("Modifiche non salvate", "Vuoi salvare le modifiche prima di continuare?", parent=self)
        if answer is None:
            return False
        if answer:
            return self.save_file()
        return True

    def _replace_content(self, content):
        self.mode = "appunti"
        self._style_mode_buttons()
        self.truth_frame.pack_forget()
        self.text_area.pack(fill="both", expand=True, padx=4, pady=4)
        self._clear_placeholder()
        self.editor.delete("1.0", "end")
        if content:
            self.editor.insert("1.0", content)
        self.dirty = False
        self.editor.edit_modified(False)
        if not content:
            self._show_placeholder()

    def new_file(self):
        if not self._confirm_discard():
            return
        self.current_file = None
        self._replace_content("")
        self._update_title()
        self.status_var.set("Nuovo documento")

    def open_file(self):
        if not self._confirm_discard():
            return
        filename = filedialog.askopenfilename(parent=self, title="Apri appunti o tavola", filetypes=[("Documenti LogicaDesk", "*.txt *.md *.logic *.tsv"), ("Tutti i file", "*.*")])
        if not filename:
            return
        try:
            content = Path(filename).read_text(encoding="utf-8")
        except (OSError, UnicodeError) as error:
            messagebox.showerror("Errore di apertura", f"Non riesco ad aprire il file.\n\n{error}", parent=self)
            return
        self.current_file = Path(filename)
        if content.startswith("# LogicaDesk tavola "):
            lines = content.splitlines()
            try:
                dimensions = lines[0].split("tavola ", 1)[1]
                rows, cols = (int(part) for part in dimensions.split("x", 1))
                data = [line.split("\t") for line in lines[1:]]
                self.table_rows, self.table_cols = rows, cols
                self.table_data = [(row + [""] * cols)[:cols] for row in data[:rows]]
                self.table_data.extend([[""] * cols for _ in range(rows - len(self.table_data))])
                self._replace_content("")
                self._render_truth_table()
                self.mode = "truth"
                self._style_mode_buttons()
                self.text_area.pack_forget()
                self.truth_frame.pack(fill="both", expand=True)
            except (ValueError, IndexError):
                self._replace_content(content)
        else:
            self._replace_content(content)
        self._update_title()
        self.status_var.set("Documento aperto")

    def save_file(self):
        if self.current_file is None:
            return self.save_as()
        return self._write_file(self.current_file)

    def save_as(self):
        default_ext = ".tsv" if self.mode == "truth" else ".txt"
        filename = filedialog.asksaveasfilename(parent=self, title="Salva appunti o tavola", defaultextension=default_ext,
            filetypes=[("Tavola di verità", "*.tsv"), ("Testo", "*.txt"), ("Markdown", "*.md"), ("LogicaDesk", "*.logic"), ("Tutti i file", "*.*")])
        if not filename:
            return False
        self.current_file = Path(filename)
        return self._write_file(self.current_file)

    def _write_file(self, path):
        try:
            path.write_text(self._content(), encoding="utf-8")
        except OSError as error:
            messagebox.showerror("Errore di salvataggio", f"Non riesco a salvare il file.\n\n{error}", parent=self)
            return False
        self.editor.edit_modified(False)
        self.dirty = False
        self._update_title()
        self.status_var.set(f"Salvato: {path.name}")
        return True

    def _export_dialog(self, extension, filetype):
        base = self.current_file.stem if self.current_file else "Appunti di logica"
        return filedialog.asksaveasfilename(
            parent=self, title=f"Esporta in {extension.upper()}",
            initialfile=f"{base}.{extension}", defaultextension=f".{extension}",
            filetypes=[(filetype, f"*.{extension}")])

    def _export_data(self):
        if self.mode == "truth":
            data = [[var.get() for var in row] for row in self.table_cells]
            return "truth", data
        return "notes", self._content()

    def export_pdf(self):
        filename = self._export_dialog("pdf", "Documento PDF")
        if not filename:
            return
        try:
            self._write_pdf(Path(filename))
        except ImportError:
            messagebox.showerror("Esportazione PDF non disponibile",
                "I componenti PDF non sono installati in questo Python. Chiudi l'app e avviala con «Avvia LogicaDesk.bat»: li installerà automaticamente al primo avvio.\n\nServe una connessione Internet per la prima installazione.", parent=self)
        except Exception as error:
            messagebox.showerror("Errore di esportazione", f"Non riesco a creare il PDF.\n\n{error}", parent=self)
        else:
            self.status_var.set(f"PDF creato: {Path(filename).name}")
            messagebox.showinfo("PDF creato", "Il documento è stato esportato correttamente.", parent=self)

    def _write_pdf(self, path):
        from xml.sax.saxutils import escape
        from reportlab.lib import colors
        from reportlab.lib.enums import TA_LEFT
        from reportlab.lib.pagesizes import A4, landscape
        from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont
        from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
                                        TableStyle, Preformatted, KeepTogether)

        primary_path = Path(r"C:\Windows\Fonts\segoeui.ttf")
        symbol_path = Path(r"C:\Windows\Fonts\seguisym.ttf")
        if not symbol_path.exists():
            symbol_path = Path(r"C:\Windows\Fonts\seguisym.ttf")
        if primary_path.exists() and "LogicaUI" not in pdfmetrics.getRegisteredFontNames():
            pdfmetrics.registerFont(TTFont("LogicaUI", str(primary_path)))
        if symbol_path.exists() and "LogicaSymbols" not in pdfmetrics.getRegisteredFontNames():
            pdfmetrics.registerFont(TTFont("LogicaSymbols", str(symbol_path)))
        normal_font = "LogicaUI" if primary_path.exists() else "Helvetica"
        symbol_font = "LogicaSymbols" if symbol_path.exists() else normal_font
        symbol_chars = set("¬∧∨→↔⊕∀∃∴⊤⊥⊢⊨≡∈∉∅ℕℤ⊆⊂∪∩∅∧∨")

        def markup(value):
            parts = []
            for char in value:
                safe = escape(char)
                if char in symbol_chars and symbol_font != normal_font:
                    parts.append(f'<font name="{symbol_font}">{safe}</font>')
                else:
                    parts.append(safe)
            return "".join(parts) or "&#160;"

        kind, payload = self._export_data()
        wide = kind == "truth" and self.table_cols > 6
        page_size = landscape(A4) if wide else A4
        doc = SimpleDocTemplate(str(path), pagesize=page_size, rightMargin=34,
                                leftMargin=34, topMargin=38, bottomMargin=38,
                                title="Appunti di logica", author="LogicaDesk")
        styles = getSampleStyleSheet()
        body = ParagraphStyle("LogicBody", parent=styles["BodyText"], fontName=normal_font,
                              fontSize=10.5, leading=15, textColor=colors.HexColor("#25334b"),
                              spaceAfter=4, alignment=TA_LEFT, splitLongWords=1)
        story = []
        if kind == "notes":
            text = payload.strip()
            for block in text.split("\n") if text else [""]:
                if any(char in block for char in "┌┐└┘├┤─│┬┴┼╞═╪╡"):
                    from reportlab.pdfbase.pdfmetrics import stringWidth
                    mono = "Courier"
                    size = 7.5
                    max_width = page_size[0] - 68
                    while size > 5.2 and stringWidth(block, mono, size) > max_width:
                        size -= .25
                    story.append(Preformatted(block, ParagraphStyle(
                        "LogicGrid", fontName=mono, fontSize=size, leading=size + 3,
                        textColor=colors.HexColor("#233a68"))))
                else:
                    story.append(Paragraph(markup(block), body))
            if not text:
                story.append(Paragraph("Appunti di logica", body))
        else:
            widths = [(page_size[0] - 68) / max(1, self.table_cols)] * self.table_cols
            data = [[Paragraph(("<b>%s</b>" if r_index == 0 else "%s") % (markup(value) or "&#160;"), ParagraphStyle(
                "Cell", parent=body, fontSize=9 if self.table_cols <= 8 else 7,
                leading=11 if self.table_cols <= 8 else 9, alignment=1, spaceAfter=0))
                for value in row] for r_index, row in enumerate(payload)]
            table = Table(data, colWidths=widths, repeatRows=0, hAlign="LEFT")
            table.setStyle(TableStyle([
                ("GRID", (0, 0), (-1, -1), .5, colors.HexColor("#b8c4e6")),
                ("BACKGROUND", (0, 0), (-1, -1), colors.white),
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#dfeaff")),
                ("BOX", (0, 0), (-1, -1), 1.5, colors.HexColor("#2c3e9e")),
                ("LINEBELOW", (0, 0), (-1, 0), 1.5, colors.HexColor("#2c3e9e")),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("LEFTPADDING", (0, 0), (-1, -1), 5),
                ("RIGHTPADDING", (0, 0), (-1, -1), 5),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]))
            story.append(table)
        doc.build(story)

    def export_word(self):
        filename = self._export_dialog("docx", "Documento Word")
        if not filename:
            return
        try:
            self._write_word(Path(filename))
        except ImportError:
            messagebox.showerror("Esportazione Word non disponibile",
                "I componenti Word non sono installati in questo Python. Chiudi l'app e avviala con «Avvia LogicaDesk.bat»: li installerà automaticamente al primo avvio.\n\nServe una connessione Internet per la prima installazione.", parent=self)
        except Exception as error:
            messagebox.showerror("Errore di esportazione", f"Non riesco a creare il documento Word.\n\n{error}", parent=self)
        else:
            self.status_var.set(f"Word creato: {Path(filename).name}")
            messagebox.showinfo("Documento Word creato", "Il documento è stato esportato correttamente.", parent=self)

    def _write_word(self, path):
        from docx import Document
        from docx.enum.section import WD_ORIENT
        from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
        from docx.shared import Inches, Pt, RGBColor

        kind, payload = self._export_data()
        document = Document()
        section = document.sections[0]
        section.top_margin = Inches(.65)
        section.bottom_margin = Inches(.65)
        section.left_margin = Inches(.7)
        section.right_margin = Inches(.7)
        section.page_width = Inches(8.27)
        section.page_height = Inches(11.69)
        if kind == "truth" and self.table_cols > 6:
            section.orientation = WD_ORIENT.LANDSCAPE
            section.page_width, section.page_height = section.page_height, section.page_width
        normal = document.styles["Normal"]
        normal.font.name = "Cambria"
        normal.font.size = Pt(11)
        normal.font.color.rgb = RGBColor(37, 51, 75)
        if kind == "notes":
            text = payload.strip()
            for line in text.split("\n") if text else [""]:
                paragraph = document.add_paragraph()
                paragraph.paragraph_format.space_after = Pt(4)
                run = paragraph.add_run(line if line else " ")
                if any(char in line for char in "┌┐└┘├┤─│┬┴┼╞═╪╡"):
                    run.font.name = "Consolas"
                    run.font.size = Pt(max(5, min(9, 600 / max(1, len(line)))))
                run.font.color.rgb = RGBColor(35, 58, 104)
        else:
            table = document.add_table(rows=self.table_rows, cols=self.table_cols)
            table.style = "Table Grid"
            table.autofit = True
            for row_index, row in enumerate(payload):
                for col_index, value in enumerate(row):
                    cell = table.cell(row_index, col_index)
                    cell.text = value
                    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
                    for paragraph in cell.paragraphs:
                        paragraph.alignment = 1
                        for run in paragraph.runs:
                            run.font.name = "Cambria"
                            run.font.size = Pt(10 if self.table_cols <= 8 else 8)
                            run.font.bold = row_index == 0
        document.save(path)

    def _on_close(self):
        if self._confirm_discard():
            self.destroy()


if __name__ == "__main__":
    if Image is None:
        _root = tk.Tk()
        _root.withdraw()
        messagebox.showerror(
            "LogicaDesk",
            "Manca il componente Pillow, necessario per la grafica.\n"
            "Installalo con:  python -m pip install --user -r requirements.txt")
        sys.exit(1)
    LogicaDesk().mainloop()
