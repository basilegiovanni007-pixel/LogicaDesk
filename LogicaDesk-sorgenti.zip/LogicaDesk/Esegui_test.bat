@echo off
title Test del motore logico di LogicaDesk
cd /d "%~dp0"
set "PY_CMD=py -3"
%PY_CMD% --version >nul 2>&1
if errorlevel 1 set "PY_CMD=python"
echo Controllo del motore logico in corso...
echo.
%PY_CMD% -X utf8 -B test_motore_logico.py
echo.
if errorlevel 1 (echo ATTENZIONE: qualche test non e' passato. Leggi i messaggi qui sopra.) else (echo Tutto a posto: tutti i test sono passati.)
pause
