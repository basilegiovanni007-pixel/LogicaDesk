LOGICADESK
==========

Un editor desktop in italiano per appunti ed esercitazioni di logica, con
interfaccia in stile vetro: sfondo sfumato pastello, schede traslucide con
ombre morbide, pulsanti in vetro colorato con riflesso e un logo originale
ispirato alle connessioni logiche. La grafica è generata con Pillow, quindi
bordi e riflessi sono lisci anche sugli schermi ad alta densità.
Su Windows usa il ridimensionamento DPI del monitor per mantenere testo e
controlli nitidi anche sugli schermi ad alta densità.
Le modalità Appunti e Tavola di verità evidenziano quella attiva. I simboli
vengono inseriti solo nell'area corrente, inclusa la cella selezionata della
tavola. Il pulsante «Inserisci negli appunti» trasferisce la griglia nella
pagina degli appunti e la adatta alla larghezza disponibile. Pulsanti, celle e
indicatori hanno superfici arrotondate e riflessi.

Avvio
-----
1. Verifica che Python includa Tkinter. Su Windows, l'installazione standard
   di Python normalmente include Tkinter.
2. Fai doppio clic su Avvia LogicaDesk.bat.
   In alternativa, apri un terminale in questa cartella ed esegui:
       python logica_desk.py
   Il file .bat installa automaticamente i componenti PDF e Word al primo
   avvio, se mancano. Per questa prima installazione serve Internet. Se avvii
   direttamente il file Python, installali manualmente con:
       python -m pip install --user -r requirements.txt

Funzioni
--------
- Editor di testo con annulla/ripristina e selezione.
- Pulsanti per inserire simboli logici nel punto in cui si trova il cursore.
- Pulsante «α Greche» accanto alla barra dei simboli: apre e chiude nella stessa
  pagina una raccolta a ventaglio di lettere greche minuscole e maiuscole.
- Formulario ricercabile di equivalenze classiche: cerca per nome o simbolo e
  inserisci una formula direttamente nell'area attiva. L'elenco scorre in
  verticale con il trackpad a due dita in modo leggero e progressivo.
- Testo guida visibile solo quando il documento è vuoto; non viene salvato.
- Modalità Tavola di verità con caselle modificabili e dimensioni configurabili
  fino a 30 righe e 16 colonne.
- Le dimensioni si cambiano direttamente nei controlli «Griglia righe × colonne»
  della tavola, senza finestre separate. Usa le frecce, digita un numero e premi
  Invio per applicare la nuova dimensione.
- «Ripulisci tavola» svuota tutte le celle e conserva le dimensioni correnti.
- Nella tavola, rotella/gesto verticale scorre su e giù; Shift+rotella scorre
  a destra e sinistra. Puoi anche trascinare la griglia con mouse o touchscreen.
- Con trackpad Windows, il gesto naturale a due dita scorre la tavola in
  verticale e in orizzontale senza richiedere Shift.
- Nella tavola puoi spostarti tra le celle con le frecce della tastiera; Invio
  e il tasto Invio numerico portano alla cella sottostante. La griglia scorre
  automaticamente per mantenere visibile la cella attiva.
- Lo scorrimento ad alta precisione è graduale e meno sensibile; i piccoli
  movimenti del trackpad vengono accumulati per evitare salti e scatti.
- Le tavole si salvano come file .tsv e si possono riaprire in modalità tavola.
- Esportazione della modalità attiva in PDF pronto per la stampa o in Word
  modificabile. Gli appunti conservano i simboli logici; le tavole vengono
  esportate come griglie vere e proprie. Per tavole larghe viene usato il foglio
  orizzontale, mentre quelle più piccole e gli appunti usano il verticale.
- Creazione, apertura e salvataggio di file UTF-8 (.txt, .md e .logic).
- Avvisi quando chiudi o cambi documento con modifiche non salvate.
- Scorciatoie: Ctrl+N (nuovo), Ctrl+O (apri), Ctrl+S (salva).

Il programma è diviso in due file, da tenere nella stessa cartella:
- logica_desk.py   la finestra dell'app
- motore_logico.py il motore logico (legge i valori V/F delle celle della tavola);
  è lo stesso motore usato da LogicaDesk Pro.
Con Esegui_test.bat puoi controllare il motore con i test automatici
(test_motore_logico.py).

L'editor e le tavole usano solo Tkinter e Pillow. PDF e Word
usano i componenti elencati in requirements.txt, installati dal file .bat se
mancano. Le celle della tavola sono libere: la generazione automatica della
tavola, le equivalenze, la conseguenza logica e le altre funzioni di calcolo
sono in LogicaDesk Pro.
