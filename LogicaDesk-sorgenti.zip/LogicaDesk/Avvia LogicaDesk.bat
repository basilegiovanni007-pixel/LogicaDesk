@echo off
cd /d "%~dp0"
if not exist "logica_desk.py" goto files_error
if not exist "motore_logico.py" goto files_error
set "PY_CMD=py -3"
%PY_CMD% --version >nul 2>&1
if errorlevel 1 set "PY_CMD=python"
%PY_CMD% --version >nul 2>&1
if errorlevel 1 goto python_error

%PY_CMD% -c "import reportlab, docx, PIL" >nul 2>&1
if errorlevel 1 (
  echo Installazione iniziale dei componenti per esportare PDF e Word...
  %PY_CMD% -m pip --version >nul 2>&1
  if errorlevel 1 (
    %PY_CMD% -m ensurepip --upgrade
    if errorlevel 1 goto pip_error
  )
  %PY_CMD% -m pip install --user --disable-pip-version-check "reportlab>=4.2,<5" "python-docx>=1.1,<2" "pillow>=9.1"
  if errorlevel 1 goto install_error
)

%PY_CMD% logica_desk.py
if errorlevel 1 (
  echo.
  echo Non e' stato possibile avviare LogicaDesk. Verifica che Python e Tkinter siano installati.
  pause
)
exit /b

:python_error
echo Python non trovato. Installa Python 3 e riprova.
pause
exit /b 1

:pip_error
echo Non riesco ad attivare pip. Reinstalla Python selezionando il componente pip.
pause
exit /b 1

:install_error
echo Installazione non riuscita. Controlla la connessione Internet e riprova.
pause
exit /b 1

:files_error
echo Non trovo logica_desk.py o motore_logico.py in questa cartella.
echo Estrai tutto il contenuto dello zip (clic destro, "Estrai tutto") e riprova da li'.
pause
exit /b 1
